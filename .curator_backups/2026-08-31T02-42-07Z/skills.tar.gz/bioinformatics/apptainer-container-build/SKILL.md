---
name: apptainer-container-build
description: Build Apptainer SIF containers from conda YAML via EnvUtil — PyPI detection, post hooks, verification, pitfalls.
tags: [apptainer, conda, container, bioinformatics, omics]
triggers:
  - apptainer build
  - SIF container
  - EnvUtil.py
  - .def file generation
  - conda env create in container
---

# Apptainer Container Build via EnvUtil

## EnvUtil Workflow

`EnvUtil.py` at `workflow/Omics/src/common/util/EnvUtil.py` generates `.def` files from conda YAML and builds SIF images.

```bash
# Generate .def only
python EnvUtil.py apptainer gen -y <yaml>

# Full pipeline: YAML -> .def -> SIF
python EnvUtil.py apptainer all -y <yaml> -o <output_dir> [--force]
```

## PyPI-Only Detection

When a conda YAML has **only pip dependencies** (plus python/pip meta-packages), EnvUtil auto-generates a `python:3.11-slim` + `uv pip install` template instead of conda.

Detection logic in `is_pypi_only()`:
- Filters out `python*` and `pip*` from conda dependencies
- If remaining conda deps exist → not pypi-only → use conda template
- If only pip deps → pypi-only → use uv template

**Pitfall**: scTE.yaml had `python>=3.6` + `pip` + `pip: scte-quant`. This was detected as PyPI-only, but `scte-quant` needs `samtools` and `zstd` (system/conda packages). Always check runtime dependencies, not just the YAML.

## Post-Install Hooks

For module-specific patches (e.g., scTE mitochondrial fix), create `<env_name>.post.sh` next to the YAML. EnvUtil auto-reads it and injects into `%post`.

```bash
# workflow/Omics/modules/scTE/scTE.post.sh
    # Fix scTE bug: M<->MT mitochondrial naming mismatch
    SCTE_BASE=$(find /opt/conda/envs/scTE -path "*/site-packages/scTE/base.py" | head -1) && \
        python3 -c "..."
```

**Pitfall**: `find ... -path "*/scTE/*"` matches too broadly (e.g., `email/mime/base.py`). Use precise path: `*/site-packages/scTE/base.py`.

## Build Verification

`apptainer build --fakeroot` may return 0 even when `%post` fails. EnvUtil now does two post-build checks:

1. **SIF size**: < 350 MB → RuntimeError (base image is ~300 MB)
2. **conda env check**: `apptainer exec <sif> conda env list` → verify env name exists

## Cell Ranger GTF Biotype Compatibility

Cell Ranger mkref filters GTF by biotype using `gene_type`/`transcript_type` (GENCODE format). Ensembl GTFs use `gene_biotype`/`transcript_biotype` instead, causing 0 genes to pass the filter. See `references/cellranger-gtf-biotype.md` for the fix.

## Key Pitfalls

1. **SIF is read-only at runtime** — cannot patch files inside a built container. All patches must be baked into `.def` before build.

2. **Classic solver is slow** — conda-forge + bioconda dual-channel with classic solver can take 10+ minutes. `libmamba` solver requires `conda install -n base -c conda-forge -y conda-libmamba-solver` which may fail in container build context. Stick with classic for reliability.

3. **`--force` flag** — Added to EnvUtil CLI. Default is `False`. When set, implies `--no-skip-existing` (rebuilds even if SIF exists).

4. **EnvUtil overwrites .def** — Running `apptainer gen` regenerates .def from template, losing manual edits. Use `.post.sh` hooks for custom patches.

## Installed vs Source Code Mismatch (CRITICAL)

The installed package inside a container may differ from the source repo:
- Different variable names (`chrom` vs `chr`)
- Different spacing (`[str(k)` vs `[ str(k)`)
- Different line numbers
- Different function signatures

**Rule**: Always check the ACTUAL installed file inside the container before writing patches:
```bash
apptainer exec <sif> bash -c 'grep -n "target_pattern" /opt/conda/envs/scTE/bin/scTE_build'
```
Don't assume the source repo matches what's installed. Patches that work on source code but fail on installed code produce silent failures — the build succeeds but the fix isn't applied.

**Pattern**: When a post.sh patch fails silently, verify by grepping the container:
```bash
apptainer exec <sif> bash -c 'grep -c "expected_patch_text" /path/to/installed/file'
```

## Comparing Container Code with PyPI Original

When debugging whether post.sh patches caused unexpected behavior, download the original PyPI package and diff against the container's installed version:

```bash
# Download original package
pip download <package>==<version> --no-deps -d /tmp/fresh_pkg
# Extract
unzip /tmp/fresh_pkg/*.whl -d /tmp/fresh_pkg_extracted
# Get container's installed version
apptainer exec <sif> cat <path/to/installed/file> > /tmp/container_file.py
# Diff
diff /tmp/fresh_pkg_extracted/<module>/file.py /tmp/container_file.py
```

This reveals exactly what the post.sh patches changed vs the original. If the diff shows only unrelated changes (e.g., M/MT naming), the patches didn't affect the behavior in question.

**Pitfall**: Don't compare with local source code in the workflow directory — it may be a separately modified version, not the source for the container. Always compare with the actual PyPI package. When the user says "the code was modified by post.sh", verify by downloading the ORIGINAL PyPI package and diffing against the container's installed code. Don't assume the local workflow source is the baseline.

## scTE Quantification Flow (for debugging cell count issues)

The scTE multi-thread quantification pipeline:

1. **Bam2bed**: `samtools view | awk (extract CR/CB + UR/UB) | sed (strip prefixes) | sed (strip chr) | awk '!x[$4$5]++' (dedup by barcode+UMI) | compress`
2. **split_chr** (per chromosome): `grep ^<chr> | count per barcode → .count.gz`
3. **filter_crs**: Sum counts across all chromosomes per barcode, filter ≥ `2 * min_genes` (default 400)
4. **align** (per chromosome): Match reads to gene/TE annotations using bucket index
5. **count_expression**: Filter barcodes with ≥ `min_genes` (default 200) unique annotations, take top `cellnumber` (default 10000)

**Key insight**: M/MT patches only affect `splitAllChrs` (single-thread path) and index building. They don't change the multi-thread quantification logic. If cell counts differ between versions, the cause is NOT the M/MT patches.

**Debugging low cell count**: Check `filter_crs` output: "Before filter N / After filter M". If M is very low, the issue is in the Bam2bed dedup or the barcode/UMI tag extraction. If M is reasonable but final count is low, check `count_expression` gene filtering.

**CRITICAL — samtools vs pysam fallback in Bam2bed**: scte-quant 1.6.1 has two Bam2bed paths:
- `_bam2bed_cmd` (samtools path): `samtools view | awk | sed | awk '!x[$4$5]++' | compress` — includes UMI dedup by barcode+UMI
- `_bam2bed_pysam` (pysam fallback): iterates reads with pysam, writes every read to BED — **NO dedup**

The pysam path writes ALL 120M reads to BED (no `awk '!x[$4$5]++'`), while the samtools path deduplicates to ~29M unique barcode+UMI pairs. This causes each barcode to have ~4x more counts in the pysam path, dramatically increasing the number of barcodes that pass the `filter_crs` threshold.

**Impact**: If the container has samtools but the test environment doesn't, results will differ massively (e.g., 110 cells vs 20K cells). Always ensure samtools is available when reproducing container results outside the container.

**Check which path was used**:
```bash
grep "samtools" <log_file>
# "samtools found" → samtools path (with dedup)
# "samtools not found — falling back to pysam" → pysam path (NO dedup)
```

## Container File Inspection

```bash
# List installed package files
apptainer exec <sif> find /opt/conda/envs/<env> -path "*/site-packages/<module>/*.py"

# Read a specific file
apptainer exec <sif> cat $(apptainer exec <sif> find /opt/conda/envs/<env> -path "*/site-packages/<module>/base.py" | head -1)

# Run Python inside container (avoid local source contamination)
cd /tmp && apptainer exec <sif> /opt/conda/envs/<env>/bin/python3 -c "import <module>; print(<module>.__file__)"

# Check what a module actually imports from (avoid CWD contamination)
cd /tmp && apptainer exec <sif> /opt/conda/envs/<env>/bin/python3 -c "
import sys; sys.path.insert(0, '/opt/conda/envs/<env>/')
import <module>.base; print(<module>.base.__file__)
"
```

**Pitfall**: Apptainer bind-mounts CWD by default. If CWD contains a local copy of the same package, Python may import the local version instead of the container's installed version. Always `cd /tmp` (or another neutral directory) before running Python inside the container.

## Annotation Standardization

Macaque Ensembl GTF (Mmul_10) uses non-standard mitochondrial gene names:
- GTF: `ND1`, `COX1`, `ATP6` (no `MT-` prefix)
- Standard (human/mouse): `MT-ND1`, `MT-COX1`, `MT-ATP6`
- Downstream QC tools (Scanpy/Seurat) match `^MT-` → macaque MT genes missed

Created `workflow/Omics/src/annotation/standardize_annotations.py`:
- Normalizes chromosome names (strip `chr`, M/chrM → MT)
- Adds `MT-` prefix to gene_name on mitochondrial chromosomes (by chromosome, not gene list)
- Supports gzipped GTF/BED
- `--dry-run` for preview, `--scan` to find all annotation files
- Species-agnostic — no `--species` parameter needed

**Rule**: Before building scTE index, always standardize annotations first:
```bash
python3 workflow/Omics/src/annotation/standardize_annotations.py \
  --gtf <gene.gtf> --te <te.bed> --dry-run  # preview
python3 workflow/Omics/src/annotation/standardize_annotations.py \
  --gtf <gene.gtf> --te <te.bed>             # execute
```

## scRNA-seq QC Gene Categories

Standard downstream QC checks these gene categories:
1. **MT-** (mitochondrial): high % → cell death/damage
2. **RPS/RPL** (ribosomal): high % → cell stress/activation
3. **HB-** (hemoglobin): red blood cell contamination
4. **PPBP/PF4** (platelet): platelet contamination
5. **MALAT1**: lncRNA affecting clustering

Naming conventions vary by GTF source. Always verify after standardization.

## scTE-Specific Notes

Exact patch text patterns: see `references/scte-patch-patterns.md`

- scTE needs: samtools, zstd (conda), scte-quant (pip)
- M<->MT patch: bidirectional fix in `splitAllChrs()` for UCSC chrM vs Ensembl MT
- scTE_build has hardcoded `chr_list = [..., 'M']` — does NOT include 'MT'. Ensembl GTF uses 'MT', so MT genes are silently skipped during index building. **Fix**: post.sh patches chr_list to add 'MT', and adds M<->MT normalization in readGtf() and TE processing.
- scTE_build `readGtf()` skips exon lines without `gene_name` — Mt_tRNA/Mt_rRNA from RefSeq lack gene_name and are silently dropped. This is expected behavior.
- **post.sh patches vs stock scte-quant 1.6.1**: The M/MT fixes are already built into scte-quant 1.6.1 from PyPI. The post.sh patches are effectively no-ops — they look for old text patterns that don't exist in the current version. Verified by downloading the original PyPI wheel and diffing against the container's installed code. The ONLY difference between stock and container is the M/MT fix in `splitAllChrs`, which only affects the single-thread path and has no impact on multi-thread quantification results.
