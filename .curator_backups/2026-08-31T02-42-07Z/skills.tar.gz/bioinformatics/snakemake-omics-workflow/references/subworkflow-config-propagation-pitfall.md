# Pitfall: subworkflow config propagation

When a subworkflow (e.g. `scRNAseq.smk`) constructs a config dict to pass to a module via `module X: config: x_config`, it must explicitly list EVERY param the module reads. If a new param is added to the top-level config JSON but NOT added to the subworkflow's config dict construction, the module receives `None` and silently falls back to its default.

## Real example

Adding `limitSjdbInsertNsj` to `config/scRNAseq.json` and `modules/star/star.smk` had no effect until it was also added to the `star_config` dict in `subworkflow/scRNAseq.smk` (line ~36). The Snakemake metadata confirmed the param was `1000000` (default) despite config having `3000000`.

The flow is:
```
config/scRNAseq.json  -->  subworkflow/scRNAseq.smk (builds star_config dict)  -->  module star.smk (reads from star_config)
```

If step 2 doesn't pass a param, step 3 gets `None`.

## Rule

When adding a new param to a module's JSON config, ALWAYS check if the subworkflow that includes that module has a manually-constructed config dict. If so, add the param there too. Search pattern: `config: xxx_config` in the subworkflow .smk file.

## Affected subworkflows

- `subworkflow/scRNAseq.smk` — builds `star_config` and `scTE_config` dicts manually
- Any subworkflow using `module X: config: ...` syntax

## How to detect

Look for `module <name>:` blocks in subworkflow .smk files. Each one with a `config:` directive has a manually-constructed dict that must stay in sync with the module's param reads.
