---
name: scanpy-scrnaseq-reclustering
description: "Re-cluster scRNA-seq h5ad with Harmony and annotation."
tags: [scanpy, scrnaseq, clustering, annotation, harmony, single-cell]
---

# Scanpy scRNA-seq Re-clustering & Annotation

Nature-standard pipeline for re-clustering merged h5ad files with proper batch correction and cell type annotation.

## Reference Files

- `references/recluster_annotate_pipeline.py` — Original pipeline script
- `references/recluster_annotate_v3.py` — Nature-standard v3 with all reviewer fixes (colorblind palette, rare cell types, doublet verification, legend, merged clusters)
- `references/macaque_ovary_analysis.md` — Macaque ovary marker analysis results and validated configuration

## Trigger phrases
- "重新聚类" / "re-cluster" / "redo clustering"
- "注释效果不好" / "annotation not good"
- "细胞群颜色不纯净" / "impure clusters"
- "批次效应" / "batch effect"

## Pipeline Steps

### 1. QC Filtering
```python
# MUST use np.array() — pandas BooleanArray breaks scipy sparse indexing
adata.var["mt"] = np.array(adata.var_names.str.upper().str.startswith("MT-") | adata.var_names.str.startswith("mt"))
adata.var["ribo"] = np.array(adata.var_names.str.startswith(("RPS", "RPL")))
sc.pp.calculate_qc_metrics(adata, qc_vars=["mt", "ribo"], inplace=True)

# Standard thresholds
adata = adata[adata.obs.n_genes_by_counts >= 200].copy()
adata = adata[adata.obs.n_genes_by_counts <= 6000].copy()
adata = adata[adata.obs.pct_counts_mt <= 20].copy()
```

### 2. Normalize + HVG Selection
```python
if "counts" not in adata.layers:
    adata.layers["counts"] = adata.X.copy()

sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)

# Use flavor="seurat" — seurat_v3 requires skmisc which may not be installed
sc.pp.highly_variable_genes(
    adata, n_top_genes=2000,
    batch_key="sample_id" if "sample_id" in adata.obs else None,
    flavor="seurat",
)
```

### 3. Harmony Batch Correction
```python
# Scale HVGs only, then PCA
hvg_mask = adata.var.highly_variable.values
adata_hvg = adata[:, hvg_mask].copy()
sc.pp.scale(adata_hvg, max_value=10)
n_comps = min(50, max(2, adata_hvg.n_obs - 1), adata_hvg.n_vars)
sc.tl.pca(adata_hvg, n_comps=n_comps, svd_solver="arpack")

adata.obsm["X_pca"] = adata_hvg.obsm["X_pca"]
adata.uns["pca"] = adata_hvg.uns["pca"]

# Direct harmonypy call — scanpy wrapper broken with harmonypy 2.0
from harmonypy import run_harmony
meta_data = pd.DataFrame({batch_key: adata.obs[batch_key].values})
ho = run_harmony(adata.obsm["X_pca"], meta_data, vars_use=[batch_key], max_iter_harmony=20)
corrected = ho.Z_corr.T  # harmonypy 2.0: may need transpose
if corrected.shape[0] != adata.n_obs:
    corrected = corrected.T
adata.obsm["X_pca_harmony"] = np.ascontiguousarray(corrected)
```

### 4. Neighbors + UMAP + Leiden
```python
sc.pp.neighbors(adata, n_neighbors=30, n_pcs=50, use_rep="X_pca_harmony")
sc.tl.umap(adata, min_dist=0.3, spread=1.0)
sc.tl.leiden(adata, resolution=0.5, key_added="leiden", flavor="igraph", n_iterations=2, directed=False)
sc.tl.rank_genes_groups(adata, "leiden", method="wilcoxon", n_genes=100)
```

### 5. Marker-based Annotation
```python
# Score each cell type
for ct, genes in marker_dict.items():
    sc.tl.score_genes(adata, gene_list=genes, score_name=f"score_{ct}")

# Per-cluster majority voting with confidence
score_cols = [c for c in adata.obs.columns if c.startswith("score_")]
scores_df = adata.obs[score_cols].copy()
scores_df.columns = [c.replace("score_", "") for c in scores_df.columns]

cluster_anno = {}
for cluster in adata.obs["leiden"].cat.categories:
    mask = adata.obs["leiden"] == cluster
    cluster_scores = scores_df[mask].mean()
    best_ct = cluster_scores.idxmax()
    best_score = cluster_scores.max()
    second_best = cluster_scores.nlargest(2).iloc[1] if len(cluster_scores) >= 2 else 0.0
    confidence = "high" if best_score > 0.1 and (best_score - second_best) > 0.05 else "medium" if best_score > 0.05 else "low"
    cluster_anno[cluster] = {"cell_type": best_ct, "score": float(best_score), "confidence": confidence}

adata.obs["cell_type"] = adata.obs["leiden"].map(lambda x: cluster_anno[x]["cell_type"]).astype("category")
adata.obs["annotation_confidence"] = adata.obs["leiden"].map(lambda x: cluster_anno[x]["confidence"]).astype("category")
```

### 6. Plotting
```python
# Save scanpy plotter objects (DotPlot, MatrixPlot, etc.)
def save_fig(fig_or_plotter, path, dpi=300):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if hasattr(fig_or_plotter, "savefig"):
        fig_or_plotter.savefig(path, dpi=dpi, bbox_inches="tight")
    elif hasattr(fig_or_plotter, "fig"):
        fig_or_plotter.fig.savefig(path, dpi=dpi, bbox_inches="tight")
    else:
        plt.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close("all")

# pca_variance_ratio does NOT accept ax parameter
sc.pl.pca_variance_ratio(adata, n_pcs=50, show=False)
plt.savefig(path, dpi=300, bbox_inches="tight")
plt.close("all")
```

## Pitfalls

### Pitfall 1: BooleanArray crash
**Symptom**: `AttributeError: 'BooleanArray' object has no attribute 'nonzero'`
**Cause**: Pandas string methods return nullable BooleanArray, scipy sparse indexing needs numpy bool
**Fix**: Wrap in `np.array()`: `np.array(adata.var_names.str.startswith("MT-"))`

### Pitfall 2: harmonypy 2.0 API change
**Symptom**: `TypeError: run_harmony() missing 1 required positional argument: 'vars_use'`
**Cause**: harmonypy 2.0 changed `run_harmony(data, labels)` to `run_harmony(data, meta_data, vars_use=[...])`
**Fix**: Pass DataFrame with batch column, use `vars_use=[batch_key]`

### Pitfall 3: Harmony Z_corr shape
**Symptom**: `ValueError: Value passed for key 'X_pca_harmony' is of incorrect shape`
**Cause**: harmonypy 2.0 `Z_corr` may be transposed; scanpy wrapper tries `Z_corr.T` which gives wrong shape
**Fix**: Call harmonypy directly, check shape, transpose if needed

### Pitfall 4: pca_variance_ratio ax parameter
**Symptom**: `TypeError: pca_variance_ratio() got an unexpected keyword argument 'ax'`
**Fix**: Don't pass `ax`, save with `plt.savefig()` after calling

### Pitfall 5: DotPlot not a Figure
**Symptom**: `TypeError: close() argument must be a Figure... not <class 'scanpy.plotting._dotplot.DotPlot'>`
**Cause**: `sc.pl.dotplot(return_fig=True)` returns DotPlot, not matplotlib Figure
**Fix**: Check for `.savefig()` method or `.fig` attribute

### Pitfall 6: seurat_v3 requires skmisc
**Symptom**: `ModuleNotFoundError: No module named 'skmisc'`
**Fix**: Use `flavor="seurat"` instead, or `uv pip install scikit-misc`

## Step 7: Cluster Merging (Critical for Purity)

When the same cell type is split into multiple disconnected Leiden clusters, they appear as fragmented islands in UMAP. The user will notice "B1靠近A而不是B2" (B1 closer to A than to B2). Merge these using connected components:

```python
from scipy.sparse.csgraph import connected_components

def merge_fragmented_clusters(adata, cluster_anno):
    """Merge disconnected clusters of the same cell type."""
    if "connectivities" not in adata.obsp:
        return

    ct_clusters = {}
    for cluster, info in cluster_anno.items():
        ct = info["cell_type"]
        ct_clusters.setdefault(ct, []).append(cluster)

    merge_map = {}
    merged_id = 0

    for ct, clusters in ct_clusters.items():
        if len(clusters) == 1:
            merge_map[clusters[0]] = merged_id
            merged_id += 1
            continue

        # Build subgraph for this cell type
        ct_mask = adata.obs["leiden"].isin(clusters).values
        ct_indices = np.where(ct_mask)[0]
        if len(ct_indices) == 0:
            continue

        conn = adata.obsp["connectivities"]
        sub_conn = conn[np.ix_(ct_indices, ct_indices)]
        n_components, labels = connected_components(sub_conn, directed=False)

        component_map = {idx: labels[i] for i, idx in enumerate(ct_indices)}

        for cluster in clusters:
            cluster_mask = adata.obs["leiden"] == cluster
            cluster_indices = np.where(cluster_mask)[0]
            if len(cluster_indices) == 0:
                continue
            cluster_components = [component_map.get(idx, -1) for idx in cluster_indices]
            main_component = max(set(cluster_components), key=cluster_components.count)
            merge_key = f"{ct}_{main_component}"
            if merge_key not in merge_map:
                merge_map[merge_key] = merged_id
                merged_id += 1
            merge_map[cluster] = merge_map[merge_key]

    if merge_map:
        adata.obs["leiden_merged"] = adata.obs["leiden"].map(merge_map).astype("category")
```

**Diagnostic**: Check if same-type clusters are farther apart than different-type clusters:
```python
for ct in cell_types:
    clusters = adata.obs.loc[adata.obs["cell_type"] == ct, "leiden"].unique()
    if len(clusters) > 1:
        max_same = max(distance(cluster_i, cluster_j) for i, j in pairs(clusters))
        min_diff = min(distance(ct_cluster, other_ct_cluster) for other_ct in other_types)
        if max_same > min_diff:
            print(f"⚠️ {ct}: same-type clusters farther apart than different-type!")
```

**UMAP for merged clusters**:
```python
if "leiden_merged" in adata.obs.columns:
    fig, ax = plt.subplots(figsize=(12, 10))
    sc.pl.umap(adata, color="leiden_merged", legend_loc="on data", legend_fontsize=8, ax=ax, show=False, title="Merged Clusters")
    save_fig(fig, os.path.join(plot_dir, "umap_merged_clusters.png"))
```

### Pitfall 7: Fragmented clusters of same cell type
**Symptom**: Same cell type split into disconnected UMAP islands; B1 closer to A than to B2
**Cause**: Over-clustering (resolution too high) splits biologically continuous populations
**Diagnostic**: Compare max distance between same-type clusters vs min distance to different types
**Fix**: (1) Lower resolution to 0.6, (2) Merge clusters post-annotation using connected components (see Step 7)
**User signal**: "细胞群颜色不纯净", "同类cluster分散", "B1靠近A而不是B2"

### Pitfall 8: Shared markers cause cell type proximity
**Symptom**: Pericyte and Smooth_muscle too close in UMAP; Stromal and Theca overlapping
**Cause**: Biologically related cell types share markers (e.g., ACTA2/TAGLN in both Pericyte and Smooth_muscle; DCN/VIM/PDGFRA in both Stromal and Theca)
**Diagnostic**: Check marker expression overlap between close cell types (>50% shared = expect proximity)
**Expected**: Central UMAP region (Stromal/Smooth_muscle/Pericyte/OSE) forms a continuum — this is biology, not a bug
**Fix**: Use more specific markers, or accept biological continuity and explain in paper

## Parameter Guidelines

| Parameter | Loose (default) | Tight separation | Over-clustered |
|-----------|----------------|------------------|----------------|
| n_top_genes | 2000 | 2000 | >3000 |
| n_neighbors | 30 | 50 | 15 |
| min_dist | 0.3 | 0.1 | 0.1 |
| resolution | 0.3-0.5 | 0.6-0.8 | >1.0 |

**Validated macaque ovary config**: `n_top_genes=2000, n_neighbors=50, min_dist=0.1, spread=0.8, resolution=0.6` produced 18 clusters with good separation. After cluster merging: 9 contiguous cell type groups.

For Nature-quality: always use Harmony/BBKNN batch correction when >1 sample.

**Tight separation mode**: Use `min_dist=0.1, spread=0.8, n_neighbors=50, resolution=0.8-1.0` when user complains about mixed/impure clusters. This produces more compact UMAP islands but may not fully separate biologically related cell types (Stromal/Smooth_muscle/Pericyte/OSE share markers).

**Expected biological continuity**: Central UMAP regions connecting Stromal, Smooth_muscle, Pericyte, OSE, and Proliferating are biologically realistic — these mesenchymal/epithelial cell types share大量基因表达, forming a continuum in expression space. UMAP reflects this. Clean separation of these types requires unique markers, not just parameter tuning.

## Marker File Format (TSV)
```
cell_type	markers
Oocyte	DDX4,DAZL,GDF9,ZP3,FIGLA,NOBOX,SYCP3
Granulosa	FSHR,CYP19A1,AMH,FOXL2,BMPR1B,LHCGR
```

Check markers exist in `adata.var_names` before running annotation. Shared markers between cell types (e.g., LHCGR in Granulosa AND Theca, STAR in Theca AND Luteal) reduce annotation purity — use unique markers when possible.

### Macaque Ovary Markers (validated)
All64 markers below confirmed present in both cellranger (26,509 genes) and scTE (19,141 genes) datasets:
- Oocyte: DDX4, DAZL, GDF9, ZP3, FIGLA, NOBOX, SYCP3
- Granulosa: FSHR, CYP19A1, AMH, FOXL2, BMPR1B, LHCGR
- Theca: CYP17A1, IGF1, STAR, CYP11A1
- Stromal: COL1A1, COL3A1, DCN, LUM, VIM, PDGFRA
- Smooth_muscle: ACTA2, MYH11, TAGLN, CNN1, DES
- Endothelial: PECAM1, VWF, CDH5, KDR, EMCN
- Macrophage: CD68, CD163, CD74, CSF1R, C1QA
- T_NK_cell: CD3E, CD3D, CD8A, NKG7, GZMB
- B_cell: CD79A, CD79B, MS4A1, PAX5
- OSE: KRT18, EPCAM, WT1, LGR5, UPK3B
- Pericyte: RGS5, PDGFRB, NOTCH3, ABCC9
- Luteal: HSD3B1, PRLR, LHCGR, STAR
- Proliferating: MKI67, TOP2A, PCNA, CENPF

**Note**: KRT8 absent in macaque genome. LHCGR shared between Granulosa/Theca. STAR shared between Theca/Luteal. These overlaps cause annotation ambiguity in those populations.

## Nature Reviewer Checklist

When preparing scRNA-seq for Nature/Cell-level journals, address these issues proactively:

### Issue 1: Missing Cell Types
**Reviewer concern**: "Oocyte/B_cell/Luteal not identified as separate clusters"
**Root cause**: These cell types are too rare to form independent Leiden clusters
**Investigation**: Trace marker-positive cells:
```python
for gene in ["DDX4", "CD79A", "HSD3B1"]:
    expr = adata[:, gene].X.toarray().flatten()
    positive = expr > 0
    print(f"{gene}: {positive.sum()} positive cells")
    print(adata.obs[positive]["cell_type"].value_counts())
```
**Fix**: Document as "detected but not clustered" in Methods. Store in `adata.uns["rare_cell_types"]`.

### Issue 2: UMAP Legend Required
Every cell type UMAP MUST have a color legend. Scanpy default omits it.
```python
sc.pl.umap(adata, color="cell_type", legend_loc="right margin",
           legend_fontsize=10, legend_fontoutline=2)
```

### Issue 3: Colorblind-Friendly Palette
Avoid red/green pairs. Use Okabe-Ito extended palette:
```python
CB_PALETTE = {
    "Endothelial":       "#0072B2",  # blue
    "Granulosa":         "#E69F00",  # orange
    "Macrophage":        "#009E73",  # green
    "OSE":               "#CC79A7",  # pink (NOT red)
    "Pericyte":          "#56B4E9",  # light blue
    "Proliferating (mixed)": "#F0E442",  # yellow
    "Smooth_muscle":     "#D55E00",  # vermillion
    "Stromal":           "#999999",  # grey
    "T_NK_cell":         "#000000",  # black
    "Theca":             "#882255",  # dark purple
}
```

### Issue 4: Proliferating is Not a Cell Type
MKI67/TOP2A are universal proliferation markers, not cell-type-specific.
Label as "Proliferating (mixed)" to indicate it spans multiple lineages.

### Issue 5: Doublet Verification
If marker X (e.g., CD79A) appears in unexpected cell type Y (e.g., Macrophage):
1. Check co-expression with Y's own markers (CD68, CD163)
2. If <30% co-expression → likely contamination/ambient RNA, not doublet
3. If >70% co-expression → likely doublet
4. Generate marker expression UMAP for visual verification

### Issue 6: STAR Background Expression
STAR+ cells in Stromal (3373 cells) mostly DON'T express Theca markers:
- Only 6.4% express CYP17A1, 8.3% express CYP11A1
- This is low-level background, not real Theca/Luteal cells

### Issue 7: Sample Mixing Verification
Always generate post-Harmony sample UMAP to prove batch correction worked.
```python
sc.pl.umap(adata, color="sample_id", title="Samples (post-Harmony)")
```

## Rare Cell Type Detection
```python
def detect_rare_cell_types(adata, marker_dict):
    """Detect cell types too rare to form independent clusters."""
    rare_types = {}
    for ct, genes in marker_dict.items():
        expr_matrix = np.zeros((adata.n_obs, len(genes)))
        for i, gene in enumerate(genes):
            if gene in adata.var_names:
                gexpr = adata[:, gene].X
                if hasattr(gexpr, 'toarray'):
                    gexpr = gexpr.toarray().flatten()
                expr_matrix[:, i] = gexpr
        co_expr = (expr_matrix > 0).sum(axis=1)
        n_multi = int((co_expr >= 2).sum())
        if n_multi > 0:
            rare_types[ct] = {"multi_marker": n_multi}
            adata.obs.loc[co_expr >= 2, "rare_cell_type"] = ct
    if rare_types:
        adata.uns["rare_cell_types"] = rare_types
    return rare_types
```

## Publication-Quality Plot Checklist
1. ✓ UMAP cell type with legend (right margin, fontoutline=2)
2. ✓ UMAP merged clusters (on data labels)
3. ✓ UMAP sample (post-Harmony, prove batch correction)
4. ✓ UMAP confidence (high/medium/low with distinct colors)
5. ✓ Marker dotplot by cell type
6. ✓ DEG dotplot (rank_genes_groups)
7. ✓ Individual marker UMAPs for rare cell types (DDX4, CD79A, HSD3B1)
8. ✓ Doublet check UMAPs (CD79A, STAR expression)
