# Apptainer SIF build pitfalls (conda + fakeroot)

Building conda-based SIF containers with `apptainer build --fakeroot` on shared
HPC systems has three recurring failure modes. All three were discovered on a
system with conda 26.x and miniconda3 as the host conda installation.

## 1. Host conda PATH leaks into container `%post`

**Symptom:** `conda env create` inside `%post` uses the HOST's conda
(`/home/<user>/miniconda3/bin/conda`) instead of the container's
(`/opt/conda/bin/conda`). The build "succeeds" but the conda env inside the
SIF is empty — `/opt/conda/envs/<name>/` contains no packages.

**Diagnostic:** The conda error report shows `base environment: /home/<user>/miniconda3`
(the host path, not `/opt/conda`).

**Fix:** Prepend the container's conda to PATH in `%post`:
```
%post
    export PATH="/opt/conda/bin:$PATH"
    conda env create -f /opt/conda/<name>.yaml
```

This is already baked into `EnvUtil.generate_def()` — verify it's present if
editing .def files manually.

## 2. `anaconda_anon_usage` plugin error

**Symptom:** `An unexpected error has occurred. Conda has prepared the above
report. If you suspect this is being caused by a malfunctioning plugin...`
The error is from the `anaconda_anon_usage` package bundled with miniconda3.

**Fix:** Set `CONDA_NO_PLUGINS=true` in `%post`:
```
%post
    export PATH="/opt/conda/bin:$PATH"
    export CONDA_NO_PLUGINS=true
```

## 3. `libmamba` solver not recognized

**Symptom:** `CondaValueError: You have chosen a non-default solver backend
(libmamba) but it was not recognized. Choose one of: classic`

The host's `~/.condarc` sets `solver: libmamba`, which leaks into the container.
The container's miniconda3 doesn't have libmamba installed.

**Fix:** Force classic solver in `%post`:
```
%post
    export PATH="/opt/conda/bin:$PATH"
    export CONDA_NO_PLUGINS=true
    conda config --set solver classic
    conda env create -f /opt/conda/<name>.yaml
```

## Canonical `%post` template

All three fixes combined:
```
%post
    export PATH="/opt/conda/bin:$PATH"
    export CONDA_NO_PLUGINS=true
    conda config --set solver classic
    conda env create -f /opt/conda/{yaml_filename} && \
        conda clean -afy && \
        rm /opt/conda/{yaml_filename}
```

This template lives in `EnvUtil.generate_def()`. If you regenerate .def files
via `EnvUtil`, the fixes are automatic. If editing .def manually, ensure all
three exports are present.

## 4. `openms-thirdparty` ≠ `openms`

**Symptom:** `DecoyDatabase: command not found` (or any core OpenMS tool).

`openms-thirdparty=3.1.0` provides third-party wrappers (ThermoRawFileParser,
CometAdapter, etc.) but NOT core OpenMS tools. Core tools (DecoyDatabase,
FileConverter, PeptideIndexer, etc.) come from the `openms` package.

**Fix:** Always include BOTH in the YAML:
```yaml
dependencies:
  - openms=3.1.0
  - openms-thirdparty=3.1.0
```

All 8 OpenMS-based QuantMS containers (raw2mzml, decoydatabase, searchengine,
psmrescoring, psmfdr, proteininference, quantification, msstats) need both.

## 5. Network timeout → localimage bootstrap fallback

**Symptom:** `apptainer build` fails with `TLS handshake timeout` or
`dial tcp: i/o timeout` when fetching the Docker base image from any
registry (daocloud, Docker Hub, Anaconda).

**Fix:** Use an existing SIF as the base via `localimage` bootstrap:
```
Bootstrap: localimage
From: /home/luosg/Database/env/star/star.sif
```

The base SIF must already have miniconda3 installed (most Omics SIFs do).
The `%post` section then runs `conda env create` on top of the existing
conda installation. External binaries (e.g. cellranger-10.1.0) are
copied via `%files` and added to PATH in `%environment`.

## 6. Bundling external (non-conda) binaries in SIF

When a tool is distributed as a pre-compiled binary (not available via
conda), copy the entire directory into the container via `%files` and
add to PATH:

```
%files
    tool.yaml /opt/conda/tool.yaml
    /absolute/path/to/tool-1.0.0 /opt/tool-1.0.0

%post
    conda env create -f /opt/conda/tool.yaml && conda clean -afy
    echo 'export PATH="/opt/tool-1.0.0/bin:$PATH"' >> /etc/profile.d/tool.sh

%environment
    export PATH="/opt/conda/envs/tool/bin:$PATH"
    export PATH="/opt/tool-1.0.0/bin:$PATH"
```

The `%files` section preserves directory structure, so relative paths
(e.g. `bin/cellranger` → `lib/bin/STAR`) remain intact inside the
container.

## 7. anndata + pandas version incompatibility

**Symptom:** `ModuleNotFoundError: No module named 'pandas.core.index'`
when importing anndata inside the SIF.

**Cause:** `pandas.core.index.RangeIndex` was removed in pandas 2.0+.
Old anndata versions (<0.10) still import it.

**Fix:** Pin `anndata>=0.10` in the YAML. Do NOT pin `pandas<2.0` —
conda may ignore the constraint when other packages (scanpy, anndata)
pull in pandas 2.x+.

```yaml
dependencies:
  - python=3.11
  - anndata>=0.10
  - scanpy>=1.9
  - h5py
```

**Verification after build:**
```bash
apptainer exec <sif> python -c "import anndata, scanpy; print(anndata.__version__)"
```

## Rebuild checklist

When rebuilding SIFs after .def changes:
1. Verify .def has all 3 PATH/plugin/solver fixes
2. `apptainer build --force --fakeroot <name>.sif <name>.def`
3. Verify env is populated: `singularity exec <sif> bash -c 'ls /opt/conda/envs/<name>/bin/ | head'`
4. If empty, check build output for conda errors (the build may exit 0 even if conda failed)
