# scRNAseq Module Patterns

## Module Rule Pattern (MUST follow)

Rules validate + call scripts only. All logic in bin/ Python scripts.

Template (from scanpy_qc rule):
```python
rule some_analysis:
    input: h5ad=qc_h5ad
    output: h5ad=out_h5ad
    log: logdir + "/some_analysis.log"
    threads: 4
    conda: "env.yaml"
    container: sif("env.yaml")
    params:
        python=python,
        script=os.path.join(ROOT_DIR, "modules", "xxx", "bin", "xxx.py"),
        param1=params.get("param1", default),
    run:
        log_path = str(log)
        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            os.makedirs(os.path.dirname(output.h5ad), exist_ok=True)
            current_time = time.strftime("%Y%m%d_%H%M%S", time.localtime())
            command_script = os.path.join(os.path.dirname(output.h5ad), f"xxx_{current_time}.sh")
            cmd = [params.python, params.script, "--mode", "xxx", "--input", input.h5ad, "--output", output.h5ad]
            with open(command_script, "w") as handle:
                handle.write("#!/usr/bin/env bash\nset -euo pipefail\n")
                handle.write(" ".join(shlex.quote(str(item)) for item in cmd) + "\n")
            shell(f"bash {shlex.quote(command_script)} >> {shlex.quote(log_path)} 2>&1")
        except Exception as exc:
            with open(log_path, "a") as handle:
                handle.write(f"xxx failed: {exc}\n")
            raise
```

**PITFALL**: Do NOT embed sed/awk/grep in .smk run blocks. Shell escaping across Python to bash to sed is fragile. Use Python in bin/ instead.

## scRNAseq Pipeline Architecture

Dual-track (gene expression + transposable elements):

```
cellranger_ref (optional, from FASTA+GTF)
      |
cellranger_count (BAM + filtered matrix)
      |                    |
cellranger_to_h5ad    scTE_quantify
      |                    |
SC scanpy pipeline    TE scanpy pipeline
(qc->cluster->batch     (qc->cluster->batch
 ->annotate->advanced    ->annotate->advanced
 ->de)                  ->de)
```

## Cell Ranger Constraints

- `cellranger count --fastqs <dir> --sample <prefix>` -- auto-discovers by naming convention
- NO support for custom file paths (--read1, --read2 dont exist)
- Files must follow: `{sample}_S{samp}_L{lane}_{read}_{pair}.fastq.gz`
- For scTE: needs --create-bam=true
- Multi-lane: Cell Ranger merges automatically from directory

## scTE (Transposable Element Quantification)

```bash
scTE_build -g hg38 -o /path/to/hg38
scTE -i possorted_genome_bam.bam -o output -x hg38.exclusive.idx \
    --min_counts 1 --min_genes 1 -CB CB -UMI UB
```

- Input: Cell Ranger BAM with CB (cell barcode) and UB (UMI) tags
- Output: CSV matrix (cells x TEs)
- Convert to h5ad: pd.read_csv -> sparse csr_matrix -> AnnData
- Cell Ranger: -CB CB -UMI UB; STARsolo: -CB CR -UMI UR

## Multi-lane FASTQ Handling (MetaUtil.prepare_scRNAseq_meta)

For scRNAseq meta with fastq_dir + sample_prefix columns:
1. Scan fastq_dir for files matching sample_prefix + fq_pattern
2. Single-lane: symlink to raw_fq_dir/{sample_id}/{sample_id}_{1,2}.fq.gz
3. Multi-lane: cat-merge all R1, all R2
4. Store merged paths (STAR) + original dir/prefix (Cell Ranger)

## Scanpy Pipeline Modes

modes: qc, cluster, batch, annotate, advanced, de

- batch: BBKNN or Harmony (sc.external.pp.bbknn / sc.external.pp.harmony_integrate)
- annotate: marker-based (TSV with cell_type + markers) or celltypist
- advanced: trajectory (diffmap+dpt), velocity, communication, CNV (infercnvpy)
- CNV needs GTF for genomic positions + reference cell types
