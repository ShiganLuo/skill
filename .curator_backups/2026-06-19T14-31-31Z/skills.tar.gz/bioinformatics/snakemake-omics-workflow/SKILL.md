---
name: snakemake-omics-workflow
description: Add new modules, subworkflows, and pipelines to the Omics Snakemake project — including porting from Nextflow
---

# When to use

- User asks to implement a new workflow/pipeline in the Omics Snakemake project
- User asks to port a Nextflow (nf-core) pipeline to Snakemake
- User asks to add a new tool module to `workflow/Omics/modules/`
- User asks to create a new subworkflow in `workflow/Omics/subworkflow/`

# Prerequisites — read these first

Before writing any code, load and read these project files:

1. **`SKILL.md`** (in project root, e.g. `workflow/Omics/SKILL.md`) — project overview, run.py responsibilities, extension checklist. **ALWAYS read this first** — it's the project owner's source of truth.
2. `subworkflow/subworkflow.md` — subworkflow conventions (module + use rule pattern, config dict naming)
3. `modules/modules.md` — module conventions (3-file structure, config dict, rule naming)

These are project-local markdown files, not Hermes skills. Read them with `read_file`.

# Extension checklist (from skill.md)

When adding a new workflow:

1. Add model template JSON in `config/<WorkflowName>.json`
2. Add `run<Workflow>()` function in `run.py`
3. Add workflow name to `--workflow_name` choices in `parse_args()`
4. Add entry to `WORKFLOW_DISPATCH` dict in `__main__` block
5. Create subworkflow snakefile in `subworkflow/<WorkflowName>.smk`
6. Create required modules in `modules/<tool>/`
7. Update `README.md` (main) — add workflow to supported table AND verify ALL existing workflows are documented (scan `subworkflow/*.smk`)
8. Update `subworkflow/README.md` — add workflow description AND verify ALL existing workflows have descriptions

# Module directory layouts

Three patterns exist in the codebase (see `modules/modules.md` for full spec):

## A. Simple 3-file (most common)
```
modules/<tool>/
  <tool>.smk    # rules
  <tool>.json   # config template
  <tool>.yaml   # conda env
```
Examples: samtools, fastqc, deepvariant, hiphase, pbsv, tabix

## B. 3-file + bin/ (custom scripts)
```
modules/<tool>/
  <tool>.smk / .json / .yaml
  bin/
    summarize.py
    plot.py
```
Examples: StringTie, arriba, spectrum, RmrRNA, track

Scripts referenced via `ROOT_DIR + "/modules/<tool>/bin/<script>.py"`.

## C. Parent + subdirectories (shared conda env)
```
modules/<tool>/
  <tool>.yaml               # shared conda
  <tool>.smk                # main/prepare rules
  <tool>.json
  <subtool>/
    <subtool>.smk            # conda: "../<tool>.yaml"
    <subtool>.json
```
Examples: gatk (prepare + bqsr/ + germline/ + somatic/), samtools (+ sort/)

# Three run/shell styles

## Style 1: Pure `shell:` block (simple commands)

```python
rule bam_flagstat:
    input:
        bam = indir + "/{sample_id}/{sample_id}.bam"
    output:
        flagstat = outdir + "/{sample_id}/{sample_id}_flagstat.txt"
    log:
        logdir + "/{sample_id}/flagstat.log"
    conda: "samtools.yaml"
    params:
        samtools = config.get("Procedure", {}).get("samtools") or "samtools"
    shell:
        "{params.samtools} flagstat {input.bam} > {output.flagstat}"
```

## Style 2: `run:` block + shell script generation (complex commands)

For tools with dynamic args, conditional flags, pipes, or multi-step sequences:

```python
rule pbsv_call:
    input:
        svsig = outdir + "/discover/{sample_id}/{sample_id}.svsig.gz",
        fasta = fasta
    output:
        vcf = outdir + "/call/{sample_id}/{sample_id}.vcf"
    log:
        logdir + "/{sample_id}/pbsv_call.log"
    threads: 8
    conda: "pbsv.yaml"
    params:
        pbsv = config.get("Procedure", {}).get("pbsv") or "pbsv"
    run:
        current_time = time.strftime("%Y%m%d_%H%M%S", time.localtime())
        logger.info(f"Start pbsv call for sample {wildcards.sample_id} at {current_time}")
        script = os.path.join(outdir, f"pbsv_call_{current_time}.sh")
        cmd = [params.pbsv, "call", "--num-threads", str(threads), input.fasta, input.svsig, output.vcf]
        with open(script, "w") as f:
            f.write("#!/bin/bash\n")
            f.write(" ".join(cmd) + "\n")
        shell("bash {script} > {log} 2>&1")
```

Multi-command variant (align + index):
```python
run:
    script = f"..."
    cmd1 = [params.STAR, ..., "--outSAMtype", "BAM SortedByCoordinate", ...]
    cmd2 = ["mv", f"{prefix}Aligned.sortedByCoord.out.bam", output.bam]
    cmd3 = [params.samtools, "index", "-@", str(threads), output.bam]
    with open(script, "w") as f:
        for cmd in [cmd1, cmd2, cmd3]:
            f.write(" ".join(cmd) + "\n")
    shell(f"bash {script} > {log} 2>&1")
```

## Style 3: `run:` block + direct Python logic

For rules needing pandas, JSON, file aggregation:
```python
run:
    # Prepare mapping files with Python
    with open(map_file, "w") as f:
        for k, v in mapping.items():
            f.write(f"{k}\t{v}\n")
    # Then call shell
    shell("python {params.script} -i {map_file} -o {output} > {log} 2>&1")
```

# Dynamic input functions

Alignment modules need paired/single dispatch:
```python
def get_alignment_input(wildcards):
    paired_r1 = f"{indir}/{wildcards.sample_id}/{wildcards.sample_id}_1.fq.gz"
    paired_r2 = f"{indir}/{wildcards.sample_id}/{wildcards.sample_id}_2.fq.gz"
    single = f"{indir}/{wildcards.sample_id}/{wildcards.sample_id}.single.fq.gz"
    if wildcards.sample_id in paired_samples:
        return [paired_r1, paired_r2]
    elif wildcards.sample_id in single_samples:
        return [single]
    raise ValueError(f"Sample {wildcards.sample_id} not defined")
```

Index fallback (prefer config-provided index, else module-generated):
```python
def get_index(wildcards):
    cfg_prefix = config.get('genome', {}).get('index_prefix')
    if cfg_prefix and os.path.exists(f"{cfg_prefix}.1.bt2"):
        return [f"{cfg_prefix}.{ext}" for ext in SUFFIXES]
    return [f"{outdir}/index/genome.{ext}" for ext in SUFFIXES]
```

# Result rules (_result)

Each module should have a `<tool>_result` rule — input-only aggregation point for subworkflow `use rule`:

```python
rule deepvariant_result:
    input:
        vcf = outdir + "/{sample_id}/{sample_id}.vcf.gz",
        tbi = outdir + "/{sample_id}/{sample_id}.vcf.gz.tbi"
```

# Config key patterns

| Key | When to use |
|---|---|
| `samples` | Single sample list (most modules) |
| `paired_samples` / `single_samples` | Alignment modules |
| `sample_groups` | Grouping (StringTie) |
| `sample_somatic_vcf_dict` / `sample_group_dict` | Spectrum-style cohort analysis |
| `bam_dir` / `vcf_dir` | Separate input locations (hiphase) |
| `ROOT_DIR` | Custom script references (bin/) |
| `Procedure` | Tool executable paths |
| `Params` | Tool-specific parameters |
| `genome` | Reference file paths |

# Module .json template (standard)

```json
{
    "indir": "input",
    "outdir": "output",
    "logdir": "logs",
    "samples": [],
    "Procedure": { "<tool>": null },
    "Params": { "<tool>": {} },
    "genome": { "fasta": null }
}
```

# Module .yaml template

```yaml
name: <tool>
channels:
  - conda-forge
  - bioconda
  - defaults
dependencies:
  - <tool>>=<version>
```

# Subworkflow pattern

```python
shell.prefix("set -x; set -e;")
from snakemake.logging import logger

indir = config.get("indir", "data/fastq")
outdir = config.get("outdir", "output")
logdir = config.get("logdir", "logs")
outfiles = config.get("outfiles", [])
samples = config.get("samples", [])

rule all:
    input:
        outfiles

# Module config dict — name: <module>_config
tool_config = {
    "indir": indir,
    "outdir": f"{outdir}/<tool>",
    "logdir": logdir,
    "samples": samples,
    "Procedure": {
        "<tool>": config.get("Procedure", {}).get("<tool>")
    },
    "genome": {
        "fasta": config.get("genome", {}).get("fasta")
    }
}
module <tool>:
    snakefile: "../modules/<tool>/<tool>.smk"
    config: <tool>_config
logger.info(f"<tool>_config: {<tool>_config}")
use rule <rule_name> from <tool> as <Workflow>_<rule_name>
```

Key conventions:
- Config dict named `<tool>_config`
- Rule aliasing: `use rule X from Y as <Workflow>_X`
- Conditional modules: wrap in `if not skip_<X>:` blocks — see `references/optional-module-pattern.md` for full pattern
- Chain outputs: module B's `indir` = module A's `outdir`
- `ROOT_DIR` must be passed to modules that use `bin/` scripts

# run.py integration

## run<Workflow>() function signature

```python
def run<Workflow>(
    datajson: Dict[str, Any],
    samples_info_dict: Dict[str, Any],
    indir: str,
    outdir: str,
):
```

Note: workflows without design pairs (like PacVar for PacBio) don't need `designPair` parameter. Only Mutation-style workflows need it.

## Inside run<Workflow>()

1. Set `datajson["ROOT_DIR"]`, `indir`, `outdir`, `logdir`
2. Build `outfiles` list by iterating `samples_info_dict`
3. Set `datajson["samples"]`, `datajson["outfiles"]`
4. Write `raw.json` to outdir

## Wiring into main block

```python
# In parse_args():
parser.add_argument('-w', '--workflow_name', type=str, nargs='+',
    choices=["...", "<Workflow>"], ...)

# WORKFLOW_DISPATCH mapping (replaces if/elif chain):
WORKFLOW_DISPATCH = {
    "<Workflow>": lambda cfg, sid, dp, indir, outdir: ("<Workflow>.smk", run<Workflow>(cfg, sid, indir, outdir)),
    ...
}

# In __main__:
smk, input_json = WORKFLOW_DISPATCH[wf_name](
    deepcopy(workflow_config), samples_info_dict, designPair, raw_fastq_dir, abs_outdir
)
```

# Nextflow-to-Snakemake porting pattern

When porting an nf-core Nextflow pipeline:

1. **Read the main workflow** (`workflows/<name>.nf`) to understand the DAG
2. **Read each subworkflow** (`subworkflows/local/*/main.nf`) for step sequences
3. **Map Nextflow operators to Snakemake**:
   - `process` → `rule` in a module .smk
   - `workflow` → subworkflow .smk
   - `Channel.join()` → Snakemake rule input dependencies
   - `Channel.combine()` → may need separate rules or config
   - `if (params.X)` → `if not config.get("Params", {}).get("skip_X")`
4. **Map Nextflow modules** (`modules/nf-core/*/main.nf`) → Snakemake modules
5. **Preserve the step order**: align → sort → index → call → phase → etc.

# Pitfalls

## 1. execute_code with Snakemake content

Do NOT use `execute_code` with triple-quoted strings containing Snakemake syntax — the shell backslash escapes and nested quotes cause SyntaxError. Use `write_file` tool directly for each file.

## 2. Patch insertion position

When inserting a new function before an existing one in run.py via `patch`, be precise about the context. A bad `old_string` match can corrupt the file. Always verify with `read_file` after patching, and compile-check with:
```bash
python -c "import py_compile; py_compile.compile('run.py', doraise=True)"
```

## 3. Module conda env path in subdirectories

Subdirectory rules must use `conda: "../<parent>.yaml"` (relative path to parent's yaml), not `"../modules/<tool>/<tool>.yaml"`.

## 4. Rule name conflicts

When importing the same module twice (e.g., hiphase for SNP and SV), use distinct aliases:
```python
module hiphase_snp:
    snakefile: "../modules/hiphase/hiphase.smk"
    config: hiphase_snp_config
module hiphase_sv:
    snakefile: "../modules/hiphase/hiphase.smk"
    config: hiphase_sv_config
use rule hiphase_phase from hiphase_snp as PacVar_hiphase_snp
use rule hiphase_phase from hiphase_sv as PacVar_hiphase_sv
```

## 5. outfiles path consistency

The `outfiles` in `run<Workflow>()` must exactly match the output paths in the rules. A mismatch causes Snakemake to fail silently or rebuild everything.

## 6. Aggregation report rules

When a module produces per-sample outputs that need a cross-sample summary, add an aggregation rule that collects all sample outputs and runs a summary script. The summary script should live in the module's `bin/` directory and accept explicit file paths (not directory scanning):

```python
rule <tool>_report:
    input:
        passed = expand(outdir + "/{sid}/{sid}_passed.tsv", sid=samples),
        discarded = expand(outdir + "/{sid}/{sid}_discarded.tsv", sid=samples),
    output:
        report = outdir + "/<tool>_report/per_sample_summary.tsv"
    params:
        script = os.path.join(ROOT_DIR, "modules/<tool>/bin/summarize.py")
    run:
        cmd = [
            "python", params.script,
            "-p", ",".join(input.passed),
            "-d", ",".join(input.discarded),
            "-o", outdir + "/<tool>_report",
        ]
        shell(" ".join(cmd) + " > {log} 2>&1")
```

Key points:
- The summary script uses `-p` (comma-separated passed files) and `-d` (discarded files), not `--indir`
- The script can ALSO support `--indir` as an alternative for standalone use (mutually exclusive argparse group)
- Output goes to a subdirectory (e.g. `<tool>_report/`) not a single flat file, since the script produces multiple outputs (TSV tables, HTML report, figures)
- The rule's `output` points to one representative file (e.g. `per_sample_summary.tsv`) for Snakemake dependency tracking

## 7. shell vs run style choice

- Simple single command → `shell:` block
- Dynamic args, conditional flags, pipes, multi-step → `run:` block generating a .sh script
- Python data processing needed → `run:` block with direct Python
- Don't inline multi-line shell strings in `run:` — generate a script file for debuggability

## 7b. Multi-word params in `" ".join(cmd)` — quote individually

When a parameter value contains spaces (e.g. Java JVM options, complex filter strings),
`" ".join(cmd)` will NOT preserve the grouping. The shell treats each space-separated
token independently, so the tool only receives the first word.

**Broken** — GATK only gets `-Xms20g`, the rest become separate shell commands:
```python
params.javaOptions = "-Xms20g -XX:GCTimeLimit=50 -XX:GCHeapFreeLimit=10"
cmd = [params.gatk, "--java-options", params.javaOptions, "HaplotypeCaller", ...]
# Generates: gatk --java-options -Xms20g -XX:GCTimeLimit=50 -XX:GCHeapFreeLimit=10 HaplotypeCaller
# Error: '-XX:GCTimeLimit=50' is not a valid command
```

**Fixed** — wrap the multi-word value in quotes so the shell keeps it as one token:
```python
cmd = [params.gatk, "--java-options", f'"{params.javaOptions}"', "HaplotypeCaller", ...]
# Generates: gatk --java-options "-Xms20g -XX:GCTimeLimit=50 -XX:GCHeapFreeLimit=10" HaplotypeCaller
```

**Pattern**: Any parameter whose value is a space-separated string of sub-arguments
needs `f'"{value}"'` wrapping when building cmd lists for `" ".join()`:
- `--java-options "Xms... Xmx... XX:..."` (GATK/Picard)
- `--filter-expression "FS > 20.0 && QD < 2.0"` (bcftools/GATK)
- `--add-args "--flag1 value1 --flag2 value2"` (tools wrapping other tools)

The error message `'-XX:GCTimeLimit=50' is not a valid command` is the telltale sign
of this bug — the JVM flag is being executed as a shell command.

## 8. run block script timestamp
## 8. run block script timestamp — NO SPACES in format
Use `current_time` to avoid parallel conflicts. **Format must not contain spaces or unquoted special characters** — the path is interpolated into `shell(f"bash {script} ...")` where spaces break tokenization:

```python
# CORRECT
current_time = time.strftime("%Y%m%d_%H%M%S", time.localtime())
script = f"{outdir}/{wildcards.sample_id}/tool_{current_time}.sh"

# BROKEN — space in path causes shell to split it into two arguments
current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
```

Symptom: `bash: .../tool_2026-06-14: No such file or directory` — bash sees the space and treats everything after it as a separate argument.

## 8b. Snakemake --rerun-triggers input requires metadata
When `--rerun-triggers input` is used, Snakemake compares input file content hashes against `.snakemake/metadata/`. If metadata is empty (first run, or `.snakemake/` was recreated), Snakemake has **no baseline** and re-runs ALL rules regardless of whether output files exist.

Key behaviors:
- Empty metadata + `--rerun-triggers input` = **all rules re-run** (touch has no effect)
- Empty metadata + default triggers (mtime) = timestamp comparison works, touch effective
- Dry-run does NOT write metadata — only actual execution does
- Missing declared output files (e.g. `.bai`) cause **cascading re-runs** of all downstream rules, even if other outputs exist
- `touch` on files without metadata makes Snakemake treat them as "updated" → cascades downstream

Debugging checklist when all rules re-run despite existing outputs:
1. Check `ls .snakemake/metadata/ | wc -l` — if 0, metadata is missing
2. Check `--rerun-triggers` — if `input` and metadata empty, that's the cause
3. Check every declared output of every rule exists (one missing `.bai` cascades everything)
4. Check `--reason` output for "Updated input files" or "Input files updated by another job" — traces the cascade chain

## 8c. conda yaml channel order
Channel order MUST be `conda-forge → bioconda → defaults`. bioconda depends on conda-forge packages; wrong order causes solver failures:
```yaml
channels:
  - conda-forge
  - bioconda
  - defaults
```

## 9. expand() wildcard escaping

Escape external wildcards with double braces `{{}}` inside `expand()`:
```python
expand(outdir + "/{case}/{case}.{{genome_version}}.msisensor", case=samples.index)
```

## 11. Read-only constraint on run.py

When user says "don't modify existing code, only add new files":
- Cannot add `run<Workflow>()` to run.py or wire into `__main__`
- Create standalone `run_<Workflow>.py` at project root instead
- Standalone script: loads config template, accepts CLI args, generates raw.json, calls snakemake
- See `references/karrseq-porting-case.md` for full example

## 12. STAR module doesn't output chimeric SAM

The existing `modules/star/star.smk` doesn't output `Chimeric.out.sam`. If a workflow needs chimeric output:
- Option A: Embed STAR rule directly in subworkflow with custom output (KARRseq approach)
- Option B: Modify star.smk to optionally output chimeric (requires existing code modification)
- Option C: Create a new `karrseq_star` module variant (if reuse across multiple workflows)

## 13. Renaming a workflow

When user asks to rename workflow X to Y, all of these must change:

1. **Files**: `mv subworkflow/X.smk subworkflow/Y.smk`, `mv config/X.json config/Y.json`
2. **Rule prefixes in subworkflow**: Replace all `X_` prefixes with `Y_` (use `replace_all=true` in patch)
3. **Function in run.py**: `runX()` → `runY()` (function name + docstring)
4. **parse_args choices**: Update the `choices=[...]` list
5. **__main__ elif block**: Update condition string, function call, smk filename
6. **README.md files**: Both main and subworkflow README

Common pitfall: forgetting to update rule prefixes inside the subworkflow .smk file. Search for the old prefix with `search_files` after renaming to catch any stragglers.

## 14. IP/Input sample mapping for peak calling workflows

For ChIP-seq / DIP-seq / any peak calling workflow, samples have a design attribute (`ip` or `input`). The `run<Workflow>()` function must:
- Separate `ip_samples` and `input_samples` from `samples_info_dict`
- Build `sample_ip_input_map: Dict[str, Optional[str]]` mapping each IP sample to its control Input
- Pass this map to the subworkflow config
- In the module's MACS3 rule, use `unpack()` to conditionally include control BAM

See `references/peak-calling-pattern.md` for full implementation example.

## 13. IP/Input control mapping for ChIP-seq/DIP-seq

For peak calling workflows, need `sample_ip_input_map` in config:
```json
{
    "ip_samples": ["IP_sample1", "IP_sample2"],
    "input_samples": ["Input_sample1"],
    "sample_ip_input_map": {
        "IP_sample1": "Input_sample1",
        "IP_sample2": "Input_sample1"
    }
}
```

runDIPseq() builds this mapping automatically from sample_info.design field.

## 14. Multi-genome subworkflow pattern

When workflow supports multiple genomes (e.g., mm + hg38), iterate over genomes in subworkflow:
```python
genomes = config.get("genomes", ["mm"])
for genome in genomes:
    bowtie2_config = {...}
    module bowtie2_align:
        snakefile: "../modules/bowtie2/bowtie2.smk"
        config: bowtie2_config
    use rule bowtie2_align_paired from bowtie2_align as DIPseq_bowtie2_align_paired
```

## 15. Comprehensive README documentation when adding workflows

When adding a new workflow, the README update checklist (items 7-8) is NOT just about the new workflow. You must:

1. **Scan subworkflow/ directory** for ALL .smk files: `ls subworkflow/*.smk`
2. **Compare against README.md table** — every .smk must appear in the supported workflows table
3. **Compare against subworkflow/README.md** — every .smk must have a description section
4. **Compare against run.py choices** — check if all .smk workflows are registered in `parse_args()`

Common mistake: only adding the new workflow to README while missing existing workflows (e.g., Mutation, PacVar, KARRseq, ncRNAseq, RNA_SNP were all missing from README.md table when PeakCalling was added).

```bash
# Quick check: list all subworkflows vs what's documented
ls subworkflow/*.smk | xargs -I{} basename {} .smk
# Then grep README.md for each name
```

## 16. Parallel execution of multiple subworkflows

`run.py -w WorkflowName` launches ONE snakemake process. To run multiple workflows
in parallel (e.g., PacVar + Mutation), each needs its own snakemake process with
**isolated `.snakemake/` directory**.

### Why `.snakemake/` isolation matters

Snakemake creates `.snakemake/` in the process cwd, containing:
- `locks/` — file-based locks keyed by output path
- `metadata/` — per-job metadata (files keyed by output path)
- `iocache/` — IO cache (SQLite, NOT safe for concurrent writes)
- `incomplete/` — incomplete job markers

Two processes sharing the same `.snakemake/` risks:
- SQLite write conflicts in iocache
- Metadata corruption if workflows have overlapping output paths
- Lock contention

### Implementation: `-w` accepts multiple workflows

`run.py` changes:
1. `-w` accepts `nargs='+'`: `parser.add_argument('-w', '--workflow_name', nargs='+', ...)`
2. Replace if/elif dispatch chain with `WORKFLOW_DISPATCH` mapping dict
3. Thread allocation: `threads_per_workflow = max(1, total_threads // n_workflows)`
   — user's `-t` is TOTAL threads, NOT per-workflow
4. Each workflow launches from its own `abs_outdir` as cwd

```python
WORKFLOW_DISPATCH = {
    "CoCulture":  lambda cfg, sid, dp, indir, outdir: ("CoCulture.smk", runCoCulture(cfg, sid, indir, outdir)),
    "PacVar":     lambda cfg, sid, dp, indir, outdir: ("PacVar.smk",    runPacVar(cfg, sid, indir, outdir)),
    "Mutation":   lambda cfg, sid, dp, indir, outdir: ("Mutation.smk",  runMutation(cfg, sid, dp, indir, outdir)),
    # ... etc
}

# In __main__:
workflow_names = args.workflow_name
n_workflows = len(workflow_names)
threads_per_workflow = max(1, args.threads // n_workflows)

smk_cmds = []
for wf_name in workflow_names:
    abs_outdir = os.path.abspath(os.path.join(args.output_dir, wf_name))
    os.makedirs(abs_outdir, exist_ok=True)
    smk, input_json = WORKFLOW_DISPATCH[wf_name](...)
    cmd = build_snakemake_cmd(ROOT_DIR, smk, input_json, threads_per_workflow, ...)
    smk_cmds.append((cmd, abs_outdir))

if n_workflows == 1:
    _run_cmd(smk_cmds[0][0], cwd=smk_cmds[0][1])
else:
    _run_cmds_parallel(smk_cmds)
```

`CmdUtil.py` changes:
- `_run_cmd(cmd, cwd=None)` — pass cwd to `subprocess.run`
- `_run_cmds_parallel(cmds)` — launches all via `subprocess.Popen`, waits, checks exit codes

### dry_run MUST flow through to snakemake

Do NOT short-circuit dry_run in run.py. The `--dry-run` flag is passed to snakemake
via `build_snakemake_cmd` — snakemake itself shows the execution plan. Always build
and execute the cmd, even in dry_run mode.

### Why NOT a Master.smk with `use rule *`

Snakemake's `module` + `use rule` does not support nesting: if PacVar.smk already
uses `module` + `use rule` to import pbmm2/samtools/etc., importing PacVar.smk
into a Master.smk via `use rule *` resolves the inner modules during parsing, but
the subworkflow's top-level variable assignments (`outdir = config.get(...)`) all
execute in the Master.smk context, causing variable name collisions across workflows.
Also, `conda:` relative paths resolve against the importing file, not the original.

## 17. Use established bioinformatics tools, don't reinvent

When the user (or prior discussion in the session) has identified an established
tool for a task (e.g., Telogator2 for telomere, RepeatMasker for centromere),
**wrap that tool in a Snakemake module** — do NOT write a custom Python script
reimplementing the same logic. Custom scripts are only for:
- Parsing/summarizing tool output (e.g., extracting stats from RepeatMasker `.out`)
- Visualization (plotting from tool TSV output)
- Glue logic between tools

If the user explicitly discussed and agreed on a tool earlier in the session,
honoring that decision is mandatory. Writing a regex-based reimplementation when
Telogator2 was already agreed upon is a waste of effort and produces inferior results.

## 18. Missing declared output files cause full cascade re-run

When a rule declares an output file that doesn't exist on disk, Snakemake MUST re-run
that rule. ALL downstream rules then get reason "input files updated by another job",
causing a full cascade re-run of the entire DAG — even if most other outputs exist.

**Debugging pattern**: When Snakemake dry-run shows all rules re-running, check the
UPSTREAM rules first. One missing output file at the top of the DAG cascades to everything.

**Example**: `pbmm2_align` declares `.sorted.bam` + `.sorted.bai` as outputs. If `.sorted.bai`
is missing (never created, or deleted), pbmm2_align must re-run → addReadsGroup input
"updated by another job" → MarkDuplicates → HaplotypeCaller → ... all 28 jobs re-run.

**Fix**: `samtools index -@ N input.bam output.bai` to create the missing index. Or `touch`
if only dry-run matters. But for actual execution, the index must be valid.

**Verification**: `find <outdir> -name "*.bai" -o -name "*.tbi" -o -name "*.csi" | wc -l`
Compare against expected count. Missing indices are the #1 cause of phantom cascade re-runs.

## 19. `--rerun-triggers input` with empty `.snakemake/metadata/`

The `--rerun-triggers input` flag tells Snakemake to re-run only when input file CONTENT
changes (hash-based). This requires `.snakemake/metadata/` to store baseline hashes from
the previous run. If metadata is empty (no previous run, or `.snakemake/` was recreated),
Snakemake has NO baseline to compare against → defaults to re-running ALL rules.

Changing to `--rerun-triggers mtime` (timestamp-based) doesn't help either — without metadata,
other triggers (`code`, `params`, `software-env`) also fail to compare and re-run.

**Root cause**: `.snakemake/metadata/` being empty. Common reasons:
- First run that errored before any rule completed (MissingInputException during DAG build)
- `.snakemake/` directory was deleted/recreated
- Workflow run from different working directory

**Fix**: Let one full run complete successfully — metadata is written per-rule as each rule
finishes. Subsequent runs will have the baseline for comparison.

## 20. BAI index naming: GATK vs samtools

GATK `--CREATE_INDEX true` creates `{name}.bai` (replaces `.bam` with `.bai`).
`samtools index file.bam` creates `{name}.bam.bai` (appends `.bai`).
`samtools index file.bam -o name.bai` creates the exact name specified.

When writing input functions that construct BAI paths, be explicit about which convention
the upstream rule uses:

```python
# If upstream uses GATK --CREATE_INDEX true:
in_dict["bai"] = f"{dir}/{sid}.{substring}.bai"

# If upstream uses samtools index (default):
in_dict["bai"] = f"{dir}/{sid}.{substring}.bam.bai"

# If upstream uses samtools index -o:
in_dict["bai"] = f"{dir}/{sid}.{substring}.bai"  # matches the -o name
```

## 21. Missing `use rule` for intermediate rules

When a module has multiple rules (e.g., `HaplotypeCaller` → `filterHaplotypeCallerVcf`),
**every rule that produces a file needed by another rule must be imported** via `use rule`.
Forgetting to import intermediate rules causes MissingInputException — Snakemake can't
find a rule in the DAG to produce the expected file.

**Checklist**: After importing a module, trace the dependency chain:
- Rule A produces `.raw.vcf.gz`
- Rule B takes `.raw.vcf.gz` and produces `.filtered.vcf.gz`
- Rule C (in another module) needs `.filtered.vcf.gz`
→ Both `use rule A` AND `use rule B` must be present in the subworkflow.

## 22. Stale file reads when debugging

When debugging file-existence issues, ALWAYS re-read files fresh. The `read_file` tool
may return cached content from earlier in the session. If the user says "you're being
confused by old cache" or "re-read the file", do it immediately — trust the user.

**Pattern**: When investigating MissingInputException:
1. `find <outdir> -type f | sort` — get ACTUAL files on disk (fresh)
2. `read_file <smk>` — re-read the rule file (may need fresh read)
3. Compare declared outputs vs actual files
4. Check timestamps: `stat -c '%y %n' <file>`

Do NOT rely on earlier `search_files` or `read_file` results when debugging — they may
be stale.

## 23. Conda htslib/bcftools dependency conflicts

When htslib or bcftools have version-pinned dependencies that cause cascading conflicts (libcurl → libnghttp2 → c-ares chain), the fix is to **remove explicit transitive dependencies**:

```yaml
# BROKEN — explicit htslib/bcftools pins conflict with pbsv's transitive deps
dependencies:
  - pbsv=2.11.0
  - htslib==1.23.1
  - bcftools==1.23.1

# FIXED — let pbsv pull compatible htslib/bcftools automatically
dependencies:
  - pbsv=2.11.0
```

Root cause: bioconda packages like htslib pin libcurl versions, which pin libnghttp2, which pin c-ares. When the solver can't find a consistent set across all pins, it fails. The main package (pbsv, samtools, etc.) already declares its own compatible transitive deps — adding explicit pins for them is redundant and causes conflicts.

If you need htslib/bcftools tools directly (e.g., `bcftools view`), add them in a SEPARATE conda env or use the main package's bundled versions.

## 24. Tool input format requirements (BAM vs FASTQ)

When wrapping a new tool, ALWAYS verify what input formats it actually accepts. Don't assume — check `--help` or usage output.

**Example — hifiasm 0.25.0**:
- Usage says `<in_1.fq> <in_2.fq> <...>` — expects FASTQ, NOT BAM
- Old versions (0.16-0.19) had `--hifi` flag; 0.25.0 removed it (positional args only)
- Passing a valid BAM file produces `counted 0 distinct minimizer k-mers` then malloc crash

**Pattern**: When a tool needs FASTQ but the pipeline has BAM, add a `samtools fastq` conversion step:
```python
# In the run block:
fq_gz = f"{outdir}/{sid}/assembly/{sid}.hifi.fq.gz"
cmd0 = ["samtools", "fastq", "-@", str(threads), input.bam, "|", "gzip", "-c", ">", fq_gz]
cmd1 = ["tool", "-o", prefix, "-t", str(threads), fq_gz]
cmd_cleanup = ["rm", "-f", fq_gz]
```

Also check tool version-specific flags — flags can be added/removed between major versions.

## 25. Unit testing Snakemake rules — test generated scripts directly

When debugging rule failures, don't re-run the entire Snakemake DAG. Each `run:` block
generates a `.sh` script in the output directory. Test it directly:

```bash
# Find the latest script
ls -lt output/<workflow>/<module>/tool_*.sh | head -1

# Run it directly (unit test)
bash output/<workflow>/<module>/tool_20260614_191530.sh

# Check the log
cat output/<workflow>/log/<sample_id>/<rule>.log
```

This isolates the failing rule from Snakemake's dependency tracking. Fix the script,
verify it works, then update the `.smk` code.

## 26. Conda environment symlink workaround for missing tools

When a conda environment is missing a tool (e.g., samtools) and `conda install` times out
on large environments, symlink from another environment:

```bash
ln -sf /path/to/other/env/bin/samtools /path/to/target/env/bin/samtools
```

This is a temporary workaround. The proper fix is to add the dependency to the `.yaml`
file and let Snakemake recreate the environment.

## 27. RepeatMasker DEFAULT_SEARCH_ENGINE must be configured

RepeatMasker requires `DEFAULT_SEARCH_ENGINE` to be set in `RepeatMaskerConfig.pm`.
If empty, it fails with: `Search engine ( ) is unknown to RepeatMasker`.

**Fix**: Find the config file and set it:
```bash
find /path/to/env -name "RepeatMaskerConfig.pm" -path "*/share/*"
sed -i "s/'value' => ''/'value' => 'rmblast'/" /path/to/RepeatMaskerConfig.pm
```

Available engines: `rmblast`, `nhmmer`, `crossmatch`, `abblast`.

## 29. Incomplete run block — cmd built but never executed

A `run:` block can construct a `cmd` list but forget to write the script and call `shell()`.
This typically happens when someone writes a comment/docstring placeholder for the shell
command and forgets to replace it with actual execution code. The rule silently does nothing,
producing empty log files and missing outputs.

**Symptoms**:
- Log file exists but is empty (0 bytes)
- Output files never created
- Snakemake reports rule failure with no stderr

**Example — broken** (from centromere.smk repeatmasker_run):
```python
run:
    script = os.path.join(outdir, f"{wildcards.sample_id}/repeatmasker_{current_time}.sh")
    cmd = [params.RepeatMasker, "-species", params.species, "-pa", str(threads), ...]
    """                           # <-- docstring, NOT executed!
    mkdir -p {params.rm_dir}
    RepeatMasker -species {params.species} ...
    """
```

**Fixed** — write script + execute:
```python
run:
    script = os.path.join(outdir, f"{wildcards.sample_id}/repeatmasker_{current_time}.sh")
    cmd = [params.RepeatMasker, "-species", params.species, "-pa", str(threads), ...]
    with open(script, "w") as f:
        f.write("#!/bin/bash\n")
        f.write(f"mkdir -p {params.rm_dir}\n")
        f.write(" ".join(cmd) + "\n")
    shell(f"bash {script} > {log} 2>&1")
```

**Checklist** — every `run:` block that builds a `cmd` list MUST end with:
1. `with open(script, "w") as f:` — write the script
2. `f.write("#!/bin/bash\n")` — shebang
3. `f.write(" ".join(cmd) + "\n")` — the command(s)
4. `shell(f"bash {script} > {log} 2>&1")` — execute it

If you see a triple-quoted string (`"""..."""`) inside a `run:` block after `cmd` construction,
it's almost certainly a bug — that's a docstring being silently evaluated and discarded.

## 28. RepeatMasker -species must be scientific name or NCBI taxon ID

RepeatMasker's `-species` flag does NOT reliably accept common names. `"mouse"` is ambiguous
(33 matches in Dfam) and RepeatMasker exits with code 255:

```
Ambiguous search term 'mouse' (found 33 results, 2 exact).
Taxon "mouse" is not defined in the current FamDB partitions present.
```

**Fix**: Use the NCBI scientific name or taxonomy ID:
- `"Mus musculus"` (exact match, taxon 10090)
- `"Homo sapiens"` (exact match, taxon 9606)
- Or just the numeric taxon ID: `"10090"`, `"9606"`

**Always verify** with `famdb.py names "<species>"` before hardcoding:
```bash
# Using the conda env's Python (h5py required)
<env>/bin/python3 <env>/share/RepeatMasker/famdb.py \
  -i <env>/share/RepeatMasker/Libraries/famdb names "Mus musculus"
```

**Pitfall**: The default in `modules/centromere/centromere.smk` line 10 is:
```python
rm_species = config.get("Params", {}).get("RepeatMasker", {}).get("species", "mouse")
```
This default `"mouse"` will fail. Config must override with `"Mus musculus"` or the default
should be changed. Always check what the module default is — if it's a common name, override
in the workflow config JSON.

**Dfam completeness**: Conda-installed RepeatMasker bundles a condensed Dfam (e.g. Dfam 3.9
with 237 families). This is enough for species-level classification via taxon filtering,
but the full Dfam database (2000+ families) gives better coverage. If RepeatMasker reports
too few hits, consider downloading the full Dfam database.

## 29. telogator2 API — short flags only

telogator2 uses short flags, not long flags:
- `-i` for input (not `--reads`)
- `-o` for output directory (not `--output`)
- `-r hifi` for read type (not `--threads`)
- `-c` for threads (not `--threads`)

Also: telogator2 needs an aligner (minimap2 by default) in PATH.

# References
- `references/debugging-snakemake-source.md` — Debug Snakemake framework source itself (pdb, IDE, key entry points)
- `references/pacvar-nextflow-port-example.md` — PacVar porting case study
- `references/karrseq-porting-case.md` — KARRseq porting case study
- `references/dipseq-chipseq-case.md` — DIP-seq/ChIP-seq workflow with MACS3 peak calling
- `references/peak-calling-pattern.md` — IP/Input control mapping, MACS3 unpack() pattern
- `references/optional-module-pattern.md` — Conditional modules with skip flags (fragment_size example)
- `references/pacbio-repeats-module-case.md` — PacBio telomere/centromere module (raw BAM input, k-mer density, terminal classification)
- `references/snakemake-debugging-patterns.md` — MissingInputException diagnosis, cascade re-run, index naming, `--rerun-triggers` behavior

# Templates
- `templates/run_workflow_standalone.py` — Standalone run script for read-only run.py
- `templates/macs3_peak_calling.smk` — MACS3 module with IP/Input control support
