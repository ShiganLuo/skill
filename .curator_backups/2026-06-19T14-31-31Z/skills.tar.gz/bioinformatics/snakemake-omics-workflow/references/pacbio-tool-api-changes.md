# Tool API Changes — PacBio Assembly Tools

## hifiasm 0.25.0

**Removed flags**: `--hifi` (use positional args)

**Input format**: Expects FASTQ, NOT BAM. Passing BAM produces `counted 0 distinct minimizer k-mers` then crash.

**Correct usage**:
```bash
hifiasm -o prefix -t 48 input.fq.gz
```

**Conversion step** (BAM → FASTQ):
```bash
samtools fastq -@ 8 input.bam | gzip -c > input.fq.gz
hifiasm -o prefix -t 48 input.fq.gz
rm -f input.fq.gz
```

## telogator2

**Flags** (short only):
- `-i` — input reads (fa/fa.gz/fq/fq.gz/bam)
- `-o` — output directory
- `-r hifi` — read type (hifi/ont)
- `-c` — threads

**Dependencies**: minimap2 must be in PATH

**Correct usage**:
```bash
telogator2 -i input.bam -o output/ -r hifi -c 16
```

## RepeatMasker 4.1.0

**Configuration**: `DEFAULT_SEARCH_ENGINE` must be set in `RepeatMaskerConfig.pm`

**Available engines**: rmblast, nhmmer, crossmatch, abblast

**Fix**:
```bash
find /path/to/env -name "RepeatMaskerConfig.pm" -path "*/share/*"
sed -i "s/'value' => ''/'value' => 'rmblast'/" /path/to/RepeatMaskerConfig.pm
```
