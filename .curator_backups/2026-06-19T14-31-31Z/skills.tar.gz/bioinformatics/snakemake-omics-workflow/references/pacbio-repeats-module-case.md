# Case: PacBio Telomere & Centromere Module

## Context

Adding telomere length and centromere satellite DNA analysis to the PacVar workflow.
Unlike other PacVar modules (which operate on aligned/sorted BAMs), these modules
read directly from the **raw PacBio HiFi BAM** (unaligned CCS reads).

## Module Structure (corrected)

**Use established tools, not custom scripts.** The final module uses Telogator2
for telomere and RepeatMasker for centromere, with custom scripts only for
RepeatMasker output parsing.

```
modules/telomere/
  telomere.smk          # 5 rules: telomere_run, centromere_assemble, centromere_run, centromere_extract, *_result
  telomere.yaml         # conda: telogator2
  centromere.yaml       # conda: repeatmasker + hifiasm
  telomere.json         # Params.telomere + Params.centromere
  bin/
    extract_centromere_stats.py  # Parses RepeatMasker .out → satellite stats
```

## Key Design Decisions

### 1. Raw BAM input (not aligned BAM)

Telomere/centromere analysis needs **raw sequences** — aligned BAM has the read
mapped to a reference, which may clip or distort repeat regions. The module reads
from `indir` (the original PacBio BAM), not from `samtools_sort_config["outdir"]`.

```python
# PacVar.smk — telomere_config uses indir, not sorted BAM dir
telomere_config = {
    "indir": indir,  # raw PacBio BAM
    ...
}
```

### 2. Use established tools

**Telomere:** Telogator2 (seed-extend matching, per-chromosome-arm output)
**Centromere:** hifiasm assembly → RepeatMasker (-species mouse)

Custom scripts are only used for parsing RepeatMasker `.out` output into
human-readable statistics. Do NOT reimplement telomere/satellite detection
when established tools exist.

### 3. Terminal vs internal telomere classification

Reads from chromosome ends have telomeric repeats (TTAGGG)n at their **termini**.
Reads from internal genomic regions may contain ITS (interstitial telomeric sequences)
in the middle. Classification:

- `start < terminal_flank` (default 500bp) → "5prime" (true telomere)
- `end > read_len - terminal_flank` → "3prime" (true telomere)
- Otherwise → "internal" (ITS, excluded from length stats)

Only 5'/3' hits with `>= min_terminal_tel` (default 1000bp) count as true telomeres.
100bp is too low — produces false positives from subtelomeric noise.

### 4. Centromere requires assembly

Mouse centromere MaSat/MiSat span Mb-scale regions. HiFi reads (~15-20kb N50)
cannot span them. The module runs hifiasm assembly first, then RepeatMasker
on the assembly contigs.

### 4. Species-specific config — MUST use scientific name

Centromere species is set in config: `Params.repeatmasker.species`.
RepeatMasker uses this via `-species` flag. **Common names like "mouse" are ambiguous
and will fail** (RepeatMasker exits 255). Use the scientific name or NCBI taxon ID:

```json
"repeatmasker": { "species": "Mus musculus" }
```

Or numeric: `"species": "10090"`. Verify with `famdb.py names "Mus musculus"`.

The default in `centromere.smk` is `"mouse"` — always override in the workflow config.

## run.py Integration

```python
# In runPacVar():
skip_telomere = datajson.get("Params", {}).get("skip_telomere", False)
if not skip_telomere:
    for sample_id in samples:
        outfiles.append(f"{outdir}/repeat/telomere/{sample_id}/{sample_id}_telomere_stats.txt")
        outfiles.append(f"{outdir}/repeat/centromere/{sample_id}/{sample_id}_centromere_stats.txt")
```

## PacVar.smk Integration

```python
skip_telomere = config.get("Params", {}).get("skip_telomere", False)

if not skip_telomere:
    telomere_config = {
        "indir": indir,  # raw BAM, not aligned
        "outdir": f"{outdir}/repeat",
        "logdir": logdir,
        "samples": samples,
        "ROOT_DIR": config.get("ROOT_DIR", "."),
        "Params": {
            "telomere": config.get("Params", {}).get("telomere", {}),
            "centromere": config.get("Params", {}).get("centromere", {})
        },
        ...
    }
    module telomere:
        snakefile: "../modules/telomere/telomere.smk"
        config: telomere_config
    use rule telomere_run from telomere as PacVar_telomere_run
    use rule centromere_run from telomere as PacVar_centromere_run
```

## Pitfalls

### 1. Don't use aligned BAM for repeat analysis

Aligned reads may have soft-clipped telomeric repeats or mapping artifacts.
Always use the original unaligned BAM for repeat content analysis.

### 2. Length filter is critical for telomere calls

Without the `min_terminal_tel` filter (>=1000bp), subtelomeric scattered repeats
and ITS fragments at read ends produce false positives. Mouse telomeres are
30-150kb (129/Ola strain), so 1000bp is conservative.

### 3. Centromere requires assembly first

Mouse centromere MaSat/MiSat span Mb-scale regions. HiFi reads (~15-20kb N50)
cannot span them. The module runs hifiasm assembly first, then RepeatMasker
on the assembly contigs. This adds significant compute time — the assembly
step uses 48 threads by default.

### 4. Pyright pysam import warning

When editing `bin/*.py` scripts in the IDE, Pyright reports `Import "pysam" could
not be resolved` because pysam is in the conda env, not the system Python. This
is harmless — the scripts run correctly inside `conda activate` or via Snakemake's
`--use-conda`.

### 5. hifiasm 0.25.0 needs FASTQ, not BAM

hifiasm 0.25.0 removed the `--hifi` flag (input is now positional args only) and
does NOT properly read BAM files — it produces `counted 0 distinct minimizer k-mers`
then crashes with malloc assertion failure.

**Fix**: Convert BAM to FASTQ with `samtools fastq` before passing to hifiasm:
```python
cmd0 = ["samtools", "fastq", "-@", str(threads), input.bam, "|", "gzip", "-c", ">", fq_gz]
cmd1 = ["hifiasm", "-o", params.prefix, "-t", str(threads), fq_gz]
cmd_cleanup = ["rm", "-f", fq_gz]
```

The intermediate `.fq.gz` is large — clean it up after hifiasm finishes.

### 7. RepeatMasker -species "mouse" fails — use "Mus musculus"

RepeatMasker 4.2.3 + Dfam 3.9 cannot resolve the common name "mouse":
```
Ambiguous search term 'mouse' (found 33 results, 2 exact).
Taxon "mouse" is not defined in the current FamDB partitions present.
```
Exit code 255. The log file and RepeatMasker output are both empty.

**Fix**: `"species": "Mus musculus"` (taxon 10090) in the workflow config JSON.
The module default `"mouse"` in `centromere.smk` line 10 must be overridden.

**Debugging path**: When repeatmasker.log is empty and `.sh` script exists but
RepeatMasker produced no output → check the species parameter first. The
command exits immediately (8 seconds for a 2.6GB input) when species is unresolvable.

### 6. centromere_config must use raw BAM indir

The centromere module's `indir` must point to the raw HiFi reads directory, NOT
the aligned/deduplicated BAM directory (`gatk_prepare_config["outdir"]`). Also
remove `bam_substring` since raw reads are just `{sample_id}.bam`.

```python
centromere_config = {
    "indir": indir,  # raw HiFi BAM, NOT gatk_prepare outdir
    # no bam_substring — raw reads have no substring
    ...
}
```
