# Debugging Snakemake Source Code

When the project includes a local Snakemake source clone (e.g. `workflow/snakemake/`), you can debug the framework itself — not just your workflows.

## Setup: Editable Install

```bash
cd workflow/snakemake
pip install -e .   # editable mode — changes to src/snakemake/ take effect immediately
```

This allows setting breakpoints and modifying Snakemake internals without reinstalling.

## pdb/ipdb Breakpoints

Insert at the point you want to inspect:

```python
import pdb; pdb.set_trace()    # stdlib
import ipdb; ipdb.set_trace()   # friendlier (pip install ipdb)
```

Then run snakemake normally — execution pauses at the breakpoint.

**Common pdb commands:**
- `n` next line, `s` step into, `c` continue
- `p var` print variable, `bt` call stack, `l` show code location

## Key Source Entry Points

| Problem Area | File | Function/Location |
|---|---|---|
| Rule parsing | `rules.py` | `Rule.__init__` |
| DAG construction | `dag.py` | `DAG.init` |
| Job scheduling | `scheduling/job_scheduler.py` | `JobScheduler.schedule` |
| Execution | `executor/` | per-executor `run` method |
| Wildcard expansion | `wildcards.py` | wildcard resolution logic |
| Shell commands | `shell.py` | `shell.exec_job` |
| Workflow loading | `workflow.py` | `Workflow.__init__` |

## VS Code / PyCharm Debugging

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Debug Snakemake",
            "type": "debugpy",
            "request": "launch",
            "module": "snakemake",
            "args": [
                "--snakefile", "${workspaceFolder}/your_workflow.smk",
                "--configfile", "raw.json",
                "--cores", "4"
            ],
            "cwd": "${workspaceFolder}"
        }
    ]
}
```

## Quick Diagnostic Commands (no source edit needed)

```bash
# Dry-run with execution reasons
snakemake --snakefile xxx.smk --configfile raw.json --cores 1 -n -r

# DAG visualization
snakemake --snakefile xxx.smk --configfile raw.json --cores 1 --dag | dot -Tpng > dag.png
```

## Pitfall: Version Mismatch

If you edit the local source but `snakemake --version` still shows the old version, the editable install may not be active in the current conda env. Verify with:

```bash
python -c "import snakemake; print(snakemake.__file__)"
```

The path should point to `workflow/snakemake/src/snakemake/`, not a site-packages directory.
