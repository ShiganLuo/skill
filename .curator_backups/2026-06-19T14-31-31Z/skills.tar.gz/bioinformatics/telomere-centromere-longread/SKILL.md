---
name: telomere-centromere-longread
description: Analyze telomere and centromere length from PacBio HiFi / ONT long-read BAM/FASTQ. Species-aware (mouse MaSat/MiSat, human alpha-satellite). Use when measuring repetitive chromosomal regions from long-read sequencing data.
tags: [pacbio, hifi, telomere, centromere, long-read, repeat, satellite, bam, mouse, human]
---

# Telomere & Centromere Analysis from Long-Read Data

## When to Use

- User has PacBio HiFi or ONT data and wants to measure telomere or centromere lengths
- User asks about repetitive region characterization (telomere, centromere, satellite DNA)
- Species is specified (motif sequences differ)

## Tool Selection Rule

**Always prefer established community tools over custom scripts.** Custom regex/k-mer
scripts are fallbacks for when standard tools are unavailable. Established tools have
been validated against known datasets and handle edge cases better.

| Task | Preferred Tool | Fallback |
|------|---------------|----------|
| Telomere length from reads | **Telogator2** (seed-extend, per-chromosome-arm) | pysam + regex scan |
| Telomere from assembly | **tidk** (scan contig ends) | regex on FASTA |
| Centromere annotation | **RepeatMasker** (-species <taxon>) | k-mer density scan |
| Centromere assembly | **hifiasm** (HiFi) or **verkko** (HiFi + ONT UL) | — |

## Quick Decision Tree

```
Telomere?
  ├─ Have HiFi/ONT BAM → Telogator2 (preferred) or pysam direct analysis
  ├─ Have FASTQ → tidk or telogator2
  └─ Have assembly → tidk scan contig ends

Centromere?
  ├─ Have assembly → RepeatMasker (-species <taxon>)
  ├─ Have reads only → hifiasm assembly → RepeatMasker (2-step)
  └─ Need full centromere span → hifiasm/verkko assembly required (ONT UL helps)
```

## Prerequisites Check

Before starting, verify environment:

```bash
source /data/pub/zhousha/miniforge3/etc/profile.d/conda.sh
conda activate DNA
# Required: pysam, biopython, numpy
python -c "import pysam; import numpy; print('OK')"
```

If missing: `pip install pysam biopython numpy` (user preference: no auto-install, wrap in try/except).

For assembly-level analysis additionally need: `hifiasm`, `minimap2`, `samtools`, `RepeatMasker`, `bedtools`.

## Step 1: Telomere Analysis

### Motif Definitions

| Species | Telomere Motif | Notes |
|---------|---------------|-------|
| Mouse   | (TTAGGG)n     | Same as human, but much longer (30-150kb depending on strain) |
| Human   | (TTAGGG)n     | Typically 5-15kb |

**Mouse strain differences matter:**
- CAST/EiJ: ~150kb telomeres
- 129/Ola (E14 cells): long telomeres (~50-100kb)
- C57BL/6J: shorter (~30-50kb)

### Approach A: Telogator2 (Preferred)

```bash
conda install -c bioconda telogator2

telogator2 --reads input.bam \
           --output results/ \
           --threads 48
```

Outputs per-chromosome-arm telomere lengths. Seed-extend matching tolerates
HiFi errors better than pure regex.

### Approach B: Direct BAM Analysis (Fallback)

When Telogator2 is unavailable, use pysam direct analysis.

Script: `scripts/analyze_telomere.py`

```bash
conda activate DNA
python scripts/analyze_telomere.py \
  --bam input.bam \
  --sample_name SAMPLE \
  --output_dir results/ \
  --min_read_length 5000
```

**Key design decisions in the script:**
- Use `pysam.AlignmentFile(bam, "rb", check_sq=False)` — avoids index requirement
- Cluster nearby telomeric hits (within 30bp gap) to handle HiFi errors
- Classify hits by position: 5prime (<500bp from start), 3prime (>500bp from end), internal
- **Terminal telomere threshold must be >=1000bp** for mouse (not 100bp — too many false positives from subtelomeric noise and ITS)
- Output: per-read TSV, per-hit TSV, statistical summary

### Approach B: tidk (from FASTQ)

```bash
conda install -c bioconda tidk
tidk search -s TTAGGG -o output_dir input.fastq.gz
tidk count -o output_dir input.fastq.gz
```

### Approach C: Assembly-level

```bash
tidk search -s TTAGGG -o asm_tel assembly.fasta
```

Check which contigs/scaffolds have telomeric repeats at their termini (= potential chromosome ends).

## Step 2: Centromere Analysis

### Motif Definitions

| Species | Centromere Type | Repeat Unit | Location |
|---------|----------------|-------------|----------|
| Mouse   | Major Satellite (MaSat) | ~234bp | Pericentromeric heterochromatin |
| Mouse   | Minor Satellite (MiSat) | ~120bp | Centromeric core |
| Human   | Alpha-satellite | ~171bp | Centromeric |

**Mouse centromeres can span several Mb** — HiFi reads (~15-20kb N50) cannot span them. Assembly required.

### Approach A: RepeatMasker on Assembly (Standard)

```bash
# Assembly first
hifiasm -o asm -t 48 --hifi reads.fastq.gz
awk '/^S/{print ">"$2; print $3}' asm.bp.p_ctg.gfa > asm.fasta

# Annotate
RepeatMasker -species mouse -pa 48 -dir rm_output -gff asm.fasta

# Extract satellite lengths
grep "MSAT\|Satellite" rm_output/asm.fasta.out | \
  awk '{sum += ($7-$6)} END {print "Satellite total:", sum}'
```

### Approach B: Read-level Satellite Scan (Fallback)

When RepeatMasker is unavailable, scan reads for satellite k-mers.

Mouse Major Satellite consensus (simplified):
```
GAAAAACCTCGAGAATGGCGAGAAACTGAGAAGCCCGCAACGAATGGGATG...
```
Key feature: GA-rich strand, long runs of "AATGGAATGG" repeats.

Mouse Minor Satellite consensus:
```
GAAAATGATAAAAACCACACTGTATGGAAATGACATTTATAATATCATAT...
```

### Approach C: Use Existing T2T Reference

C57BL/6J has a T2T reference at NCBI. Map reads to it and extract centromeric region coverage.

## Pitfalls

1. **BAM index not required** — use `check_sq=False` in pysam. Many PacBio BAMs lack BAI.
2. **HiFi quality is high but not perfect** — telomeric motif matching needs gap tolerance. Pure regex misses reads with 1-2 mismatches in repeat.
3. **Mouse telomeres are VERY long** — standard human-centric thresholds (e.g., >100bp) produce many false positives from subtelomeric noise. Use >=1000bp for mouse.
4. **Terminal threshold is critical** — a TTAGGG repeat at a read end is NOT necessarily a true telomere. Could be subtelomeric scattered repeats or ITS near a random break point. Length >1000bp filters these out. For mouse E14 (129/Ola), true telomeres are typically 30-150kb.
5. **Centromere assembly collapse** — highly repetitive satellite DNA collapses in short contigs. Need high coverage + long reads. ONT ultra-long (>100kb) + HiFi is best.
6. **Species matters for RepeatMasker** — always specify `-species mouse` (not human). Wrong species gives wrong satellite annotations.
7. **E14 is 129/Ola, not C57BL/6J** — telomere length differs significantly between strains.
8. **BAM conversion to FASTQ is slow for 100GB files** — prefer direct pysam access or Telogator2's native BAM support to avoid the conversion step.
9. **User preference: use established tools** — when user asks to analyze telomere/centromere, check for existing tools (Telogator2, tidk, RepeatMasker) before writing custom scripts. Custom scripts are fallbacks, not first choice.

## Verification

After telomere analysis:
- Check that `*_telomere_stats.txt` shows reasonable numbers (mouse: median terminal telomere >5kb)
- Verify reads with telomere hits exist in `*_telomere_reads.tsv`
- Confirm 5' and 3' distributions are roughly symmetric

After centromere analysis:
- Satellite DNA should be 3-6% of mouse genome assembly
- MaSat should be more abundant than MiSat
- Check that satellite annotations are on expected chromosomes
