# Unit Testing Snakemake Rules

## Principle

Each `run:` block generates a `.sh` script in the output directory. Test it directly
instead of re-running the entire Snakemake DAG.

## Finding scripts

```bash
# List all generated scripts for a module
ls -lt output/PacVar/repeat/centromere/hifiasm_*.sh | head -5
ls -lt output/PacVar/repeat/telomere/telogator2_*.sh | head -5
```

## Testing workflow

1. Find the latest script: `ls -lt output/**/tool_*.sh | head -1`
2. Run it: `bash output/PacVar/repeat/centromere/hifiasm_20260614_191530.sh`
3. Check the log: `cat output/PacVar/log/DMSO_P20/hifiasm.log`
4. Fix the script, verify it works
5. Update the `.smk` code to match

## Example: testing hifiasm

```bash
# Check script content
cat output/PacVar/repeat/centromere/hifiasm_20260614_191530.sh

# Run it
bash output/PacVar/repeat/centromere/hifiasm_20260614_191530.sh

# Check output
ls -lh output/PacVar/repeat/centromere/DMSO_P20/assembly/asm.bp.p_ctg.fa
```

## Example: testing telogator2

```bash
# Run with correct PATH
export PATH=/path/to/telogator2/env/bin:$PATH
telogator2 -i input.bam -o output/ -r hifi -c 16

# Check progress
du -sh output/temp/
ls -la output/temp/05_final/results/
```

## When to use unit testing

- Rule fails with unclear error
- Tool produces unexpected output
- Debugging tool-specific issues (wrong flags, missing dependencies)
- Verifying fixes before re-running the full DAG
