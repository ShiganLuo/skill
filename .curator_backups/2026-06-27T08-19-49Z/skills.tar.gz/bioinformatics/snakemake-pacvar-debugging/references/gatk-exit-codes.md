# GATK Exit Code Decoding

## GATK Python wrapper exit code mechanism

GATK's launcher (`bin/gatk`) is a Python script using `subprocess.check_call()`.

```python
# From bin/gatk:
try:
    check_call(cmd, env=gatk_env)
except CalledProcessError as e:
    sys.exit(e.returncode)
```

When Java is killed by signal N, `e.returncode = -N`. Python's `sys.exit(-N)`
gets truncated to 8-bit unsigned: `exit_code = (-N) & 0xFF`.

## Exit code → signal mapping

| Exit code | Formula | Signal | Common cause |
|-----------|---------|--------|--------------|
| 137 | 128+9 | SIGKILL | OOM killer (most common) |
| 139 | 128+11 | SIGSEGV | Direct shell signal |
| 245 | 0xFF & -11 | SIGSEGV | Native crash in GATK wrapper path |
| 247 | 0xFF & -9 | SIGKILL | OOM kill via GATK wrapper path |
| 246 | 0xFF & -10 | SIGBUS | Memory bus error |
| 1 | | | GATK UserException (normal error, has message) |
| 3 | | | GATK wrapper: missing JAR or bad config |

## Why two exit code ranges?

- **128+N**: bash reports signal-killed processes as 128+signum (standard Unix)
- **0xFF & -N**: Python's `sys.exit(-N)` truncates to unsigned 8-bit

Which one you see depends on how the process is invoked:
- Direct shell: `bash script.sh` → 128+N
- Through GATK Python wrapper: `check_call()` → `sys.exit(-N)` → 0xFF & -N

## Silent death (no log output)

Signals SIGSEGV, SIGKILL, SIGBUS terminate the process immediately.
No user-space code runs — no buffer flush, no stderr write, no hs_err dump.

This is why `>> log 2>&1` doesn't help: the redirect is set up by the shell,
but the child process dies before writing anything after the last flush.

## Diagnostic checklist

1. Is exit code 245/247/246? → signal death, not a GATK error
2. Look for `hs_err_pid*.log` in working directory (JVM crash dump)
3. Check if native libraries are loaded (Intel GKL, AVX-512)
4. Try `--pair-hmm-implementation VECTOR_LOGLESS_CACHING` (Java fallback)
5. Try `--native-pair-hmm-threads 1` (reduce native parallelism)
6. Check `dmesg | grep -i oom` for OOM killer evidence
