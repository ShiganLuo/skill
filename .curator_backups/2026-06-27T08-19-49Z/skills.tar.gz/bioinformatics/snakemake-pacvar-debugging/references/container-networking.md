# Container Networking: Proxy, DNS, and Singularity/Apptainer

## Singularity image pull failures

### SOCKS5 proxy breaks Docker Hub pulls

**Error**: `socks connect tcp 127.0.0.1:1080->registry-1.docker.io:443: EOF`

**Fix**: Unset proxy environment variables before pulling:
```bash
env -u http_proxy -u https_proxy -u all_proxy \
    -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY \
    singularity pull docker://google/deepvariant:latest
```

### DNS resolution failure after unsetting proxy

**Error**: `dial tcp: lookup registry-1.docker.io on 127.0.0.53:53: server misbehaving`

**Root cause**: Network requires proxy to reach external hosts, but the SOCKS5 proxy (127.0.0.1:1080) doesn't work for HTTPS registry connections. Unsetting proxy leaves no route to the internet.

**Workarounds**:
1. Use a different proxy type (HTTP/HTTPS proxy instead of SOCKS5)
2. Pull from a mirror registry accessible without proxy
3. Pull on a machine with proper network access, then transfer the `.sif` file
4. Use `--library` flag to point Singularity to an accessible library server

## DeepVariant is container-only

The bioconda `deepvariant` package is a stub. The actual tool requires a container:
```bash
# Docker
docker pull google/deepvariant:1.10.0
# Singularity
singularity pull docker://google/deepvariant:1.10.0
```

## Alternative: Clair3 (conda-installable, HiFi-optimized)

If container access is blocked, Clair3 is a conda-installable alternative for HiFi variant calling:
```bash
conda install -c bioconda clair3
```

## Container technology comparison

| Feature | Docker | Singularity/Apptainer | Podman |
|---------|--------|----------------------|--------|
| Daemon | Required | None | None (daemonless) |
| Root required | Yes (default) | No | No (rootless) |
| HPC friendly | No | Yes (designed for it) | Partial |
| Image format | Layered tar | SIF single file | OCI compatible |
| Runs Docker images | Native | `docker://` URI | Native |
| GPU support | nvidia-docker | `--nv` flag | nvidia-container-toolkit |
| Typical use | DevOps, CI/CD | HPC, scientific computing | Security-sensitive envs |

**Key**: Apptainer is the successor to Singularity (renamed under Linux Foundation). Commands are largely identical — `singularity` → `apptainer`.
