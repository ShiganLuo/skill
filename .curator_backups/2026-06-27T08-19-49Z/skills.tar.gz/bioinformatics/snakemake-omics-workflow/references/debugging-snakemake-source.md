# Debugging Snakemake Source Code

When the project includes a local Snakemake source clone (e.g. `workflow/snakemake/`), you can debug the framework itself — not just your workflows.

## Setup: Editable Install

```bash
cd workflow/snakemake
pip install -e .   # editable mode — changes to src/snakemake/ take effect immediately
```

This allows setting breakpoints and modifying Snakemake internals without reinstalling.

## pdb/ipdb Breakpoints

Insert at the point you want to inspect:

```python
import pdb; pdb.set_trace()    # stdlib
import ipdb; ipdb.set_trace()   # friendlier (pip install ipdb)
```

Then run snakemake normally — execution pauses at the breakpoint.

**Common pdb commands:**
- `n` next line, `s` step into, `c` continue
- `p var` print variable, `bt` call stack, `l` show code location

## Key Source Entry Points

| Problem Area | File | Function/Location |
|---|---|---|
| Rule parsing | `rules.py` | `Rule.__init__` |
| DAG construction | `dag.py` | `DAG.init` |
| Job scheduling | `scheduling/job_scheduler.py` | `JobScheduler.schedule` |
| Execution | `executor/` | per-executor `run` method |
| Wildcard expansion | `wildcards.py` | wildcard resolution logic |
| Shell commands | `shell.py` | `shell.exec_job` |
| Workflow loading | `workflow.py` | `Workflow.__init__` |

## VS Code / PyCharm Debugging

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Debug Snakemake",
            "type": "debugpy",
            "request": "launch",
            "module": "snakemake",
            "args": [
                "--snakefile", "${workspaceFolder}/your_workflow.smk",
                "--configfile", "raw.json",
                "--cores", "4"
            ],
            "cwd": "${workspaceFolder}"
        }
    ]
}
```

## Quick Diagnostic Commands (no source edit needed)

```bash
# Dry-run with execution reasons
snakemake --snakefile xxx.smk --configfile raw.json --cores 1 -n -r

# DAG visualization
snakemake --snakefile xxx.smk --configfile raw.json --cores 1 --dag | dot -Tpng > dag.png
```

## Parser Architecture: How Snakefile Mixes Python and Rules

Snakemake's key insight: **Snakefile IS valid Python**. The parser (`src/snakemake/parser.py`) performs source-to-source transformation using Python's `tokenize` module before `exec()`.

### Transformation Pipeline

```
Snakefile → tokenize → TokenAutomaton (state machine) → Python code → exec()
```

### Key Components

| Component | Location | Role |
|---|---|---|
| `Snakefile` class | parser.py:1356 | Wraps file with `tokenize.generate_tokens()` |
| `Python` automaton | parser.py:1300 | Top-level state machine, dispatches keywords |
| `Rule` automaton | parser.py:782 | Transforms `rule name:` → `@workflow.rule(name=...)` |
| `Run` automaton | parser.py:573 | Transforms `run:` → `@workflow.run` + function def |
| `Shell` automaton | parser.py:674 | Transforms `shell:` → `@workflow.shellcmd()` + `shell()` |

### Transformation Examples

**Rule + Shell:**
```python
# Snakefile
rule hello:
    output: "out.txt"
    shell: "echo hello > {output}"

# Transformed Python
@workflow.rule(name='hello', lineno=1, ...)
@workflow.output("out.txt")
@workflow.shellcmd("echo hello > {output}")
def __rule_hello(input, output, params, wildcards, ...):
    shell("echo hello > {output}", bench_record=bench_record, ...)
```

**Rule + Run:**
```python
# Snakefile
rule hello:
    output: "out.txt"
    run:
        with open(output[0], 'w') as f:
            f.write("hello")

# Transformed Python
@workflow.rule(name='hello', lineno=1, ...)
@workflow.output("out.txt")
@workflow.run
def __rule_hello(input, output, params, wildcards, ...):
    with open(output[0], 'w') as f:
        f.write("hello")
```

### How It Works

1. **`Python.python()` (line 1336)**: Checks if token is at line start AND is a registered keyword
2. If keyword → call `subautomaton(token.string).consume()` to transform
3. If not keyword → yield token unchanged (it's regular Python)
4. Each subautomaton yields transformed tokens (decorators, function defs)

### Why This Matters for Debugging

- Parser errors show transformed Python line numbers, not original Snakefile lines
- `linemap` dict (parser.py:1404) maps transformed → original lines for error reporting
- Adding new keywords requires: (1) create automaton class, (2) register in `Python.subautomata`

## Pitfall: Version Mismatch

If you edit the local source but `snakemake --version` still shows the old version, the editable install may not be active in the current conda env. Verify with:

```bash
python -c "import snakemake; print(snakemake.__file__)"
```

The path should point to `workflow/snakemake/src/snakemake/`, not a site-packages directory.
