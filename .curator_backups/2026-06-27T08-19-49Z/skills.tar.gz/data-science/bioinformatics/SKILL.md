---
name: bioinformatics
description: Bioinformatics tools and genomics pipelines — RNA-seq quantification, coverage analysis, tool output summarization, SV visualization, and post-processing scripts.
tags: [genomics, rna-seq, stringtie, quantification, bioinformatics, coverage-analysis, oncoprint, sv-visualization, summary-report]
triggers:
  - StringTie, featureCounts, HTSeq, or other RNA-seq quantification
  - Gene abundance merging, TPM/FPKM/Coverage calculations
  - GTF/GFF annotation parsing and manipulation
  - Duplicate gene_id handling in quantification output
  - RNA-seq pipeline design or debugging
  - Gene body coverage, transcript coverage curves, RSeQC-style analysis
  - BAM coverage extraction, BED loading, coverage normalization
  - Summarize bioinformatics tool output across samples
  - OncoPrint, SV comparison plots, significance brackets
  - Build report script for pipeline output
---

# Bioinformatics Tools & Genomics Pipelines

Class-level skill for bioinformatics workflows: RNA-seq quantification, coverage analysis, tool output summarization, and structural variant visualization.

---

## Section A: StringTie Gene Abundance Quantification

Recurring patterns for RNA-seq analysis, quantification, and post-processing.

## StringTie Gene Abundance Quantification

### Output Format

StringTie `-e -B -A` produces gene_abundance.tsv with columns:

| Column    | Type  | Description |
|-----------|-------|-------------|
| Gene ID   | str   | Ensembl gene ID (e.g. ENSG00000158623) |
| Gene Name | str   | HGNC symbol |
| Reference | str   | Chromosome |
| Strand    | str   | + or - |
| Start     | int   | 1-based start coordinate |
| End       | int   | End coordinate |
| Coverage  | float | Mean coverage depth |
| FPKM      | float | Fragments Per Kilobase per Million |
| TPM       | float | Transcripts Per Million |

### Duplicate Gene_id Problem

**Root cause**: StringTie clusters transcripts by genomic overlap, NOT by reference gene_id. If a gene has transcripts in non-overlapping loci (e.g. COPG2 with a ~147kb gap), StringTie outputs multiple rows with the same gene_id.

**Why only some samples**: Read coverage across the inter-locus gap varies by sample depth and fragment length. Higher coverage may bridge the gap; low coverage leaves it split.

**Why `-g` parameter won't fix it**: The `-g` (minimum locus gap) parameter controls clustering of read clusters with reads present. If there are zero reads in the gap, increasing `-g` has no effect — there's nothing to bridge.

### Merging Duplicate Gene Rows

TPM, FPKM, and Coverage are normalized metrics and cannot be simply summed. Correct merging rules:

1. **TPM**: Direct sum is mathematically valid. TPM is per-million normalized; same-sample sums preserve correct relative proportions.
2. **FPKM**: Direct sum is valid for the same reason (per-gene normalization).
3. **Coverage**: Must be length-weighted average:
   ```
   Coverage_merged = sum(Cov_i * L_i) / sum(L_i)
   where L_i = End_i - Start_i
   ```
4. **Start/End**: min(Start) / max(End). Must remain **int type** — do not convert to float.
5. **Output order**: Preserve original row order (first occurrence position), do NOT sort by gene_id.

### Pitfalls

- Do NOT sort merged output by gene_id — preserve original file order.
- Start and End must stay int, not float. Use `int()` conversion explicitly.
- Coverage weighted average needs length as weight, not raw coverage sum.
- Adjusting StringTie `-g` parameter is NOT a fix for disconnected loci — downstream merging is the correct approach.
- prepDE.py3 `-g` flag handles transcript-to-gene aggregation but still won't merge disconnected regions in the same way.

See `references/stringtie-gene-merging.md` for the working aggregation script.

---

## Section B: Gene Body / Transcript Coverage Analysis

Compute gene body coverage curves from BAM files with BED annotations. Covers BED loading, BAM coverage extraction, binning, normalization, and plotting. Use for: gene body coverage, transcript coverage curves, coverage QC, RSeQC-style analysis.

**Key technique**: Use `bam.fetch()` + `read.get_blocks()` instead of `pysam.pileup()` for 10-50x speedup. Normalize per-gene by max to compare distribution shapes across samples.

**Common pitfall**: "Batman ears" curve (high at ends, low in middle) caused by not excluding UTR/IVS regions. Fix: `--exclude-region UTR IVS`.

See `references/coverage-analysis.md` for the full algorithm, CLI interface, and performance benchmarks.

---

## Section C: Bioinformatics Tool Summary Scripts

Build Python scripts that parse bioinformatics tool output (TSV/VCF/BED), aggregate across samples, and produce TSV tables, HTML reports, and publication-quality figures with data-driven conclusions.

**Pattern**: CLI with mutually exclusive `--indir` (scan directory) vs `-p/-d` (comma-separated file lists) modes. Pure analysis functions → three output channels (TSV, HTML, figures). Snakemake integration via `-p/-d` mode.

**Key principle**: Always group figures under section headers with data-driven conclusions (real numbers, not hardcoded). Compute stats from actual data.

See `references/tool-summary-scripts.md` for the complete workflow, Snakemake integration patterns, and standard figure set.

---

## Section D: Structural Variant Visualization

Build Python CLI tools that produce publication-quality plots from genomics SV data — OncoPrint, comparison bar charts, significance brackets, multi-format output.

**Key patterns**:
- `PlotFormat` type alias with `Literal` constraint on function parameters
- N-group comparison bar charts with auto-generated colors
- OncoPrint with FIXED gridspec ratios (`[1, 4]`), never raw data dimensions
- Significance brackets as single polyline (not 3 separate lines)
- `ProcessPoolExecutor` for parallel plotting (never `ThreadPoolExecutor` due to SQLite)

See `references/sv-visualization.md` for the complete visualization patterns, OncoPrint layout, and pitfall catalog.
