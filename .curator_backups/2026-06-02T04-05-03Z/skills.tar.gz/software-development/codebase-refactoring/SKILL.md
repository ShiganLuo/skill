---
name: codebase-refactoring
description: "Refactor Python codebases: code quality review, file renaming to snake_case, import updates, and git workflow for restructuring projects."
triggers:
  - "review this code"
  - "refactor this project"
  - "rename files to follow conventions"
  - "restructure the project"
  - "clean up the codebase"
  - "apply software engineering best practices"
---

# Codebase Refactoring

Workflow for reviewing, refactoring, and restructuring Python projects following software engineering best practices.

## User Style Preferences (MUST FOLLOW)

- **Docstrings**: Always English, never Chinese
- **Logging format**: Use f-strings (`logger.info(f"Processing: {name}")`), NOT `%s` style (`logger.info("Processing: %s", name)`)
- **File naming**: snake_case with descriptive names reflecting functionality
- **Type hints**: Use modern syntax with `from __future__ import annotations`

## Phase 1: Code Quality Review

When user asks "how is this code" or requests a review:

1. Scan the project structure (`search_files` target=files)
2. Read key files to understand functionality
3. Evaluate against these criteria:
   - Docstrings and documentation quality
   - Type hints usage
   - Error handling robustness
   - Code duplication
   - Hardcoded paths
   - Mutable default arguments
   - Naming conventions (snake_case for files/vars, PascalCase for classes)
   - Import organization

## Phase 2: Refactoring a Single File

When refactoring a specific file:

1. Read the entire file first
2. Identify issues:
   - Hardcoded paths → convert to CLI args or config
   - Mutable defaults (e.g., `def f(x=[])`) → use `None` with initialization
   - Code duplication → extract common functions
   - Poor naming → rename to descriptive snake_case
   - Missing type hints → add them
   - Mixed language comments → standardize to English
3. Write the refactored version preserving all original functionality
4. Use `write_file` to create new version (keep old for comparison)

## Phase 3: Project-Wide File Renaming

When renaming files across a project:

### Step 1: Inventory and Plan
```
# Create renaming plan with old -> new mapping
# Group by directory for batch operations
```

### Step 2: Create New Directories
```bash
mkdir -p new_dir1 new_dir2
```

### Step 3: Use `git mv` for Each File
```bash
git mv old/path/file.py new/path/file_name.py
```

**Critical**: Always use `git mv` not plain `mv` to preserve git history.

### Step 4: Update All Import References
Search for all imports referencing old module names:
```bash
grep -r "old_module_name" --include="*.py" .
```

Use `execute_code` with `patch` tool for batch import updates:
```python
from hermes_tools import patch
files = ["file1.py", "file2.py"]
for f in files:
    patch(f, "from old.module import", "from new.module import")
```

### Step 5: Clean Up
- Remove `__pycache__` directories
- Remove empty directories
- Verify with `git status`

### Step 6: Commit and Push
```bash
git add -A
git commit -m "refactor: descriptive commit message listing all changes"
git push
```

## Common Renaming Patterns

| Current (Bad)              | Target (Good)                |
|---------------------------|------------------------------|
| `LogUtil.py`              | `logger.py`                  |
| `MatchUtil.py`            | `sample_matcher.py`          |
| `chipevalute_interval.py` | `chip_evaluator.py`          |
| `stanard_pipeline.py`     | `pipeline.py` (fix typos)    |
| `result_plot.py`          | `validation_plots.py`        |
| `depth.py`                | `sensitivity.py`             |
| `run.py`                  | `run_simulation.py`          |
| `HD/`                     | `hrd/`                       |
| `task/`                   | `workflow/`                  |
| `assests/`                | `assets/`                    |

## Directory Naming Conventions

- Use lowercase with underscores: `bed_formatting/`, `frequency_correction/`
- Abbreviations should be lowercase: `hrd/` not `HD/`
- Names should describe content: `workflow/` not `task/`

## Pitfalls

- **Forgetting to update imports**: Always grep for old module names after renaming
- **Using `mv` instead of `git mv`**: Loses git history
- **Not cleaning `__pycache__`**: Can cause confusion with stale bytecode
- **Renaming without understanding dependencies**: Check for hardcoded script paths in shell scripts and argparse defaults
- **Committing too much at once**: Keep refactoring commits separate from feature changes
