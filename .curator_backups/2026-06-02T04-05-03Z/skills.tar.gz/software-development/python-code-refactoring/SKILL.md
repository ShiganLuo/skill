---
name: python-code-refactoring
description: Refactor Python scripts to production-quality code with clean structure, English docs, proper naming, and no anti-patterns
trigger:
  - User asks to refactor/improve Python code
  - User asks to clean up a script
  - User says code needs better structure or naming
  - User requests code quality improvements
---

# Python Code Refactoring

Refactor Python scripts to production-quality code following software engineering best practices.

## User Preferences (CRITICAL)

- **Docstrings/comments: ENGLISH only** - Never use Chinese or other languages
- **Logging: Use f-strings** - `logger.info(f"Processing {item}")` NOT `logger.info("Processing %s", item)`
- **Naming: Software engineering style** - descriptive, functional names (e.g., `aggregate_depth_stats.py` not `stat_xishu.py`)

## Refactoring Checklist

When refactoring Python code, address these in order:

### 1. Remove Hardcoded Values
- File paths → CLI arguments or config
- Magic numbers → named constants
- Column names → constants or config

```python
# BAD
df = pd.read_csv("/mnt/.../data.tsv")

# GOOD  
DEFAULT_INPUT = "data.tsv"
# Use argparse or config
```

### 2. Fix Mutable Default Arguments
```python
# BAD - mutable default
def process(columns=["col1", "col2"]):
    ...

# GOOD - None default
def process(columns=None):
    if columns is None:
        columns = ["col1", "col2"]
```

### 3. Merge Duplicate Functions
- If two functions share >50% logic, merge into one
- Extract common logic into helpers
- Use parameters to handle variations

### 4. Use pathlib Consistently
```python
# BAD
import os
path = os.path.join(dir, filename)

# GOOD
from pathlib import Path
path = Path(dir) / filename
```

### 5. Add Module/Script Docstring
```python
"""Brief description.

Detailed description of what this module does.

Usage:
    python script.py -arg1 value1 -arg2 value2
"""
```

### 6. Add Constants at Top
```python
# Constants
DEFAULT_SUFFIX = "_output.tsv"
DEFAULT_COLUMNS = ["Chr", "Start", "Stop"]
MAX_RETRIES = 3
```

### 7. Improve Type Hints
```python
# Use specific types, not Any
def process(files: List[Path]) -> Dict[str, pd.DataFrame]:
    ...
```

### 8. Improve Error Handling
- Check file existence before reading
- Validate inputs early
- Use specific exceptions
- Log errors with context

## Naming Conventions

### File Names
- Use descriptive functional names
- Pattern: `<action>_<object>.py`
- Examples:
  - `aggregate_depth_stats.py` ✓
  - `stat_xishu.py` ✗ (Chinese abbreviation)
  - `generate_report.py` ✓
  - `report.py` ✗ (too vague)

### Function Names
- Use `verb_noun` pattern
- Examples:
  - `normalize_dep_factor()` ✓
  - `normalize()` ✗ (what?)
  - `extract_sample_id()` ✓

### Variable Names
- Be descriptive
- Avoid single letters except loop vars
- Examples:
  - `sample_list` ✓
  - `sl` ✗
  - `dep_factor_series` ✓

## Git Workflow After Refactoring

```bash
# Stage changes
git add -A  # or specific files

# Commit with descriptive message
git commit -m "refactor: <what was improved>

- List key changes
- Use conventional commit format"

# Push
git push
```

Commit message format:
- `refactor:` for code restructuring
- `fix:` for bug fixes
- `feat:` for new features
- `docs:` for documentation only

## Quality Checks

Before finishing refactoring:
- [ ] All docstrings in English
- [ ] No hardcoded paths/numbers
- [ ] No mutable defaults
- [ ] Consistent pathlib usage
- [ ] Clear file/function names
- [ ] Type hints added
- [ ] Error handling added
- [ ] Can run without modification (paths are args)
