---
name: full-stack-model-migration
description: >
  Coordinate data model changes across Spring Boot (MyBatis) backend + Vue3 frontend.
  Covers: adding tenant/user isolation columns, updating entity→mapper→service→controller,
  frontend API/type/view alignment. Trigger: user wants to add multi-tenancy, refactor
  a data model, or change database schema across full stack.
tags: [spring-boot, mybatis, vue3, full-stack, database, multi-tenant, refactoring]
---

# Full-Stack Model Migration

Pattern: change a database table, then propagate the change through every layer of the stack.

## Migration Checklist (Spring Boot + MyBatis + Vue3)

### Layer 1: Database
1. ALTER TABLE to add/modify columns
2. Add UNIQUE constraints, foreign keys as needed
3. Update the SQL schema file (.sql) for fresh installs
4. Update existing data if needed (migrate old records)

### Layer 2: Entity (Java)
1. Add new fields to the entity class
2. Fix type mismatches (e.g., String vs Integer for TINYINT columns)
3. Ensure field names match MyBatis naming conventions

### Layer 3: Mapper Interface (Java)
1. Add new query methods (e.g., `getXxxByUserId`)
2. Remove duplicate/ambiguous method signatures
3. Add `@Param` annotations for multi-param methods
4. Add delete/update methods for the new queries

### Layer 4: Mapper XML
1. Add new columns to `<resultMap>`
2. Update all `<insert>` statements to include new columns
3. Add new `<select>` queries for the new access patterns
4. Add `<update>` variants if needed (selective vs full update)
5. Add `<delete>` if needed

### Layer 5: Service
1. Inject any new dependencies (e.g., UserMapper for auth)
2. Add helper methods (e.g., `getCurrentUserId()` from SecurityContext)
3. Replace hardcoded IDs with dynamic lookups
4. Add null-safety checks (NPE protection)
5. Update method signatures if needed

### Layer 6: Service Interface
1. Add new method declarations
2. Update existing signatures

### Layer 7: Controller
1. Update endpoints to use new service methods
2. Remove redundant/duplicate endpoints
3. Update URL patterns if needed (e.g., add path variables)
4. Ensure auth context is used correctly

### Layer 8: Frontend Types (TypeScript)
1. Update/add interfaces to match backend DTOs
2. Add missing fields
3. Fix naming inconsistencies

### Layer 9: Frontend API (TypeScript)
1. Update API method signatures (add parameters)
2. Update URL patterns to match new backend routes
3. Ensure type parameters match

### Layer 10: Frontend Views (Vue)
1. Import new dependencies (stores, utilities)
2. Pass required parameters to API calls
3. Handle loading/error states for new flows
4. Update templates if data structure changed

## Pitfalls

- **Batch frontend API updates incomplete**: When changing an API signature (adding required param), grep ALL callers across the frontend: `grep -rn "methodName()" src/ --include="*.vue" --include="*.ts"`. Missing one caller = runtime error. Common miss: `app-init.ts` which runs before login and can't access user store.
- **Hardcoded IDs**: The most common single-site→multi-user issue. Search for `1L`, `id=1`, `(long) 1` in service layer AND background services. Commonly missed locations: `@Scheduled` tasks (e.g., VisitCountSyncTask), cache/counter services (e.g., RedisVisitCounter), RSS/feed generators. These don't go through controllers so they're easy to overlook. Grep broadly: `grep -rn "1L\|= 1;" src/main/java/ --include="*.java"`
- **Semantic parameter mismatch after migration**: When adding `userId` to a table, controllers may pass `userId` but internal service calls still use `getSettingById(id)` instead of `getSettingByUserId(userId)`. The method receives a `userId` value but queries by primary key — silently returning null. After ANY migration that adds a user/tenant isolation column, grep ALL service method bodies for old query methods: `grep -rn "getSettingById\|getXXXById" src/main/java/.../service/`. Verify every caller passes the right type of ID to the right query method.
- **Mapper duplicate signatures**: Two methods with same name but different param types (long vs Long) cause MyBatis binding errors.
- **Null-safety gaps**: Service methods that call `entity.getXxx()` without null-checking the entity first.
- **Type mismatches**: DB TINYINT(1) mapped to Java String when DTO expects Integer (or vice versa).
- **Naming inconsistencies**: Entity field `wechatQrCode` vs DTO `weiXinQRCode` vs DB column `wechat_qrcode` — must be consistent.
- **Frontend param propagation**: When backend adds required params to API, every frontend caller must be updated. Search for all usages of the API method.
- **Vue store initialization is two steps**: Adding `import { useUserStore } from "@/stores/index"` is NOT enough. You must ALSO add `const userStore = useUserStore()`. These are independent operations that can each be missed. When batch-modifying Vue files, always verify BOTH the import AND the const declaration exist. Check with: `grep -rn "useUserStore" src/ --include="*.vue"` — files with import but no `const userStore` will have runtime errors.
- **API error silencing for expected errors**: When a backend endpoint returns a "not found" or "not initialized" error that's expected (e.g., user hasn't set up blog settings), the HTTP interceptor shows an ElMessage toast BEFORE the promise rejects. `.catch()` alone cannot suppress the message because the interceptor fires first. **Two-layer fix**: (1) Add `silent?: boolean` to AxiosRequestConfig via `declare module 'axios'`, check it in the response interceptor before showing ElMessage. (2) Add `silent: true` to the API call config, plus `.catch()` for graceful fallback. See `references/http-interceptor-silent-pattern.md` for the full implementation.
- **Default asset fallback pattern**: When a dynamic asset URL (background image, avatar, logo) might be empty, import a local default and use `|| defaultBg` as fallback in both JS and template: `:src="url || defaultBg"`. Apply at the component level (e.g., PageHeader) so all parent pages inherit the fallback.
- **Selective vs Full update**: MyBatis `<if test="xxx != null">` means null fields won't be cleared. Use a separate full-update SQL if users need to clear fields.
- **Vue SFC file corruption (CRITICAL)**: `write_file` on `.vue` files silently empties them, causing "At least one <template> or <script> is required" errors. NEVER use `write_file` on existing `.vue` files. ALWAYS use `patch` for modifications. If corrupted, recover with `terminal: git checkout -- <file>`. See `safe-file-editing` skill for the full rule set.
- **Batch execute_code + write_file**: Using `execute_code` with `write_file` inside a loop empties multiple files in one pass. Use `patch` for targeted edits instead; only use `write_file` for brand-new files.
- **GET + @RequestBody**: Spring Boot `@GetMapping` with `@RequestBody` fails with "Required request body is missing". GET requests have no body. Use `@ModelAttribute` for query parameters, or change to `@PostMapping`. Common when frontend sends `params: {}` (query string) but backend expects body.
- **Frontend-backend param mismatch**: Frontend `request.get({ params: query })` sends URL query params. Backend must use `@ModelAttribute` or `@RequestParam`, NOT `@RequestBody`. Verify HTTP method matches parameter binding.
- **Components in App.vue re-mount on route change**: Any component imported in `App.vue` (e.g., WelcomeMessage, global notifications) will re-trigger `onMounted` every time the user navigates. If the component has side effects (API calls, ElMessage popups), they repeat on every page switch. Fix: add a `sessionStorage` guard to ensure the side effect runs only once per session.
- **ElMessage "positioning" is usually not a CSS issue**: When unexpected text appears on the page (especially bottom-left), don't assume it's an ElMessage CSS positioning bug. First check: is a component in `App.vue` or a layout component re-firing on route change? The text is often a legitimate ElMessage from a component that re-mounts. Check component lifecycle before checking CSS.
- **Docker build in China: multi-round fixes**: Docker builds in China often fail in sequence: (1) image 403 → swap base images, (2) terser not found → remove terser config, (3) TypeScript errors → fix code. Fix one category at a time, rebuild, check next error. Don't try to fix everything at once. Also: `sed` on vite.config.ts can break syntax — use `patch` tool for precise edits instead.
- **TypeScript build errors surface in Docker builds**: When `pnpm run build` runs `type-check` before `vite build`, any missing type (removed field, wrong import) blocks the entire Docker build. Fix the code, then rebuild. Don't disable type-checking to work around it.
- **Vite terser not found in v3+**: Since Vite v3, `terser` is an optional dependency. If `vite.config.ts` has `minify: 'terser'` and `terserOptions: {...}`, the Docker build fails with `terser not found`. Fix: remove `minify: 'terser'` and `terserOptions` from the build config entirely — Vite defaults to esbuild which is built-in. Check both frontend and admin vite.config.ts files.
- **`git checkout -- .` reverts ALL changes**: When `git checkout -- .` is used to restore files, it reverts EVERYTHING — including unrelated fixes that were made in the same session. If the user asks to restore code, clarify whether they want to revert everything or just specific changes. After restoring, re-apply fixes that were collateral damage.
- **Frontend route patterns matter for link generation**: When generating URLs (RSS, share links, etc.), always check the actual frontend router definition. Vue router may use query params (`/article?id=11`) instead of path params (`/article/11`). Check `router.push()` calls in the view to confirm the pattern: `router.push({ path: "/article", query: { id: id } })` means the URL is `/article?id=11`.
- **User correction: verify before diving deep**: When debugging an issue (e.g., "ElMessage appearing at bottom-left"), don't assume the root cause. The user may know what the actual symptom is. If your initial investigation finds nothing, STOP and ask for clarification instead of continuing to guess. In this session, I spent time checking CSS positioning when the real issue was a WelcomeMessage component re-mounting on route change.

## Spring Security: Getting Current User

```java
// In service layer
Authentication auth = SecurityContextHolder.getContext().getAuthentication();
String username = auth.getName();
Long userId = userMapper.getIdByUsername(username);
```

For admin endpoints: use SecurityContext (user must be logged in).
For public endpoints: accept userId as path parameter, no auth required.

## References
- `references/blog-settings-migration-example.md` — Concrete example of single-site→multi-user migration
- `references/http-interceptor-silent-pattern.md` — Silent API calls for expected errors
- `references/rss-implementation-pattern.md` — RSS 2.0 feed implementation (Java DOM API, no library needed)

## File Naming Patterns

- Entity: `src/main/java/.../entity/Xxx.java`
- Mapper interface: `src/main/java/.../mapper/XxxMapper.java`
- Mapper XML: `src/main/resources/mapper/XxxMapper.xml`
- Service: `src/main/java/.../service/XxxService.java` + `impl/XxxServiceImpl.java`
- Controller: `src/main/java/.../controller/admin/AdminXxxController.java` (admin) + `controller/front/FrontXxxController.java` (public)
- Frontend API: `src/api/xxxApi.ts`
- Frontend types: `src/types/xxx.ts` or `src/types/xxx/xxx.d.ts`
- Frontend views: `src/views/xxx/index.vue`
