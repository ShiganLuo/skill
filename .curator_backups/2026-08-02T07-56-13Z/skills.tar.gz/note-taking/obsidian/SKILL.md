---
name: obsidian
description: Read, search, create, and edit notes in the Obsidian vault.
---

# Obsidian Vault

Use this skill for filesystem-first Obsidian vault work: reading notes, listing notes, searching note files, creating notes, appending content, and adding wikilinks.

## Vault path

Use a known or resolved vault path before calling file tools.

The documented vault-path convention is the `OBSIDIAN_VAULT_PATH` environment variable, for example from `~/.hermes/.env`. If it is unset, use `~/Documents/Obsidian Vault`.

File tools do not expand shell variables. Do not pass paths containing `$OBSIDIAN_VAULT_PATH` to `read_file`, `write_file`, `patch`, or `search_files`; resolve the vault path first and pass a concrete absolute path. Vault paths may contain spaces, which is another reason to prefer file tools over shell commands.

If the vault path is unknown, `terminal` is acceptable for resolving `OBSIDIAN_VAULT_PATH` or checking whether the fallback path exists. Once the path is known, switch back to file tools.

## Read a note

Use `read_file` with the resolved absolute path to the note. Prefer this over `cat` because it provides line numbers and pagination.

## List notes

Use `search_files` with `target: "files"` and the resolved vault path. Prefer this over `find` or `ls`.

- To list all markdown notes, use `pattern: "*.md"` under the vault path.
- To list a subfolder, search under that subfolder's absolute path.

## Search

Use `search_files` for both filename and content searches. Prefer this over `grep`, `find`, or `ls`.

- For filenames, use `search_files` with `target: "files"` and a filename `pattern`.
- For note contents, use `search_files` with `target: "content"`, the content regex as `pattern`, and `file_glob: "*.md"` when you want to restrict matches to markdown notes.

## Create a note

Use `write_file` with the resolved absolute path and the full markdown content. Prefer this over shell heredocs or `echo` because it avoids shell quoting issues and returns structured results.

## Append to a note

Prefer a native file-tool workflow when it is not awkward:

- Read the target note with `read_file`.
- Use `patch` for an anchored append when there is stable context, such as adding a section after an existing heading or appending before a known trailing block.
- Use `write_file` when rewriting the whole note is clearer than constructing a fragile patch.

For an anchored append with `patch`, replace the anchor with the anchor plus the new content.

For a simple append with no stable context, `terminal` is acceptable if it is the clearest safe option.

## Targeted edits

Use `patch` for focused note changes when the current content gives you stable context. Prefer over shell text rewriting.

### Batch edits

When updating many files at once (e.g., filling in 30+ templates), use `execute_code` with `hermes_tools.patch(path, old, new)`. See `references/batch-operations.md` for the correct signature, failure modes, and a reusable loop pattern.

**Pitfall**: `hermes_tools.patch(path, old, new)` in execute_code has different args than the standalone `patch` tool. The execute_code version takes 3 positional args: path, old_string, new_string.

## Embedded Images

To resize embedded images in Obsidian:
- Width only: `![[image.png|500]]` (500px wide)
- Width x Height: `![[image.png|300x200]]`
- Attachments are stored in `<filename>_Attachments/` directories adjacent to the note

### Image Tables (横竖混排对齐 + 铺满宽度)

When placing images of different aspect ratios side-by-side in a table, three problems stack up:
1. `![[image|width]]` does NOT align them — portrait images are taller than landscape ones
2. Markdown tables auto-size columns — images won't fill the available width
3. PDF export may push oversized images to the next page

**Fix**: Use HTML `<table>` + `<img>` with CSS. This is the ONLY reliable approach in Obsidian for images that must fill width AND align height.

```html
<table width="100%"><tr>
<td width="50%" align="center"><img src="photo1.png" style="width:100%;height:250px;object-fit:cover;"><br><sub>景点A</sub></td>
<td width="50%" align="center"><img src="photo2.png" style="width:100%;height:250px;object-fit:cover;"><br><sub>景点B</sub></td>
</tr></table>
```

For 3-image rows, use `width="33%"` / `width="34%"` and `height:220px`.

**CSS properties that matter:**

| Property | Effect | When to use |
|----------|--------|-------------|
| `width:100%` | Image fills cell width | Always |
| `height:250px` | Fixed height, all images align | Always |
| `object-fit:cover` | Fill cell, crop overflow | Default — best for landscapes |
| `object-fit:contain` | Show full image, may leave whitespace | When cropping cuts important content |
| `object-position:bottom` | Crop from top, keep bottom | Subject is in lower portion (e.g. 月牙泉) |
| `max-height:450px` | Cap height, prevent PDF page overflow | Large images that must stay on one page |

**Pitfall**: Obsidian's `![[image|width]]` syntax does NOT support height-only sizing. The `|300x200` format requires both dimensions and crops. Markdown table columns auto-size and won't expand images to fill available space. HTML `<table>` is the only reliable way.

### Structured Daily Sections (日程格式)

For itineraries or daily logs, use this consistent section pattern:

```markdown
### Day X（日期）：标题

| 图片1·标题 | 图片2·标题 |
|:---:|:---:|
| <img src="img1.png" height="200"> | <img src="img2.png" height="200"> |

> 📍 **今日关键词：** 关键词1 · 关键词2

**⏰ 行程安排：**
- 时间线...
- 🏨 住宿：...

> 💡 弹性：...

**🚗 驾驶信息：** 距离 | 时间
```

Emoji 图标区分区块：📍关键词、⏰行程、🏨住宿、💡弹性、🚗驾驶。

## Wikilinks

Obsidian links notes with `[[Note Name]]` syntax. When creating notes, use these to link related content.

## Vault Analysis

When user asks about organizing or managing their vault, **scan first, advise second**. Don't give generic best practices — analyze their actual structure.

### Analysis workflow
1. `search_files` with `target: "files"` and `pattern: "*.md"` to get file count and structure
2. `search_files` with `target: "content"`, `pattern: "#[a-zA-Z]+"` to check tag usage
3. `search_files` with `target: "content"`, `pattern: "\\[\\[.*\\]\\]"` to check link usage
4. `search_files` with `target: "content"`, `pattern: "tags:"` to find frontmatter tags
5. Read a few representative notes to understand content patterns

### What to report
- File count and directory structure
- Tag consistency (are they used? consistent?)
- Link density (are notes connected?)
- Isolated notes (no incoming links)
- Existing index/MOC files

## Vault Restructuring

When user asks to reorganize or optimize vault structure:

### Principles
- **User prefers minimal nesting** — 2-3 levels max, flat where possible. Do NOT suggest deep hierarchical folder trees (e.g. `行业/公司/基因检测/吉因加/` is too deep). User explicitly rejected multi-level nesting. When user says "我只想分几个大的方面，不建立很多层级文件夹", they mean exactly that — merge/simplify, don't split further.
- Analyze first, suggest concrete reorganization plan, then execute on approval.
- When suggesting, show the BEFORE and AFTER tree side-by-side.
- Use `mv` commands via `terminal` for bulk file moves. Create destination dirs with `os.makedirs` first.
- Clean up empty directories after moves.

### Common reorganization patterns
- Merge related small folders into one (e.g. 高管→公司/高管, 股市→投资)
- Move misplaced items to parent level (e.g. 职业发展 doesn't belong under 行业/)
- Rename vague folders (e.g. 股市→投资 for broader scope)
- Keep "工作" (actual work) separate from "研究" (research/analysis)

## MOC (Map of Content) Creation

When user wants MOC or better organization:

1. Scan vault structure to understand existing categories
2. Look for existing index files (files with `type: index` in frontmatter)
3. Create `Home.md` at vault root as entry point
4. Use wikilinks with display names: `[[path/to/note|Display Name]]`
5. Include frontmatter: `title`, `type: index`, `created`

### Home.md structure
```markdown
---
title: Home
type: index
created: YYYY-MM-DD
---

# 🏠 知识库首页

## 📚 主要板块
### [[path/to/index|板块名称]]
- 子项1
- 子项2

## ⚙️ 系统
### [[path/to/tasks|任务]]
```

## Research Report Collection

When user wants to collect industry reports (行业报告) for their vault:

1. Use 东方财富证券研报中心 — see `references/eastmoney-research-reports.md` for API details and browser extraction approach
2. Filter by relevant industry categories (生物制品, 化学制药, 医疗器械, etc.)
3. Save as daily digest: `行业研究/每日行业报告/YYYY-MM-DD.md`
4. Format as markdown tables with columns: 日期 | 机构 | 报告标题
5. Add a "本周重点关注" summary section at the end

## Batch Note Population (填充批量笔记)

When user asks to fill/populate a directory of skeleton notes with research info:

1. **Read existing notes first** to understand the template pattern (frontmatter fields, section structure, wikilink conventions)
2. **Categorize by content level** — empty templates vs partially filled — use `execute_code` with `read_file` to scan line counts
3. **Search for info** — try subagents or web search; if web search fails (see pitfall below), use model knowledge
4. **Batch update via execute_code + patch** — construct all patches in a Python dict and loop through them. This is faster and more reliable than individual patch calls across turns
5. **Verify a sample** — `terminal` + `cat` a few updated files to confirm format

### Pitfall: patch old_string must match exactly
- Frontmatter whitespace matters. If a patch fails, `cat -A` the file to check for trailing spaces, extra tags, or encoding differences
- When old_string has a `tags:` list with different items than expected, the match fails. Check with `terminal` first

### Pitfall: web search unreliable in China environment
- Google returns 400 errors, Baidu triggers CAPTCHA, Bing blocks bot requests
- delegate_task subagents with `toolsets: ["web"]` often return empty results
- **Fallback**: use model knowledge for well-known companies, or ask user to provide source material

### Reference
- See `references/company-research-template.md` for the standard company note structure used in this vault
- See `references/travel-itinerary-template.md` for the structured travel plan format (daily sections, weather impact, cost by group size, checklist, HTML image tables)

## Tags vs Links

Not every vault needs a tag system. When user asks about tags:
- If they already have folder structure + links → **tags may be unnecessary**
- Tags are useful for: cross-folder filtering (status, type), not for topics
- Links are better for: concept relationships, knowledge connections
- **Recommend: scan their actual usage before suggesting a tag system**
