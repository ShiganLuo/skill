# Verifying SIF image contents

After building or updating a SIF, verify that expected tools and pip packages
are correctly installed inside the container.

## Check if a command exists inside a SIF

```bash
apptainer exec /path/to/env/star/star.sif bash -c 'which Tailer; find /opt/conda/envs/star -name "Tailer"; pip show jla-tailer'
```

Output (success):
```
/opt/conda/envs/star/bin/Tailer
/opt/conda/envs/star/bin/Tailer
Name: jla-tailer
Version: 0.1.18
```

This three-pronged check covers:
1. `which <cmd>` -- is it on PATH inside the container?
2. `find /opt/conda/envs/<name> -name "<cmd>"` -- does the binary exist?
3. `pip show <package>` -- is the pip package metadata present?

## Conda env structure inside SIF

EnvUtil-built SIFs use `continuumio/miniconda3:latest` as the base image.
Conda envs are created at `/opt/conda/envs/<env_name>/`. The `%environment`
section sets `PATH="/opt/conda/envs/<env_name>/bin:$PATH"` so tools are
directly available via `apptainer exec`.

For pip-installed packages (e.g. `jla-tailer` in star.yaml), the package
lands at `/opt/conda/envs/<env_name>/lib/python<X.Y>/site-packages/`.

## When to verify

- After adding new dependencies to a YAML and rebuilding the SIF
- After adding pip dependencies (pip install can fail silently in conda env create)
- When a tool inside the SIF is not found at runtime

## Testing if a YAML can create a conda env (pitfall)

`conda env create -f <yaml> --dry-run` is **not reliable** for complex envs
with many dependencies. It can hang for 5+ minutes on the conda solver,
making it impractical as a quick sanity check.

Alternatives:
1. Build the SIF directly (`apptainer build` or `EnvUtil.py apptainer all`) --
   the build itself is the real test. If conda env create fails inside the
   SIF build, you see the error in the apptainer log.
2. Create a throwaway conda env: `conda env create -f <yaml> -n test_env`
   (no --dry-run). Slower but definitive.
3. Use `conda env create -f <yaml> --dry-run --json` with a long timeout
   (600s+) only if you specifically need a dry-run.

The user's workflow: update YAML -> rebuild SIF -> verify with
`apptainer exec` -> commit and push.
