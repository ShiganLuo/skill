---
name: snakemake-omics-workflow
description: Add new modules, subworkflows, and pipelines to the Omics Snakemake project — including porting from Nextflow
---

# When to use

- User asks to implement a new workflow/pipeline in the Omics Snakemake project
- User asks to port a Nextflow (nf-core) pipeline to Snakemake
- User asks to add a new tool module to `workflow/Omics/modules/`
- User asks to create a new subworkflow in `workflow/Omics/subworkflow/`

# Prerequisites — read these first

Before writing any code, load and read these project files:

1. **`SKILL.md`** (in project root, e.g. `workflow/Omics/SKILL.md`) — project overview, run.py responsibilities, extension checklist. **ALWAYS read this first** — it's the project owner's source of truth.
2. `subworkflow/subworkflow.md` — subworkflow conventions (module + use rule pattern, config dict naming)
3. `modules/modules.md` — module conventions (3-file structure, config dict, rule naming)

These are project-local markdown files, not Hermes skills. Read them with `read_file`.

# Extension checklist (from skill.md)

When adding a new workflow:

1. Add model template JSON in `config/<WorkflowName>.json`
2. Add `run<Workflow>()` function in `run.py`
3. Add workflow name to `--workflow_name` choices in `parse_args()`
4. Add entry to `WORKFLOW_DISPATCH` dict in `__main__` block
5. Create subworkflow snakefile in `subworkflow/<WorkflowName>.smk`
6. Create required modules in `modules/<tool>/`
7. Update `README.md` (main) — add workflow to supported table AND verify ALL existing workflows are documented (scan `subworkflow/*.smk`)
8. Update `subworkflow/README.md` — add workflow description AND verify ALL existing workflows have descriptions

# Module directory layouts

Three patterns exist in the codebase (see `modules/modules.md` for full spec):

## A. Simple 3-file (most common)
```
modules/<tool>/
  <tool>.smk    # rules
  <tool>.json   # config template
  <tool>.yaml   # conda env
```
Examples: samtools, fastqc, deepvariant, hiphase, pbsv, tabix

## B. 3-file + bin/ (custom scripts)
```
modules/<tool>/
  <tool>.smk / .json / .yaml
  bin/
    summarize.py
    plot.py
```
Examples: StringTie, arriba, spectrum, RmrRNA, track

Scripts referenced via `ROOT_DIR + "/modules/<tool>/bin/<script>.py"`.

## C. Parent + subdirectories (shared conda env)
```
modules/<tool>/
  <tool>.yaml               # shared conda
  <tool>.smk                # main/prepare rules
  <tool>.json
  <subtool>/
    <subtool>.smk            # conda: "../<tool>.yaml"
    <subtool>.json
```
Examples: gatk (prepare + bqsr/ + germline/ + somatic/), samtools (+ sort/)

# Three run/shell styles

## Unified style: `run:` block + shell script generation (ONLY allowed style)

**Pure `shell:` blocks are NOT allowed.** All rules use `run:` blocks with cmd list
construction, script generation, and structured logging via `setup_logger`.

```python
rule <tool>_<action>:
    input: ...
    output: ...
    log: logdir + "/{sample_id}/<tool>_<action>.log"
    threads: N
    conda: "<tool>.yaml"
    params:
        <tool> = config.get("Procedure", {}).get("<tool>") or "<tool>"
    run:
        try:
            open(log[0], "w").close()
            logger = setup_logger(logger_name="<tool>_<action>", log_file=log[0])
            current_time = time.strftime("%Y%m%d_%H%M%S", time.localtime())
            logger.info(f"Start <tool> <action> for sample {wildcards.sample_id} at {current_time}")
            script = os.path.join(outdir, f"{wildcards.sample_id}/<tool>_<action>_{current_time}.sh")
            cmd = [params.<tool>, "<action>", ...]
            with open(script, "w") as f:
                f.write(" ".join(cmd) + "\n")
            shell(f"bash {script} >> {log[0]} 2>&1")
        except Exception as e:
            with open(log[0], "a") as f:
                f.write(f"<tool> <action> failed for sample {wildcards.sample_id} with error: {e}\n")
            raise
```

See `modules/modules.md` "规则编写风格" section for full spec.

## Multi-command variant (manual script needed for chaining)

For tools with dynamic args, conditional flags, pipes, or multi-step sequences.
**Note**: With the shell.py + run_wrapper auto-script modification (see
`references/snakemake-shell-autoscript-mod.md`), ALL rule types automatically
generate reproducible scripts. `shell()` calls in `run:` blocks are captured to
`{log_dir}/shell_commands/`, and the full rule script (with HPC headers) is saved
to `{log_dir}/scripts/`. Manual script generation is optional — only needed if
you want to combine multiple commands in one script.

### Simplified pattern (preferred — auto-saved by two-layer system)

```python
run:
    log_path = str(log)
    try:
        open(log_path, "w").close()
        logger = setup_logger(logger_name="pbsv_call", log_file=log_path)
        logger.info(f"Start pbsv call for sample {wildcards.sample_id}")
        cmd = [params.pbsv, "call", "--num-threads", str(threads), input.fasta, input.svsig, output.vcf]
        shell(" ".join(cmd) + " >> {log_path} 2>&1")
    except Exception as e:
        with open(log_path, "a") as f:
            f.write(f"Error: {e}\n")
        raise
```

The shell.py modification automatically saves the resolved command to
`{log_dir}/scripts/pbsv_call.sample_id=XXX.20260620_124752.sh`.

### Multi-command variant (manual script needed for chaining)

When a rule needs multiple sequential commands in one script:

```python
run:
    log_path = str(log)
    current_time = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    script = os.path.join(outdir, f"{wildcards.sample_id}/align_{current_time}.sh")
    cmd1 = [params.STAR, ..., "--outSAMtype", "BAM SortedByCoordinate", ...]
    cmd2 = ["mv", f"{prefix}Aligned.sortedByCoord.out.bam", output.bam]
    cmd3 = [params.samtools, "index", "-@", str(threads), output.bam]
    with open(script, "w") as f:
        for cmd in [cmd1, cmd2, cmd3]:
            f.write(" ".join(cmd) + "\n")
    shell(f"bash {script} >> {log_path} 2>&1")
```

## Python data processing + shell command hybrid

When a rule needs Python logic (file prep, pandas aggregation) plus shell commands,
Python runs directly in the `run:` block, shell commands still go through script:

```python
run:
    # Python preparation
    with open(map_file, "w") as f:
        for k, v in mapping.items():
            f.write(f"{k}\t{v}\n")
    # Shell execution via script
    with open(script, "w") as f:
        f.write(" ".join(cmd) + "\n")
    shell(f"bash {script} >> {log[0]} 2>&1")
```

# Dynamic input functions

Alignment modules need paired/single dispatch:
```python
def get_alignment_input(wildcards):
    paired_r1 = f"{indir}/{wildcards.sample_id}/{wildcards.sample_id}_1.fq.gz"
    paired_r2 = f"{indir}/{wildcards.sample_id}/{wildcards.sample_id}_2.fq.gz"
    single = f"{indir}/{wildcards.sample_id}/{wildcards.sample_id}.single.fq.gz"
    if wildcards.sample_id in paired_samples:
        return [paired_r1, paired_r2]
    elif wildcards.sample_id in single_samples:
        return [single]
    raise ValueError(f"Sample {wildcards.sample_id} not defined")
```

Index fallback (prefer config-provided index, else module-generated):
```python
def get_index(wildcards):
    cfg_prefix = config.get('genome', {}).get('index_prefix')
    if cfg_prefix and os.path.exists(f"{cfg_prefix}.1.bt2"):
        return [f"{cfg_prefix}.{ext}" for ext in SUFFIXES]
    return [f"{outdir}/index/genome.{ext}" for ext in SUFFIXES]
```

## Input function returning list of FASTQs (non-wildcard)

When a rule processes ALL samples at once (e.g. mimseq), the input function
builds a list of all fastq paths. Return the list directly in the dict:

```python
def get_mimseq_input():
    fastqs = [os.path.join(indir, sid, f"{sid}.single.fq.gz") for sid in samples]
    return {
        "fastqs": fastqs,       # list — rule uses input.fastqs
        "meta": config.get("meta", ""),
        "trnas": config.get("genome", {}).get("trnas", ""),
    }
```

In the `run:` block, expand the list with `*`:
```python
run:
    cmd = [params.mimseq, input.meta, *input.fastqs]
    # or iterate: for fq in input.fastqs: ...
```

**Do NOT** use `unpack()` when the function returns a dict — `unpack()` is only
needed when the function returns a bare list/tuple for positional inputs.

# Result rules (_result)

Each module should have a `<tool>_result` rule — input-only aggregation point for subworkflow `use rule`:

```python
rule deepvariant_result:
    input:
        vcf = outdir + "/{sample_id}/{sample_id}.vcf.gz",
        tbi = outdir + "/{sample_id}/{sample_id}.vcf.gz.tbi"
```

# Config key patterns

| Key | When to use |
|---|---|
| `samples` | Single sample list (most modules) |
| `paired_samples` / `single_samples` | Alignment modules |
| `sample_groups` | Grouping (StringTie) |
| `sample_somatic_vcf_dict` / `sample_group_dict` | Spectrum-style cohort analysis |
| `bam_dir` / `vcf_dir` | Separate input locations (hiphase) |
| `ROOT_DIR` | **MANDATORY in all module configs** — common.smk uses it to locate `src/` and `bin/` scripts. Default `"."` will cause path errors if omitted. |
| `Procedure` | Tool executable paths |
| `Params` | Tool-specific parameters |
| `genome` | Reference file paths |

# Module .json template (standard)

```json
{
    "indir": "input",
    "outdir": "output",
    "logdir": "logs",
    "samples": [],
    "Procedure": { "<tool>": null },
    "Params": { "<tool>": {} },
    "genome": { "fasta": null }
}
```

# Module .yaml template

```yaml
name: <tool>
channels:
  - conda-forge
  - bioconda
  - defaults
dependencies:
  - <tool>>=<version>
```

# Subworkflow pattern

```python
shell.prefix("set -x; set -e;")
from snakemake.logging import logger

indir = config.get("indir", "data/fastq")
outdir = config.get("outdir", "output")
logdir = config.get("logdir", "logs")
outfiles = config.get("outfiles", [])
samples = config.get("samples", [])
ROOT_DIR = config.get("ROOT_DIR", ".")

rule all:
    input:
        outfiles

# Module config dict — name: <module>_config
# ROOT_DIR is MANDATORY in every module config
tool_config = {
    "indir": indir,
    "outdir": f"{outdir}/<tool>",
    "logdir": logdir,
    "samples": samples,
    "ROOT_DIR": ROOT_DIR,
    "Procedure": {
        "<tool>": config.get("Procedure", {}).get("<tool>")
    },
    "genome": {
        "fasta": config.get("genome", {}).get("fasta")
    }
}
module <tool>:
    snakefile: "../modules/<tool>/<tool>.smk"
    config: <tool>_config
logger.info(f"<tool>_config: {<tool>_config}")
use rule <rule_name> from <tool> as <Workflow>_<rule_name>
```

Key conventions:
- Config dict named `<tool>_config`
- Rule aliasing: `use rule X from Y as <Workflow>_X`
- Conditional modules: wrap in `if not skip_<X>:` blocks — see `references/optional-module-pattern.md` for full pattern
- Chain outputs: module B's `indir` = module A's `outdir`
- **`ROOT_DIR` is MANDATORY in every module config** — common.smk uses it to locate `src/` and `bin/` scripts. Default `"."` will cause path errors.

# run.py integration

## run<Workflow>() function signature

```python
def run<Workflow>(
    datajson: Dict[str, Any],
    samples_info_dict: Dict[str, Any],
    indir: str,
    outdir: str,
):
```

Note: workflows without design pairs (like PacVar for PacBio) don't need `designPair` parameter. Only Mutation-style workflows need it.

## run.py extra_args: multi-value support

`parse_args()` supports three forms of extra CLI arguments:

```
--key=value          → extra_args["key"] = "value"       (string)
--key value          → extra_args["key"] = "value"       (string, single value)
--key v1 v2 v3       → extra_args["key"] = ["v1","v2","v3"]  (list, multi-value)
--flag               → extra_args["flag"] = True         (boolean flag)
```

Multi-value collection stops at the next `--` token or end of args.
Single-value args stay as scalar (not wrapped in list).

`smart_cast()` handles lists by converting each element independently:
```python
["1","2","3"]          → [1, 2, 3]
["1.5","true","hello"] → [1.5, True, "hello"]
```

Dot-notation multi-value args work with `dict_set_by_path()`:
```bash
python run.py -m meta.tsv -w tRNAseq -o out \
  --Params.cutadapt.adapters AAAAAAAACAAAAAAAAAA A$ AA$
# → config["Params"]["cutadapt"]["adapters"] = ["AAAAAAAACAAAAAAAAAA", "A$", "AA$"]
```

**Caveat**: Flat (non-dot) multi-value args go through `workflow_config.update()`,
which can overwrite existing dict values with lists. Prefer dot-notation for
nested config parameters.

## Inside run<Workflow>()

1. Set `datajson["ROOT_DIR"]`, `indir`, `outdir`, `logdir`
2. Build `outfiles` list by iterating `samples_info_dict`
3. Set `datajson["samples"]`, `datajson["outfiles"]`
4. Write `raw.json` to outdir

## Wiring into main block

```python
# In parse_args():
parser.add_argument('-w', '--workflow_name', type=str, nargs='+',
    choices=["...", "<Workflow>"], ...)

# WORKFLOW_DISPATCH mapping (replaces if/elif chain):
WORKFLOW_DISPATCH = {
    "<Workflow>": lambda cfg, sid, dp, indir, outdir: ("<Workflow>.smk", run<Workflow>(cfg, sid, indir, outdir)),
    ...
}

# In __main__:
smk, input_json = WORKFLOW_DISPATCH[wf_name](
    deepcopy(workflow_config), samples_info_dict, designPair, raw_fastq_dir, abs_outdir
)
```

# Nextflow-to-Snakemake porting pattern

When porting an nf-core Nextflow pipeline:

1. **Read the main workflow** (`workflows/<name>.nf`) to understand the DAG
2. **Read each subworkflow** (`subworkflows/local/*/main.nf`) for step sequences
3. **Map Nextflow operators to Snakemake**:
   - `process` → `rule` in a module .smk
   - `workflow` → subworkflow .smk
   - `Channel.join()` → Snakemake rule input dependencies
   - `Channel.combine()` → may need separate rules or config
   - `if (params.X)` → `if not config.get("Params", {}).get("skip_X")`
4. **Map Nextflow modules** (`modules/nf-core/*/main.nf`) → Snakemake modules
5. **Preserve the step order**: align → sort → index → call → phase → etc.

# Pitfalls

## 0. Always write all 3 files together (.smk + .json + .yaml)

When creating or updating a module, you MUST write/update all three files in one pass: `<tool>.smk`, `<tool>.json`, and `<tool>.yaml`. Do NOT write just the .smk and stop — the user expects the config template and conda env to be synchronized with the rules.

The .json must reflect every `config.get()` call in the .smk (comparisons, Params sub-keys, genome keys, etc.). The .yaml must list all Python/system dependencies the bin/ scripts actually import.

**User correction** ("按照流程文档,你需要同步编写json和yaml"): writing only the .smk without .json/.yaml is an incomplete deliverable.

## 1. execute_code with Snakemake content

Do NOT use `execute_code` with triple-quoted strings containing Snakemake syntax — the shell backslash escapes and nested quotes cause SyntaxError. Use `write_file` tool directly for each file.

## 2. Patch insertion position

When inserting a new function before an existing one in run.py via `patch`, be precise about the context. A bad `old_string` match can corrupt the file. Always verify with `read_file` after patching, and compile-check with:
```bash
python -c "import py_compile; py_compile.compile('run.py', doraise=True)"
```

## 3. Module conda env path in subdirectories

Subdirectory rules must use `conda: "../<parent>.yaml"` (relative path to parent's yaml), not `"../modules/<tool>/<tool>.yaml"`.

## 4. Rule name conflicts

When importing the same module twice (e.g., hiphase for SNP and SV), use distinct aliases:
```python
module hiphase_snp:
    snakefile: "../modules/hiphase/hiphase.smk"
    config: hiphase_snp_config
module hiphase_sv:
    snakefile: "../modules/hiphase/hiphase.smk"
    config: hiphase_sv_config
use rule hiphase_phase from hiphase_snp as PacVar_hiphase_snp
use rule hiphase_phase from hiphase_sv as PacVar_hiphase_sv
```

## 5. outfiles path consistency

The `outfiles` in `run<Workflow>()` must exactly match the output paths in the rules. A mismatch causes Snakemake to fail silently or rebuild everything.

## 6. Aggregation report rules

When a module produces per-sample outputs that need a cross-sample summary, add an aggregation rule that collects all sample outputs and runs a summary script. The summary script should live in the module's `bin/` directory and accept explicit file paths (not directory scanning):

```python
rule <tool>_report:
    input:
        passed = expand(outdir + "/{sid}/{sid}_passed.tsv", sid=samples),
        discarded = expand(outdir + "/{sid}/{sid}_discarded.tsv", sid=samples),
    output:
        report = outdir + "/<tool>_report/per_sample_summary.tsv"
    params:
        script = os.path.join(ROOT_DIR, "modules/<tool>/bin/summarize.py")
    run:
        cmd = [
            "python", params.script,
            "-p", ",".join(input.passed),
            "-d", ",".join(input.discarded),
            "-o", outdir + "/<tool>_report",
        ]
        shell(" ".join(cmd) + " > {log} 2>&1")
```

Key points:
- The summary script uses `-p` (comma-separated passed files) and `-d` (discarded files), not `--indir`
- The script can ALSO support `--indir` as an alternative for standalone use (mutually exclusive argparse group)
- Output goes to a subdirectory (e.g. `<tool>_report/`) not a single flat file, since the script produces multiple outputs (TSV tables, HTML report, figures)
- The rule's `output` points to one representative file (e.g. `per_sample_summary.tsv`) for Snakemake dependency tracking

## 7. ALL rules must use `run:` blocks (no pure `shell:` allowed)

The project convention is **unified `run:` block style only**. Pure `shell:` blocks
are not allowed, even for simple single commands. Every rule must:
1. Use `run:` block with cmd list construction
2. Generate a `.sh` script file (with timestamp in name)
3. Log start/end with `setup_logger`
4. Wrap in try/except with error written to log

Rationale:
- Pure `shell:` blocks can't log structured events (timestamp, sample, start/end)
- Pure `shell:` blocks can't append error info to log on failure
- Pure `shell:` blocks can't dynamically build parameter lists
- Unified style reduces maintenance cost — all rules have predictable behavior

See `modules/modules.md` "规则编写风格" section for the canonical template.

## 7b. Multi-word params in `" ".join(cmd)` — quote individually

When a parameter value contains spaces (e.g. Java JVM options, complex filter strings),
`" ".join(cmd)` will NOT preserve the grouping. The shell treats each space-separated
token independently, so the tool only receives the first word.

**Broken** — GATK only gets `-Xms20g`, the rest become separate shell commands:
```python
params.javaOptions = "-Xms20g -XX:GCTimeLimit=50 -XX:GCHeapFreeLimit=10"
cmd = [params.gatk, "--java-options", params.javaOptions, "HaplotypeCaller", ...]
# Generates: gatk --java-options -Xms20g -XX:GCTimeLimit=50 -XX:GCHeapFreeLimit=10 HaplotypeCaller
# Error: '-XX:GCTimeLimit=50' is not a valid command
```

**Fixed** — wrap the multi-word value in quotes so the shell keeps it as one token:
```python
cmd = [params.gatk, "--java-options", f'"{params.javaOptions}"', "HaplotypeCaller", ...]
# Generates: gatk --java-options "-Xms20g -XX:GCTimeLimit=50 -XX:GCHeapFreeLimit=10" HaplotypeCaller
```

**Pattern**: Any parameter whose value is a space-separated string of sub-arguments
needs `f'"{value}"'` wrapping when building cmd lists for `" ".join()`:
- `--java-options "Xms... Xmx... XX:..."` (GATK/Picard)
- `--filter-expression "FS > 20.0 && QD < 2.0"` (bcftools/GATK)
- `--add-args "--flag1 value1 --flag2 value2"` (tools wrapping other tools)

The error message `'-XX:GCTimeLimit=50' is not a valid command` is the telltale sign
of this bug — the JVM flag is being executed as a shell command.

## 8. run block script timestamp
## 8. run block script timestamp — NO SPACES in format
Use `current_time` to avoid parallel conflicts. **Format must not contain spaces or unquoted special characters** — the path is interpolated into `shell(f"bash {script} ...")` where spaces break tokenization:

```python
# CORRECT
current_time = time.strftime("%Y%m%d_%H%M%S", time.localtime())
script = f"{outdir}/{wildcards.sample_id}/tool_{current_time}.sh"

# BROKEN — space in path causes shell to split it into two arguments
current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
```

Symptom: `bash: .../tool_2026-06-14: No such file or directory` — bash sees the space and treats everything after it as a separate argument.

## 8b. Snakemake --rerun-triggers input requires metadata
When `--rerun-triggers input` is used, Snakemake compares input file content hashes against `.snakemake/metadata/`. If metadata is empty (first run, or `.snakemake/` was recreated), Snakemake has **no baseline** and re-runs ALL rules regardless of whether output files exist.

Key behaviors:
- Empty metadata + `--rerun-triggers input` = **all rules re-run** (touch has no effect)
- Empty metadata + default triggers (mtime) = timestamp comparison works, touch effective
- Dry-run does NOT write metadata — only actual execution does
- Missing declared output files (e.g. `.bai`) cause **cascading re-runs** of all downstream rules, even if other outputs exist
- `touch` on files without metadata makes Snakemake treat them as "updated" → cascades downstream

Debugging checklist when all rules re-run despite existing outputs:
1. Check `ls .snakemake/metadata/ | wc -l` — if 0, metadata is missing
2. Check `--rerun-triggers` — if `input` and metadata empty, that's the cause
3. Check every declared output of every rule exists (one missing `.bai` cascades everything)
4. Check `--reason` output for "Updated input files" or "Input files updated by another job" — traces the cascade chain

## 8c. conda yaml channel order
Channel order MUST be `conda-forge → bioconda → defaults`. bioconda depends on conda-forge packages; wrong order causes solver failures:
```yaml
channels:
  - conda-forge
  - bioconda
  - defaults
```

## 9. expand() wildcard escaping

Escape external wildcards with double braces `{{}}` inside `expand()`:
```python
expand(outdir + "/{case}/{case}.{{genome_version}}.msisensor", case=samples.index)
```

## 11. Read-only constraint on run.py

When user says "don't modify existing code, only add new files":
- Cannot add `run<Workflow>()` to run.py or wire into `__main__`
- Create standalone `run_<Workflow>.py` at project root instead
- Standalone script: loads config template, accepts CLI args, generates raw.json, calls snakemake
- See `references/karrseq-porting-case.md` for full example

## 12. STAR module doesn't output chimeric SAM

The existing `modules/star/star.smk` doesn't output `Chimeric.out.sam`. If a workflow needs chimeric output:
- Option A: Embed STAR rule directly in subworkflow with custom output (KARRseq approach)
- Option B: Modify star.smk to optionally output chimeric (requires existing code modification)
- Option C: Create a new `karrseq_star` module variant (if reuse across multiple workflows)

## 13. Renaming a workflow

When user asks to rename workflow X to Y, all of these must change:

1. **Files**: `mv subworkflow/X.smk subworkflow/Y.smk`, `mv config/X.json config/Y.json`
2. **Rule prefixes in subworkflow**: Replace all `X_` prefixes with `Y_` (use `replace_all=true` in patch)
3. **Function in run.py**: `runX()` → `runY()` (function name + docstring)
4. **parse_args choices**: Update the `choices=[...]` list
5. **__main__ elif block**: Update condition string, function call, smk filename
6. **README.md files**: Both main and subworkflow README

Common pitfall: forgetting to update rule prefixes inside the subworkflow .smk file. Search for the old prefix with `search_files` after renaming to catch any stragglers.

## 14. IP/Input sample mapping for peak calling workflows

For ChIP-seq / DIP-seq / any peak calling workflow, samples have a design attribute (`ip` or `input`). The `run<Workflow>()` function must:
- Separate `ip_samples` and `input_samples` from `samples_info_dict`
- Build `sample_ip_input_map: Dict[str, Optional[str]]` mapping each IP sample to its control Input
- Pass this map to the subworkflow config
- In the module's MACS3 rule, use `unpack()` to conditionally include control BAM

See `references/peak-calling-pattern.md` for full implementation example.

## 13. IP/Input control mapping for ChIP-seq/DIP-seq

For peak calling workflows, need `sample_ip_input_map` in config:
```json
{
    "ip_samples": ["IP_sample1", "IP_sample2"],
    "input_samples": ["Input_sample1"],
    "sample_ip_input_map": {
        "IP_sample1": "Input_sample1",
        "IP_sample2": "Input_sample1"
    }
}
```

runDIPseq() builds this mapping automatically from sample_info.design field.

## 14. Multi-genome subworkflow pattern

When workflow supports multiple genomes (e.g., mm + hg38), iterate over genomes in subworkflow:
```python
genomes = config.get("genomes", ["mm"])
for genome in genomes:
    bowtie2_config = {...}
    module bowtie2_align:
        snakefile: "../modules/bowtie2/bowtie2.smk"
        config: bowtie2_config
    use rule bowtie2_align_paired from bowtie2_align as DIPseq_bowtie2_align_paired
```

## 15. Comprehensive README documentation when adding workflows

When adding a new workflow, the README update checklist (items 7-8) is NOT just about the new workflow. You must:

1. **Scan subworkflow/ directory** for ALL .smk files: `ls subworkflow/*.smk`
2. **Compare against README.md table** — every .smk must appear in the supported workflows table
3. **Compare against subworkflow/README.md** — every .smk must have a description section
4. **Compare against run.py choices** — check if all .smk workflows are registered in `parse_args()`

Common mistake: only adding the new workflow to README while missing existing workflows (e.g., Mutation, PacVar, KARRseq, ncRNAseq, RNA_SNP were all missing from README.md table when PeakCalling was added).

```bash
# Quick check: list all subworkflows vs what's documented
ls subworkflow/*.smk | xargs -I{} basename {} .smk
# Then grep README.md for each name
```

## 16. Parallel execution of multiple subworkflows

`run.py -w WorkflowName` launches ONE snakemake process. To run multiple workflows
in parallel (e.g., PacVar + Mutation), each needs its own snakemake process with
**isolated `.snakemake/` directory**.

### Why `.snakemake/` isolation matters

Snakemake creates `.snakemake/` in the process cwd, containing:
- `locks/` — file-based locks keyed by output path
- `metadata/` — per-job metadata (files keyed by output path)
- `iocache/` — IO cache (SQLite, NOT safe for concurrent writes)
- `incomplete/` — incomplete job markers

Two processes sharing the same `.snakemake/` risks:
- SQLite write conflicts in iocache
- Metadata corruption if workflows have overlapping output paths
- Lock contention

### Implementation: `-w` accepts multiple workflows

`run.py` changes:
1. `-w` accepts `nargs='+'`: `parser.add_argument('-w', '--workflow_name', nargs='+', ...)`
2. Replace if/elif dispatch chain with `WORKFLOW_DISPATCH` mapping dict
3. Thread allocation: `threads_per_workflow = max(1, total_threads // n_workflows)`
   — user's `-t` is TOTAL threads, NOT per-workflow
4. Each workflow launches from its own `abs_outdir` as cwd

```python
WORKFLOW_DISPATCH = {
    "CoCulture":  lambda cfg, sid, dp, indir, outdir: ("CoCulture.smk", runCoCulture(cfg, sid, indir, outdir)),
    "PacVar":     lambda cfg, sid, dp, indir, outdir: ("PacVar.smk",    runPacVar(cfg, sid, indir, outdir)),
    "Mutation":   lambda cfg, sid, dp, indir, outdir: ("Mutation.smk",  runMutation(cfg, sid, dp, indir, outdir)),
    # ... etc
}

# In __main__:
workflow_names = args.workflow_name
n_workflows = len(workflow_names)
threads_per_workflow = max(1, args.threads // n_workflows)

smk_cmds = []
for wf_name in workflow_names:
    abs_outdir = os.path.abspath(os.path.join(args.output_dir, wf_name))
    os.makedirs(abs_outdir, exist_ok=True)
    smk, input_json = WORKFLOW_DISPATCH[wf_name](...)
    cmd = build_snakemake_cmd(ROOT_DIR, smk, input_json, threads_per_workflow, ...)
    smk_cmds.append((cmd, abs_outdir))

if n_workflows == 1:
    _run_cmd(smk_cmds[0][0], cwd=smk_cmds[0][1])
else:
    _run_cmds_parallel(smk_cmds)
```

`CmdUtil.py` changes:
- `_run_cmd(cmd, cwd=None)` — pass cwd to `subprocess.run`
- `_run_cmds_parallel(cmds)` — launches all via `subprocess.Popen`, waits, checks exit codes

### dry_run MUST flow through to snakemake

Do NOT short-circuit dry_run in run.py. The `--dry-run` flag is passed to snakemake
via `build_snakemake_cmd` — snakemake itself shows the execution plan. Always build
and execute the cmd, even in dry_run mode.

### Why NOT a Master.smk with `use rule *`

Snakemake's `module` + `use rule` does not support nesting: if PacVar.smk already
uses `module` + `use rule` to import pbmm2/samtools/etc., importing PacVar.smk
into a Master.smk via `use rule *` resolves the inner modules during parsing, but
the subworkflow's top-level variable assignments (`outdir = config.get(...)`) all
execute in the Master.smk context, causing variable name collisions across workflows.
Also, `conda:` relative paths resolve against the importing file, not the original.

## 17. Cross-module dependencies via config

When module B needs output from module A (e.g., telomere needs centromere's
assembly), pass the output directory via config:

```python
# In subworkflow:
telomere_config = {
    ...
    "assembly_dir": f"{outdir}/repeat/centromere",  # where centromere outputs
    ...
}
```

In module B's .smk, construct the input path:
```python
assembly_dir = config.get("assembly_dir", "")

def get_assembly_fasta(wildcards):
    if assembly_dir:
        return os.path.join(assembly_dir, f"{wildcards.sample_id}/assembly/asm.bp.p_ctg.fa")
    return os.path.join(outdir, f"../centromere/{wildcards.sample_id}/assembly/asm.bp.p_ctg.fa")
```

Key points:
- Config key names the DIRECTORY, not individual files (module A's internal
  structure may change)
- Module B constructs paths using known conventions from module A
- Fallback path allows standalone use without the subworkflow
- This is cleaner than `rules.centromere_assemble.output.fasta` which creates
  hard coupling between modules

## 18. Use established bioinformatics tools, don't reinvent

When the user (or prior discussion in the session) has identified an established
tool for a task (e.g., Telogator2 for telomere, RepeatMasker for centromere),
**wrap that tool in a Snakemake module** — do NOT write a custom Python script
reimplementing the same logic. Custom scripts are only for:
- Parsing/summarizing tool output (e.g., extracting stats from RepeatMasker `.out`)
- Visualization (plotting from tool TSV output)
- Glue logic between tools

If the user explicitly discussed and agreed on a tool earlier in the session,
honoring that decision is mandatory. Writing a regex-based reimplementation when
Telogator2 was already agreed upon is a waste of effort and produces inferior results.

## 19. Missing declared output files cause full cascade re-run

When a rule declares an output file that doesn't exist on disk, Snakemake MUST re-run
that rule. ALL downstream rules then get reason "input files updated by another job",
causing a full cascade re-run of the entire DAG — even if most other outputs exist.

**Debugging pattern**: When Snakemake dry-run shows all rules re-running, check the
UPSTREAM rules first. One missing output file at the top of the DAG cascades to everything.

**Example**: `pbmm2_align` declares `.sorted.bam` + `.sorted.bai` as outputs. If `.sorted.bai`
is missing (never created, or deleted), pbmm2_align must re-run → addReadsGroup input
"updated by another job" → MarkDuplicates → HaplotypeCaller → ... all 28 jobs re-run.

**Fix**: `samtools index -@ N input.bam output.bai` to create the missing index. Or `touch`
if only dry-run matters. But for actual execution, the index must be valid.

**Verification**: `find <outdir> -name "*.bai" -o -name "*.tbi" -o -name "*.csi" | wc -l`
Compare against expected count. Missing indices are the #1 cause of phantom cascade re-runs.

## 20. `--rerun-triggers input` with empty `.snakemake/metadata/`

The `--rerun-triggers input` flag tells Snakemake to re-run only when input file CONTENT
changes (hash-based). This requires `.snakemake/metadata/` to store baseline hashes from
the previous run. If metadata is empty (no previous run, or `.snakemake/` was recreated),
Snakemake has NO baseline to compare against → defaults to re-running ALL rules.

Changing to `--rerun-triggers mtime` (timestamp-based) doesn't help either — without metadata,
other triggers (`code`, `params`, `software-env`) also fail to compare and re-run.

**Root cause**: `.snakemake/metadata/` being empty. Common reasons:
- First run that errored before any rule completed (MissingInputException during DAG build)
- `.snakemake/` directory was deleted/recreated
- Workflow run from different working directory

**Fix**: Let one full run complete successfully — metadata is written per-rule as each rule
finishes. Subsequent runs will have the baseline for comparison.

## 21. BAI index naming: GATK vs samtools

GATK `--CREATE_INDEX true` creates `{name}.bai` (replaces `.bam` with `.bai`).
`samtools index file.bam` creates `{name}.bam.bai` (appends `.bai`).
`samtools index file.bam -o name.bai` creates the exact name specified.

When writing input functions that construct BAI paths, be explicit about which convention
the upstream rule uses:

```python
# If upstream uses GATK --CREATE_INDEX true:
in_dict["bai"] = f"{dir}/{sid}.{substring}.bai"

# If upstream uses samtools index (default):
in_dict["bai"] = f"{dir}/{sid}.{substring}.bam.bai"

# If upstream uses samtools index -o:
in_dict["bai"] = f"{dir}/{sid}.{substring}.bai"  # matches the -o name
```

## 22. Missing `use rule` for intermediate rules

When a module has multiple rules (e.g., `HaplotypeCaller` → `filterHaplotypeCallerVcf`),
**every rule that produces a file needed by another rule must be imported** via `use rule`.
Forgetting to import intermediate rules causes MissingInputException — Snakemake can't
find a rule in the DAG to produce the expected file.

**Checklist**: After importing a module, trace the dependency chain:
- Rule A produces `.raw.vcf.gz`
- Rule B takes `.raw.vcf.gz` and produces `.filtered.vcf.gz`
- Rule C (in another module) needs `.filtered.vcf.gz`
→ Both `use rule A` AND `use rule B` must be present in the subworkflow.

## 23. Stale file reads when debugging

When debugging file-existence issues, ALWAYS re-read files fresh. The `read_file` tool
may return cached content from earlier in the session. If the user says "you're being
confused by old cache" or "re-read the file", do it immediately — trust the user.

**Pattern**: When investigating MissingInputException:
1. `find <outdir> -type f | sort` — get ACTUAL files on disk (fresh)
2. `read_file <smk>` — re-read the rule file (may need fresh read)
3. Compare declared outputs vs actual files
4. Check timestamps: `stat -c '%y %n' <file>`

Do NOT rely on earlier `search_files` or `read_file` results when debugging — they may
be stale.

## 24. Conda htslib/bcftools dependency conflicts

When htslib or bcftools have version-pinned dependencies that cause cascading conflicts (libcurl → libnghttp2 → c-ares chain), the fix is to **remove explicit transitive dependencies**:

```yaml
# BROKEN — explicit htslib/bcftools pins conflict with pbsv's transitive deps
dependencies:
  - pbsv=2.11.0
  - htslib==1.23.1
  - bcftools==1.23.1

# FIXED — let pbsv pull compatible htslib/bcftools automatically
dependencies:
  - pbsv=2.11.0
```

Root cause: bioconda packages like htslib pin libcurl versions, which pin libnghttp2, which pin c-ares. When the solver can't find a consistent set across all pins, it fails. The main package (pbsv, samtools, etc.) already declares its own compatible transitive deps — adding explicit pins for them is redundant and causes conflicts.

If you need htslib/bcftools tools directly (e.g., `bcftools view`), add them in a SEPARATE conda env or use the main package's bundled versions.

## 25. Tool input format requirements (BAM vs FASTQ)

When wrapping a new tool, ALWAYS verify what input formats it actually accepts. Don't assume — check `--help` or usage output.

**General rule**: Run `<tool> --help` or `<tool> <subcommand> --help` BEFORE writing any
cmd list in a Snakemake rule. Tool APIs change between versions — flags get renamed,
subcommands get added/removed, positional args change order.

**Example — hifiasm 0.25.0**:
- Usage says `<in_1.fq> <in_2.fq> <...>` — expects FASTQ, NOT BAM
- Old versions (0.16-0.19) had `--hifi` flag; 0.25.0 removed it (positional args only)
- Passing a valid BAM file produces `counted 0 distinct minimizer k-mers` then malloc crash

**Pattern**: When a tool needs FASTQ but the pipeline has BAM, add a `samtools fastq` conversion step:
```python
# In the run block:
fq_gz = f"{outdir}/{sid}/assembly/{sid}.hifi.fq.gz"
cmd0 = ["samtools", "fastq", "-@", str(threads), input.bam, "|", "gzip", "-c", ">", fq_gz]
cmd1 = ["tool", "-o", prefix, "-t", str(threads), fq_gz]
cmd_cleanup = ["rm", "-f", fq_gz]
```

Also check tool version-specific flags — flags can be added/removed between major versions.

## 26. Unit testing Snakemake rules — test generated scripts directly

When debugging rule failures, don't re-run the entire Snakemake DAG. Each `run:` block
generates a `.sh` script in the output directory. Test it directly:

```bash
# Find the latest script
ls -lt output/<workflow>/<module>/tool_*.sh | head -1

# Run it directly (unit test)
bash output/<workflow>/<module>/tool_20260614_191530.sh

# Check the log
cat output/<workflow>/log/<sample_id>/<rule>.log
```

This isolates the failing rule from Snakemake's dependency tracking. Fix the script,
verify it works, then update the `.smk` code.

After fixing, re-run just that job:
```bash
snakemake --snakefile workflow.smk --configfile raw.json \
  --target-jobs 'rule:tool:wildcards.sample=S1' \
  --forcerun tool --cores 8
```

See `references/running-specific-steps.md` for comprehensive guide on targeting
specific rules, samples, and jobs.

## 27. Conda environment symlink workaround for missing tools

When a conda environment is missing a tool (e.g., samtools) and `conda install` times out
on large environments, symlink from another environment:

```bash
ln -sf /path/to/other/env/bin/samtools /path/to/target/env/bin/samtools
```

This is a temporary workaround. The proper fix is to add the dependency to the `.yaml`
file and let Snakemake recreate the environment.

## 28. RepeatMasker DEFAULT_SEARCH_ENGINE must be configured

RepeatMasker requires `DEFAULT_SEARCH_ENGINE` to be set in `RepeatMaskerConfig.pm`.
If empty, it fails with: `Search engine ( ) is unknown to RepeatMasker`.

**Fix**: Find the config file and set it:
```bash
find /path/to/env -name "RepeatMaskerConfig.pm" -path "*/share/*"
sed -i "s/'value' => ''/'value' => 'rmblast'/" /path/to/RepeatMaskerConfig.pm
```

Available engines: `rmblast`, `nhmmer`, `crossmatch`, `abblast`.

## 29. Incomplete run block — cmd built but never executed

A `run:` block can construct a `cmd` list but forget to write the script and call `shell()`.
This typically happens when someone writes a comment/docstring placeholder for the shell
command and forgets to replace it with actual execution code. The rule silently does nothing,
producing empty log files and missing outputs.

**Symptoms**:
- Log file exists but is empty (0 bytes)
- Output files never created
- Snakemake reports rule failure with no stderr

**Example — broken** (from centromere.smk repeatmasker_run):
```python
run:
    script = os.path.join(outdir, f"{wildcards.sample_id}/repeatmasker_{current_time}.sh")
    cmd = [params.RepeatMasker, "-species", params.species, "-pa", str(threads), ...]
    """                           # <-- docstring, NOT executed!
    mkdir -p {params.rm_dir}
    RepeatMasker -species {params.species} ...
    """
```

**Fixed** — write script + execute:
```python
run:
    script = os.path.join(outdir, f"{wildcards.sample_id}/repeatmasker_{current_time}.sh")
    cmd = [params.RepeatMasker, "-species", params.species, "-pa", str(threads), ...]
    with open(script, "w") as f:
        f.write("#!/bin/bash\n")
        f.write(f"mkdir -p {params.rm_dir}\n")
        f.write(" ".join(cmd) + "\n")
    shell(f"bash {script} > {log} 2>&1")
```

**Checklist** — every `run:` block that builds a `cmd` list MUST end with:
1. `with open(script, "w") as f:` — write the script
2. `f.write("#!/bin/bash\n")` — shebang
3. `f.write(" ".join(cmd) + "\n")` — the command(s)
4. `shell(f"bash {script} > {log} 2>&1")` — execute it

If you see a triple-quoted string (`"""..."""`) inside a `run:` block after `cmd` construction,
it's almost certainly a bug — that's a docstring being silently evaluated and discarded.

## 29. RepeatMasker -species must be scientific name or NCBI taxon ID

RepeatMasker's `-species` flag does NOT reliably accept common names. `"mouse"` is ambiguous
(33 matches in Dfam) and RepeatMasker exits with code 255:

```
Ambiguous search term 'mouse' (found 33 results, 2 exact).
Taxon "mouse" is not defined in the current FamDB partitions present.
```

**Fix**: Use the NCBI scientific name or taxonomy ID:
- `"Mus musculus"` (exact match, taxon 10090)
- `"Homo sapiens"` (exact match, taxon 9606)
- Or just the numeric taxon ID: `"10090"`, `"9606"`

**Always verify** with `famdb.py names "<species>"` before hardcoding:
```bash
# Using the conda env's Python (h5py required)
<env>/bin/python3 <env>/share/RepeatMasker/famdb.py \
  -i <env>/share/RepeatMasker/Libraries/famdb names "Mus musculus"
```

**Pitfall**: The default in `modules/centromere/centromere.smk` line 10 is:
```python
rm_species = config.get("Params", {}).get("RepeatMasker", {}).get("species", "mouse")
```
This default `"mouse"` will fail. Config must override with `"Mus musculus"` or the default
should be changed. Always check what the module default is — if it's a common name, override
in the workflow config JSON.

**Dfam completeness**: Conda-installed RepeatMasker bundles a condensed Dfam (e.g. Dfam 3.9
with 237 families). This is enough for species-level classification via taxon filtering,
but the full Dfam database (2000+ families) gives better coverage. If RepeatMasker reports
too few hits, consider downloading the full Dfam database.

## 30. Python imports at module top-level fail with `module` + `use rule`

When a module .smk is loaded via `module X:` + `use rule`, Snakemake executes the
module's top-level code **at parse time**, before any rules run. If the top-level
code does `sys.path.insert()` then `from xxx import yyy`, the import executes
immediately — and fails if the path is wrong, the config isn't fully populated yet,
or the module is being loaded from a different working directory than expected.

**Symptom**: `ModuleNotFoundError: No module named 'common'` even though
`ROOT_DIR` is set correctly in the config.

**Root cause**: `module centromere:` in the subworkflow triggers immediate loading
and execution of `centromere.smk` top-level code. The `config` dict IS available
(because `config: centromere_config` is passed), but path resolution depends on
the parsing context, which may differ from execution context.

**Broken pattern** (top-level import):
```python
# modules/centromere/centromere.smk — FAILS at parse time
import sys
import os
ROOT_DIR = config.get("ROOT_DIR", ".")
src_dir = os.path.join(ROOT_DIR, "src")
sys.path.insert(0, src_dir)
from common.LogUtil import setup_logger  # ← ModuleNotFoundError!
logger = setup_logger(__name__)
```

**Fixed pattern** (delayed import via helper function):
```python
# modules/centromere/centromere.smk
import sys
import os
import time

outdir = config.get("outdir", "output")
logdir = config.get("logdir", "log")
indir = config.get("indir", "input")
ROOT_DIR = config.get("ROOT_DIR", ".")

def _import_logger():
    """Import setup_logger from common.LogUtil (delayed to run time)."""
    src_dir = os.path.join(ROOT_DIR, "src")
    if not os.path.exists(src_dir):
        raise FileNotFoundError(f"Source directory not found: {src_dir}")
    if src_dir not in sys.path:
        sys.path.insert(0, src_dir)
    from common.LogUtil import setup_logger
    return setup_logger

rule my_rule:
    input: ...
    output: ...
    run:
        setup_logger = _import_logger()
        logger = setup_logger(logger_name="my_rule", log_file=log)
        # ... rest of run block ...
```

**Key points**:
- Standard library imports (`os`, `sys`, `time`) are safe at top level
- Third-party imports (`pandas`, `pysam`) are safe IF installed in the base env
- Project-internal imports (`from common.LogUtil import ...`) that depend on
  `sys.path` manipulation MUST be delayed to `run:` blocks
- Call `_import_logger()` (or equivalent) at the START of each `run:` block
- The helper returns the factory function; each rule calls it with its own log file
- If `PYTHONPATH` is set in `run.py` (see below), the `src_dir not in sys.path`
  check prevents redundant inserts

**Related**: If many modules need the same utility, set `PYTHONPATH` globally in
`run.py` so Snakemake subprocesses inherit it (see §31).

## 31. Sharing utilities across modules — PYTHONPATH in run.py

When multiple modules need the same utility (e.g., `LogUtil`, `CmdUtil`), there are
three approaches. **PYTHONPATH** is the simplest for this project.

### Option A: PYTHONPATH in run.py (recommended)

In `run.py`'s `__main__` block, before building snakemake commands:
```python
# run.py __main__
ROOT_DIR = os.path.dirname(__file__)
src_dir = os.path.join(ROOT_DIR, "src")
current = os.environ.get("PYTHONPATH", "")
if src_dir not in current.split(os.pathsep):
    os.environ["PYTHONPATH"] = f"{src_dir}{os.pathsep}{current}" if current else src_dir
```

This makes `from common.LogUtil import setup_logger` work in ANY subprocess
launched by run.py — including snakemake rule execution. The module .smk still
uses the delayed import pattern (§30), but the `_import_logger()` helper becomes
simpler since `sys.path` is already correct:

```python
def _import_logger():
    """Import setup_logger — PYTHONPATH already set by run.py."""
    from common.LogUtil import setup_logger
    return setup_logger
```

### Option B: Common snakefile via include (implemented)

Create `modules/common/common.smk` with shared imports, then `include:` it from
each subworkflow and module. See `templates/common_smk.snippet` for the template.

**Structure**:
```
modules/common/
  common.smk      # shared utilities
  README.md       # usage docs
```

**common.smk contents** — standard library + project utilities:
```python
import sys
import os
import time
import shutil

ROOT_DIR = config.get("ROOT_DIR", ".")
_src_dir = os.path.join(ROOT_DIR, "src")
if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

from common.LogUtil import setup_logger

def create_logger(logger_name, log_file, level=None):
    if level is None:
        import logging
        level = logging.INFO
    return setup_logger(logger_name=logger_name, log_file=log_file, level=level)
```

**Usage in subworkflow** (top of file):
```python
include: "../modules/common/common.smk"
```

**Usage in module** (top of file):
```python
include: "../common/common.smk"
```

Then in `run:` blocks, `setup_logger`, `time`, `shutil`, `os`, `ROOT_DIR` are
all available without additional imports.

**Caveats**:
- Included code runs in the including file's namespace — variable names can
  collide if two included files define the same name
- Each module that uses `module` + `use rule` must also `include:` common.smk
  (the include does NOT propagate from subworkflow into modules)
- If `config` is not available when the module is parsed (rare), the
  `config.get("ROOT_DIR")` call fails — fall back to Option A (PYTHONPATH)

### Option C: Python package (pip install -e)

Create `setup.py` in the project root, `pip install -e .`. Most robust but requires
an extra install step. Best for code shared across multiple independent projects.

## 32. `include:` does NOT propagate into `module` + `use rule`

When a subworkflow does `include: "../modules/common/common.smk"`, the included
code runs in the subworkflow's namespace. Modules loaded via `module X:` +
`use rule` are parsed independently — they do NOT inherit the subworkflow's
includes. Each module that needs shared utilities must include common.smk itself:

```python
# subworkflow/PacVar.smk
include: "../modules/common/common.smk"   # ← only for PacVar.smk's own code

module centromere:
    snakefile: "../modules/centromere/centromere.smk"
    config: centromere_config
# centromere.smk does NOT get setup_logger from PacVar.smk's include
```

```python
# modules/centromere/centromere.smk — must include independently
include: "../common/common.smk"
# Now setup_logger is available
```

**Symptom**: `NameError: name 'setup_logger' is not defined` in a module's
`run:` block, even though the subworkflow includes common.smk.

**Fix**: Add `include: "../common/common.smk"` at the top of every module .smk
that uses shared utilities.

## 33. Don't modify existing files when only asked to create new ones

When the user asks to "create a common module" or "add a new module", the scope is:
- ✅ Create new files (modules/common/common.smk, README.md, etc.)
- ✅ Update documentation files (modules.md, README.md)
- ❌ Do NOT modify existing subworkflow files (PacVar.smk, Mutation.smk, etc.)
- ❌ Do NOT modify existing module files (centromere.smk, gatk_germline.smk, etc.)

**User correction** ("你修改我的主流程PacVar.smk干什么"): modifying the main workflow
when only asked to create a shared module is a scope violation. The user decides
when and which existing files to update — the agent should only create new files
and update docs.

**Rule**: When the task is "create X" or "add Y", enumerate exactly which files
you'll create/modify and confirm before touching anything outside the new file set.
If you find yourself adding `include:` to an existing subworkflow as part of a
"create a common module" task — stop. That's a separate migration step the user
controls.

**Verification**: Always `git status` after changes. If it shows `modified:` on
files the user didn't ask to touch, revert with `git restore`.

## 39. Adding new analysis approaches to existing modules

When adding new analysis approaches to an existing module, there are two patterns:

**Pattern A: Unified module (user's preference for telomere)**
All approaches go in one module with `bin/` scripts. The module .yaml includes all
dependencies. This keeps related analyses together and simplifies the subworkflow.

**Pattern B: Separate modules (when approaches have very different dependencies)**
Each approach gets its own module. Use when dependencies are incompatible or when
the user explicitly requests separation.

**Always ask the user which pattern they prefer before implementing.**

Regardless of pattern, the extension checklist still applies:
1. Update `run.py` outfiles to match new rule outputs
2. Update `README.md` (main) — workflow table
3. Update `subworkflow/README.md` — workflow description

**User correction**: Initially split telomere into 4 modules, user said "拆分telomere模块,
恢复其原本样子" then "算了,不拆分了" — final decision was unified module.

## 35. Snakemake v9 `log` in `run:` blocks is a `Log` object, not a string

In Snakemake v9, the `log` variable inside `run:` blocks is a special `Log` object,
not a plain string path. Passing bare `log` to `open()`, `logging.FileHandler()`,
or any function expecting `str | bytes | os.PathLike` raises:

```
TypeError: expected str, bytes or os.PathLike object, not Log
```

**Broken**:
```python
run:
    open(log, "w").close()                          # TypeError!
    logger = setup_logger(log_file=log)              # TypeError in FileHandler!
    with open(log) as f:                             # TypeError!
        content = f.read()
```

**Fixed** — use `str(log)` everywhere `log` is used as a path:
```python
run:
    log_path = str(log)
    open(log_path, "w").close()
    logger = setup_logger(log_file=log_path)
    with open(log_path) as f:
        content = f.read()
```

`log[0]` also works (indexing the first log file), but `str(log)` is more readable
and consistent.

**Debugging symptom**: Snakemake main log shows `SpawnedJobError` with `returned
non-zero exit status 1`, but the rule-specific log files are **empty** (0 bytes).
The subprocess fails before the rule body executes, so nothing gets written to the
log. The actual error is in the subprocess's stderr.

**Debugging approach** — reproduce the exact subprocess command:
1. Find the `subprocess.CalledProcessError` in the main snakemake log
2. Copy the full `Command '...'` string from the traceback
3. Run it manually in terminal — Snakemake shows the actual TypeError

**Scope**: Affects ALL `run:` blocks that reference `log` as a path. Search the
codebase with `grep -rn "open(log" modules/` and `grep -rn "log_file=log" modules/`
to find all affected rules.

**Preferred pattern** — convert once at the top, use `log_path` everywhere:
```python
run:
    log_path = str(log)
    open(log_path, "w").close()
    logger = setup_logger(logger_name="my_rule", log_file=log_path)
    try:
        ...
    except Exception as e:
        # log_path is always accessible in except, even if logger failed to init
        with open(log_path, "a") as f:
            f.write(f"Error: {e}\n")
        raise
```

## 36. `conda:` only activates for `shell:` commands, NOT `run:` block Python

The `conda:` directive in Snakemake activates the conda environment **only for
`shell:` commands**. Python code inside `run:` blocks executes in the Snakemake
main process (typically the `smk` or base environment), NOT the rule's conda env.

**Broken** — `shutil.which()` runs in smk env, not the rule's conda env:
```python
rule repeatmasker_run:
    conda: "centromere.yaml"       # has RepeatMasker installed
    run:
        # This searches smk env's PATH, NOT centromere env's PATH!
        RepeatMasker_dir = shutil.which("RepeatMasker")  # returns None!
        if RepeatMasker_dir is None:
            raise FileNotFoundError("RepeatMasker executable not found")
```

**Fixed** — use `shell()` to run `which` inside the conda environment:
```python
run:
    # shell() runs in the conda env, so `which` finds the right binary
    RepeatMasker_dir = shell("which RepeatMasker", read=True).strip()
```

Or skip the check entirely and let the shell command fail with a clear error.

**Why this happens**: `conda:` in Snakemake wraps the shell command with conda
activation (`conda activate <env> && <cmd>`). But `run:` block Python runs in the
main Snakemake process — the conda env is never activated for Python code.

**Scope**: Any `run:` block that uses `shutil.which()`, `subprocess.run()`, or
other Python stdlib to interact with conda-installed tools will fail. The tools
exist in the conda env but are invisible to the Python process.

### Pitfall: `shell()` parameter is `read=True`, NOT `read_stdout=True`

Snakemake's `shell()` in `run:` blocks accepts `read=True` (not `read_stdout=True`)
to capture stdout. The function signature is:

```python
def __new__(cls, cmd, *args, iterable=False, read=False, bench_record=None, **kwargs):
```

`read_stdout=True` gets absorbed into `**kwargs` and passed to `format()` as a
template variable — it does NOT capture stdout. The variable receiving the result
will be `None` or the formatted command string, not the command's output.

**Broken**:
```python
RepeatMasker_dir = shell("which RepeatMasker", read_stdout=True)  # → None!
```

**Fixed**:
```python
RepeatMasker_dir = shell("which RepeatMasker", read=True).strip()
```

See `src/snakemake/shell.py` line 166-177 for the actual implementation.

## 38. Concurrent tool library cache conflicts — sentinel init rule pattern

When multiple samples run a tool that builds a shared library cache on first run
(RepeatMasker, BLAST databases, etc.), concurrent execution causes race conditions
on the shared cache directory. `makeblastdb` writing to the same path from multiple
processes produces corrupted databases or SIGABRT crashes.

**Pattern**: Add a one-time init rule that builds the cache, then make all sample
rules depend on it via a sentinel file:

```python
rule repeatmasker_init:
    """Build RepeatMasker library cache once."""
    output:
        touch(outdir + "/.repeatmasker_lib_init.done")
    log:
        logdir + "/repeatmasker_init.log"
    conda:
        "centromere.yaml"
    params:
        species = config.get("Params", {}).get("RepeatMasker", {}).get("species", "Mus musculus"),
        RepeatMasker = config.get("Procedure", {}).get("RepeatMasker") or "RepeatMasker"
    threads: 1
    run:
        import tempfile, shutil
        try:
            open(log[0], "w").close()
            logger = setup_logger(logger_name="repeatmasker_init", log_file=log[0])
            logger.info("Building RepeatMasker library cache (one-time init)")
            tmpdir = tempfile.mkdtemp()
            dummy_fa = os.path.join(tmpdir, "dummy.fa")
            with open(dummy_fa, "w") as f:
                f.write(">dummy\nATCGATCGATCG\n")
            cmd = [params.RepeatMasker, "-species", f"'{params.species}'",
                   "-pa", str(threads), "-dir", tmpdir, "-gff", dummy_fa]
            script = os.path.join(tmpdir, "init.sh")
            with open(script, "w") as f:
                f.write(" ".join(cmd) + "\n")
            shell(f"bash {script} >> {log[0]} 2>&1")
            shutil.rmtree(tmpdir, ignore_errors=True)
            logger.info("RepeatMasker library cache built successfully")
        except Exception as e:
            with open(log[0], "a") as f:
                f.write(f"RepeatMasker init failed with error: {e}\n")
            raise

rule repeatmasker_run:
    input:
        fasta = outdir + "/{sample_id}/assembly/asm.fa",
        lib_init = outdir + "/.repeatmasker_lib_init.done"  # ← blocks until cache ready
    # ... rest of rule
```

**DAG effect**:
```
hifiasm (per sample, parallel)
  └── repeatmasker_init (once, sequential)
       └── repeatmasker_run (per sample, parallel)
```

**Other tools with this issue**: any tool that builds shared index/cache on first
run — BLAST `makeblastdb`, BWA index, STAR genomeGenerate (if shared path).

## 39. Init rule gating: check actual database, not sentinel

When gating an init rule (like `tidk_init`, `repeatmasker_init`), the input
function should check the **tool's actual database/config file**, not a `touch`ed
sentinel in the output directory.

**Broken** — sentinel in output dir:
```python
def get_input(wildcards):
    sentinel = os.path.join(outdir, ".tidk_build.done")
    if not os.path.exists(sentinel):  # only works same-run, not cross-run
        in_dict["db_init"] = sentinel
```

**Fixed** — check actual database file:
```python
def get_input(wildcards):
    tidk_db = os.path.expanduser("~/.local/share/tidk/tidk_database.csv")
    if not os.path.exists(tidk_db):
        in_dict["db_init"] = outdir + "/.tidk_build.done"
```

**Why**: Sentinel files in the output directory are created by the init rule
during execution. At DAG construction time (when input functions run), the
sentinel doesn't exist yet — so the dependency is always added, and the init
rule always runs. The actual database file persists across runs and is the
real indicator.

**Pattern**: For each tool with an init rule, identify where the tool stores
its persistent state:
- tidk: `~/.local/share/tidk/tidk_database.csv`
- RepeatMasker: `<env>/share/RepeatMasker/Libraries/famdb/`
- BLAST: `<db_dir>/*.nsq` / `*.nin`

Check those files in the input function, not the sentinel.

## 40. Verify tool API before writing rules

When wrapping a tool, always verify the actual CLI flags with `<tool> --help`
and `<tool> <subcommand> --help` before writing rules. Documentation and
assumptions can be wrong.

**Example — tidk**: Assumed `tidk search -s <motif> -o <output> <fasta>` but
actual API is `tidk search --string <motif> --output <prefix> --dir <dir> <fasta>`.
Also assumed `tidk count` exists — it does NOT.

**Pattern**: Before writing a rule that calls a tool:
1. Run `<tool> --help` to see available subcommands
2. Run `<tool> <subcommand> --help` for the specific subcommand
3. Note the exact flag names (long vs short), required args, and positional args
4. Write the cmd list accordingly

## 37. Error handling: initialization outside try causes empty logs

When `open(log)` or `setup_logger()` is placed **outside** a `try` block and fails
(e.g., due to TypeError from §35), the `except` block never executes. The log file
remains empty, and the actual error message is lost.

**Broken** — error on line 1 escapes the try/except:
```python
run:
    open(log, "w").close()           # ← TypeError here, except never runs
    logger = setup_logger(log_file=log)
    try:
        shell("some_command > {log} 2>&1")
    except Exception as e:
        logger.error(f"Failed: {e}")  # ← never reached
        raise
```

Result: log file is empty (0 bytes), Snakemake shows `SpawnedJobError` with no
details. The user has no way to diagnose what went wrong.

**Fixed** — initialization inside try, with fallback logging in except:
```python
run:
    log_path = str(log)
    try:
        open(log_path, "w").close()
        logger = setup_logger(logger_name="my_rule", log_file=log_path)
        shell("some_command > {log_path} 2>&1")
    except Exception as e:
        # log_path is ALWAYS accessible (it's from outer scope)
        with open(log_path, "a") as f:
            f.write(f"Error: {e}\n")
        raise
```

**Key insight from user correction**: The user explicitly said "这次就是因为放在
try外面,导致日志没有捕获" — initialization outside try is the direct cause of
empty log files. Always put `open(log)` and `setup_logger()` inside the try block.
Use `log_path` (not `logger`) in except for fallback logging, since `logger` may
not be defined if `setup_logger()` itself failed.

## 34. Snakemake parser architecture (how .smk becomes Python)

Snakemake uses a tokenizer-based state machine (`parser.py`) to transform .smk
files into executable Python. Key classes:
- `Python` — top-level automaton, passes non-keyword tokens through unchanged
- `Rule` — converts `rule name:` to `@workflow.rule(name=...)` decorator
- `Run` — converts `run:` block to `@workflow.run` + function definition
- `Shell` — converts `shell:` to `@workflow.shellcmd(...)` + `shell()` call
- `Input`/`Output`/`Params` etc. — convert to `@workflow.input(...)` etc.

**Implication**: Snakefile IS Python. Any valid Python at the top level executes
during parsing. `rule`, `shell`, `run` etc. are NOT Python keywords — they're
recognized by the tokenizer only when they appear at the start of a line.

See `references/snakemake-parser-architecture.md` for full analysis.

## 29. telogator2 API — short flags only

telogator2 uses short flags, not long flags:
- `-i` for input (not `--reads`)
- `-o` for output directory (not `--output`)
- `-r hifi` for read type (not `--threads`)
- `-c` for threads (not `--threads`)

Also: telogator2 needs an aligner (minimap2 by default) in PATH.

## 43. Singularity/Apptainer container bind mounts — files outside working directory

When a Snakemake rule uses `container:` directive with `--sdm apptainer`, Snakemake only
binds the working directory and a few standard paths (e.g. source-cache) into the container.
**Files outside the working directory tree are NOT automatically bound** — even if they're
declared as `input:` in the rule.

**Symptom**: Tool inside container reports "file not found" (e.g. FASTA index `.fai`), but
the file exists on the host. The error comes from inside the container, not the host.

**Root cause**: Singularity only sees paths that are explicitly bound. Reference genomes,
external databases, or any path under `/data/pub/zhousha/Reference/` etc. won't be visible
inside the container unless bound.

**Fix** — add `--singularity-args` via `run.sh`:
```bash
--snakemake-args --sdm apptainer --singularity-args '--bind /data/pub/zhousha/Reference'
```

Because `--snakemake-args` uses `nargs=REMAINDER`, everything after it is forwarded verbatim
to snakemake. Multiple bind paths: `--bind /path/a,/path/b` or repeat `--bind`.

**Why symlinks DON'T work**: Singularity resolves symlinks inside the container's filesystem
namespace. A symlink at `outdir/ref/genome.fa -> /data/pub/zhousha/Reference/genome.fa`
still points to `/data/pub/zhousha/Reference/genome.fa` inside the container, where that
path doesn't exist. The symlink target must be bound, not the symlink itself.

**Debugging checklist when containerized tools report "file not found"**:
1. Verify the file exists on the host: `ls -lh <path>`
2. Verify INSIDE the container: `singularity exec <sif> ls -lh <path>`
3. If host OK but container fails → bind mount missing
4. Add `--singularity-args '--bind <parent_dir>'` to run.sh

**User correction**: When analyzing logs that report missing files, ALWAYS verify actual file
existence (host AND container) before concluding the file is missing. Don't just trust the
log message — it may be a container mount issue, not a real missing file.

## 30. tidk API — `--string`, `--output`, `--dir` flags (NOT `-s`/`-o`)

tidk search uses long flags with different semantics than expected:

```bash
# CORRECT
tidk search --string TTAGGG --output <prefix> --dir <output_dir> <FASTA>
# Output: <output_dir>/<prefix>_telomeric_repeat.tsv

# BROKEN — these flags don't exist
tidk search -s TTAGGG -o output_dir assembly.fasta
```

There is NO `tidk count` subcommand in current versions (removed).
Always run `tidk search --help` to verify API before writing scripts.

**Error symptoms**:
- `error: the following required arguments were not provided: --dir <DIR>`
- `error: unrecognized subcommand 'count'`

## 45. Module config key naming must match subworkflow config dict

When creating a module, the config keys used in `config.get("Procedure", {}).get("<key>")`
and `config.get("Params", {}).get("<key>")` must match what the subworkflow actually passes.
A mismatch causes all optional parameters to silently fall back to defaults.

**Example — cutadapt module**:
Module `cutadapt.smk` uses:
```python
params.cutadapt = config.get("Procedure", {}).get("cutadapt") or "cutadapt"
params.quality  = config.get("Params", {}).get("cutadapt", {}).get("quality") or 20
```

But subworkflows (MERIP, RNAseq, PeakCalling) pass:
```python
cutadapt_config = {
    "Procedure": {"trim_galore": config.get(...)},  # key is "trim_galore", not "cutadapt"
    "Params": {"trim_galore": {"quality": 30}},     # key is "trim_galore", not "cutadapt"
}
```

Result: `config.get("Procedure", {}).get("cutadapt")` returns `None` → falls back to `"cutadapt"`.
Quality falls back to 20 instead of the intended 30. **Silent, no error.**

**Fix options**:
1. Module uses the key the subworkflow passes: `.get("trim_galore")` — but confusing
2. Subworkflow remaps keys: `"cutadapt": config.get(...).get("trim_galore")` — explicit
3. Module checks both: `.get("cutadapt") or .get("trim_galore")` — fragile, avoid

**Best practice**: When creating a module, check ALL existing subworkflows that reference it
with `search_files` for `module <name>:` and verify their config dict keys match your
`config.get()` calls. The module directory name and config key should be the same tool.

See `references/trimming-module-conventions.md` for trimming module specifics.

## 46. Data metadata file conventions (meta.tsv)

Project data directories contain `meta.tsv` with a standard header:
```
sample_id\tdata_id\tdesign\tfastq_1\tfastq_2\tworkflow
```

- `sample_id`: Human-readable sample name (from run title)
- `data_id`: Database accession (CRR/SRR/ERR ID)
- `design`: Experimental grouping — samples sharing the same condition/treatment/stage
- `fastq_1` / `fastq_2`: Absolute paths to FASTQ files (fastq_2 empty for single-end)
- `workflow`: Which workflow to run (e.g. tRNAseq, RNAseq, Mutation)

The `design` field groups samples by common prefix from the run title, excluding the
replicate number suffix. E.g., "GV-1", "GV-2", "GV-3" → design = "GV".

A companion `run.tsv` (from GSA/SRA download) provides the source metadata. Cross-reference
its Accession column with actual files on disk (e.g. `fastq/*.fastq.gz`) to construct
absolute paths.

## 44. Verify tool API with `--help` before fixing parameter errors

When a log shows parameter errors (e.g., `error: Found argument '--num-threads' which wasn't expected`), do NOT blindly fix based on the error message. First activate the tool's conda environment and run `--help` to verify the actual API:

```bash
# Step 1: Find the tool's conda env
which <tool> || find /path/to/envs -name "<tool>" -type f

# Step 2: Activate and check
conda activate <env>
<tool> --help

# Step 3: Fix both the generated script AND the .smk source
```

**Why**: Tool APIs change between versions. The error message suggests a fix (`Did you mean '--threads'?`), but the actual API may have other changes too (e.g., `--input-bam` → `--bam`). Running `--help` reveals all changed flags at once.

**User correction**: "你先激活那个环境,看看真实参数是怎么样的,再修改" — activate environment first, check real parameters, then modify.

**Example — hiphase 1.7.0**: Error showed `--num-threads` → `--threads`, but `--help` also revealed `--input-bam` → `--bam` and `--input-vcf` → `--vcf`. Blindly fixing only the first error would have left two more broken flags.

**Side effect discovery**: hiphase 1.7.0 auto-compresses output as bgzip when `--output-vcf` ends in `.vcf.gz`. The old script pattern (`hiphase → .vcf`, `bgzip → .vcf.gz`, `rm .vcf`) causes double-compression (see pitfall #48 Case B). Fix: pass `.vcf.gz` directly to `--output-vcf` and remove the bgzip step.

## 45. Multi-command script failure cascade — corrupted output files

When a shell script contains multiple sequential commands (e.g., hiphase → bgzip → rm),
failure of an early command doesn't stop later commands from executing. This produces
corrupted output files that block re-runs.

**Example — hiphase failure cascade**:
```bash
# Script generated by hiphase.smk run block
hiphase --num-threads 8 ... --output-vcf output.phased.vcf    # FAILS (wrong flag)
bgzip output.phased.vcf -o output.phased.vcf.gz                # runs on non-existent file → corrupted .gz
rm output.phased.vcf                                            # fails (file doesn't exist)
```

**Symptom**: `bcftools view file.vcf.gz` returns `Exec format error` or `Blocked GNU Zip Format (BGZF; gzip compatible), block length -279`

**Diagnosis**:
```bash
file output.vcf.gz
# Shows: "Blocked GNU Zip Format (BGZF; gzip compatible), block length -279" ← corrupted
ls -lh output.vcf.gz
# Shows non-zero size but corrupted content
```

**Fix**:
1. Delete the corrupted `.gz` and any `.csi`/`.tbi` index files
2. Fix the root cause (wrong tool parameters)
3. Re-run the script

**Prevention**: When debugging multi-command scripts, always check ALL output files for
corruption, not just the first command's output. The `file` command quickly reveals
truncated or malformed files.

## 46. bgzip compressed files — viewing

bgzip compressed files (.vcf.gz) can be viewed with:
```bash
zcat file.vcf.gz           # full content
zless file.vcf.gz          # paged view
zgrep "pattern" file.vcf.gz # search
bcftools view file.vcf.gz  # VCF-specific (with header parsing)
bcftools view -h file.vcf.gz # header only
bcftools view -H file.vcf.gz # records only, no header
```

## 47. Multi-command script tool resolution across conda envs

When a `run:` block generates a multi-command script (e.g., hiphase → bgzip → rm),
tools may come from different conda environments. The `conda:` directive only activates
for `shell:` commands, NOT for scripts executed via `shell("bash script.sh")` from
`run:` blocks (see pitfall #36).

**Symptom**: `bgzip: command not found` even though bgzip exists in another conda env.

**Approach 1 — `shutil.which()` with fallback** (works when tool is on system PATH):
```python
import shutil
bgzip_cmd = shutil.which("bgzip") or "/usr/bin/bgzip"
```
**Caveat**: This searches the main Snakemake process PATH, NOT the conda env. Only works
if bgzip is installed system-wide or in the base env.

**Approach 2 — `shell("which tool", read=True)`** (finds tool in conda env):
```python
bgzip_path = shell("which bgzip", read=True).strip()
```
This runs inside the conda env activation, so it finds tools installed there. Use this
when the tool is only in the conda env, not system-wide.

**Approach 3 — Add dependency to module .yaml** (preferred, permanent fix):
Add htslib to the hiphase.yaml so bgzip is in the same conda env:
```yaml
dependencies:
  - hiphase>=1.7.0
  - htslib>=1.23  # provides bgzip, tabix
```

**Approach 4 — Combine PATHs in generated script**:
```python
# In run block, find both env paths
hiphase_dir = os.path.dirname(shell("which hiphase", read=True).strip())
bgzip_dir = os.path.dirname(shell("which bgzip", read=True).strip())
script_header = f"export PATH=\"{hiphase_dir}:{bgzip_dir}:$PATH\"\n"
```

**Verification**: After fixing, verify with `file output.vcf.gz` — should show valid
BGZF without negative block length.

## 48. Corrupted bgzip file diagnosis

When `file output.vcf.gz` shows `block length -279` or similar negative number, the
bgzip file may be corrupted OR double-compressed. Two distinct root causes:

### Case A: bgzip ran on non-existent input (cascade failure, see #45)

bgzip compresses nothing → produces a truncated/corrupted file.

**Diagnosis**:
```bash
file output.vcf.gz
# "Blocked GNU Zip Format (BGZF; gzip compatible), block length -279" ← corrupted
bgzip -t output.vcf.gz  # FAILS with non-zero exit
```

**Fix**: Delete corrupted file, fix root cause, re-run.

### Case B: Double-compressed bgzip (tool auto-compresses + script compresses again)

Tool (e.g. hiphase 1.7.0) outputs bgzip-compressed `.vcf.gz` directly, but the
script also runs `bgzip` on it → outer bgzip wrapping an inner bgzip stream.

**Diagnosis** — `bgzip -t` PASSES (only checks outer BGZF structure):
```bash
file output.vcf.gz
# "Blocked GNU Zip Format (BGZF; gzip compatible), block length -356" ← negative but bgzip -t passes
bgzip -t output.vcf.gz  # PASSES (exit 0) — only validates outer layer
zcat output.vcf.gz | head  # outputs BINARY GARBAGE, not VCF text
```

**Confirmation** — double decompress reveals VCF:
```bash
bgzip -d -c output.vcf.gz | bgzip -d -c | head  # ← shows VCF headers
```

**Fix** — decompress once to get the real bgzip:
```bash
cp output.vcf.gz output.vcf.gz.doublecompressed   # backup
bgzip -d -c output.vcf.gz > output.vcf.gz.fixed
mv output.vcf.gz.fixed output.vcf.gz
file output.vcf.gz  # should show positive block length
zcat output.vcf.gz | head  # should show VCF text
```

**Prevention**: When a tool outputs `.vcf.gz` (bgzip), do NOT run bgzip again in the
same script. Check with `<tool> --help` whether it auto-compresses. If unsure, test:
```bash
file <tool_output>.vcf.gz  # if already BGZF, skip bgzip step
```

**Key distinction from Case A**: `bgzip -t` passes (Case B) vs fails (Case A).
`zcat` outputs binary garbage in both cases, but double-decompress reveals valid VCF
only in Case B.

### General verification after any fix
```bash
file output.vcf.gz                    # positive block length
zcat output.vcf.gz | head -20         # VCF headers
tabix -l output.vcf.gz                # lists chromosomes
```

# References
- `references/debugging-snakemake-source.md` — Debug Snakemake framework source itself (pdb, IDE, key entry points, execution paths, Rule attributes)
- `references/pacvar-nextflow-port-example.md` — PacVar porting case study
- `references/karrseq-porting-case.md` — KARRseq porting case study
- `references/dipseq-chipseq-case.md` — DIP-seq/ChIP-seq workflow with MACS3 peak calling
- `references/trimming-module-conventions.md` — Trimming module (cutadapt / trim-galore) rule naming, input/output conventions, UMI mode, config key pitfall
- `references/peak-calling-pattern.md` — IP/Input control mapping, MACS3 unpack() pattern
- `references/comparison-pair-workflow-pattern.md` — Comparison-pair config structure for differential analysis workflows (SV, DE, etc.)
- `references/monolithic-tool-wrapper-pattern.md` — Wrapping self-contained pipeline tools (mimseq, Cell Ranger) as single rules
- `references/optional-module-pattern.md` — Conditional modules with skip flags (fragment_size example)
- `references/pacbio-repeats-module-case.md` — PacBio telomere/centromere module (raw BAM input, k-mer density, terminal classification)
- `references/running-specific-steps.md` — Run specific rules, samples, or jobs (--target-jobs, --until, --forcerun, --omit-from, --batch, HPC job submission)
- `references/snakemake-debugging-patterns.md` — MissingInputException diagnosis, cascade re-run, index naming, `--rerun-triggers` behavior
- `references/snakemake-parser-architecture.md` — How Snakemake's tokenizer + state machine transforms .smk into Python (token automaton, Rule/Run/Shell classes)
- `references/common-smk-pattern.md` — Common.smk implementation: shared utilities via include, migration from duplicate boilerplate
- `references/snakemake-shell-autoscript-mod.md` — shell.py modification for automatic script generation from `run:` blocks (full ScriptSaveSettings design)
- `references/snakemake-audit-logging.md` — Simpler audit logging: write executed commands to `.audit.sh` in output directory, plus how to use modified snakemake source code
- `references/gatk-native-crash-diagnosis.md` — GATK SIGSEGV (exit code 245) diagnosis: Intel GKL native crash, JVM memory flags, PairHMM fallback

# Templates
- `templates/run_workflow_standalone.py` — Standalone run script for read-only run.py
- `templates/macs3_peak_calling.smk` — MACS3 module with IP/Input control support
- `templates/delayed_import_module_header.smk` — Module header with `_import_logger()` pattern for `module` + `use rule` safe imports
- `templates/common_smk.snippet` — `modules/common/common.smk` template for shared utilities (setup_logger, time, shutil, os, sys)
