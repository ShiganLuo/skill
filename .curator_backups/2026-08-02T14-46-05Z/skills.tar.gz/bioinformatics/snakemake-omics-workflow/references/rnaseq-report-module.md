# RNAseq report module (session note)

Use this when adding an RNAseq PPT report to Omics Snakemake, or extending an existing report with new analysis sections.

Key shape:
- `modules/RNAseq_report/RNAseq_report.smk`
- `modules/RNAseq_report/RNAseq_report.json`
- `modules/RNAseq_report/RNAseq_report.yaml`
- `modules/RNAseq_report/bin/generate_report.py`

Subworkflow wiring:
- `subworkflow/RNAseq.smk` builds `RNAseq_report_config`
- `use rule generate_report from RNAseq_report as RNAseq_generate_report`
- final target: `outdir + "/RNAseq_report.pptx"`

Report script notes:
- `python-pptx` for slides, `matplotlib` for charts, `PIL` for aspect-ratio-safe image sizing
- generate from existing workflow outputs; do not recompute upstream analysis
- accept `--analysis-dir`, `--output`, `--samples`, `--paired-samples`, `--single-samples`, `--contrasts`, `--lang`, `--img-dir`

## Architecture of generate_report.py

The script follows a consistent 5-layer pattern:
1. **I18N dict** (zh/en) with `t(key, lang)` helper — all user-facing strings
2. **Data loaders** — one function per analysis type, returns DataFrame/dict with safe fallbacks for missing files (`safe_read_tsv`, `safe_read_csv`)
3. **Plot functions** — matplotlib figures saved as temp PNG via `TempImageStore.save_fig()`
4. **Slide builders** — each takes `prs: Presentation` + data + `lang`, uses `_header()`, `_textbox()`, `_bullets()`, `_table()`, `_add_picture()` helpers
5. **main()** — argparse CLI, auto-discovers contrast dirs, conditionally builds slides based on file existence

Layout constants (module-level):
```python
SLIDE_W = 10.0; SLIDE_H = 5.625  # 16:9
HEADER_H = 0.65; MARGIN_L = 0.45; MARGIN_R = 0.45
CONTENT_W = SLIDE_W - MARGIN_L - MARGIN_R
CONTENT_TOP = HEADER_H + 0.18
```

## Extending the report with new analysis sections (function/GO/KEGG/GSEA pattern)

When adding a new downstream analysis (e.g. function enrichment) to the existing report, touch these layers in order:

1. **i18n keys** (zh + en) — add all user-facing strings for the new section (slide titles, column headers, notes).
2. **Data loaders** — one function per analysis type, returns dict/DataFrame with safe fallbacks for missing files. Use `safe_read_csv()` (pd.read_csv) for CSV outputs from R scripts (not read_csv with sep="\t"). Use `_count_lines()` for plain-text gene lists (up_genes.txt etc).
3. **Slide builders** — typically 3 types per new analysis:
   - Summary slide (one row per contrast, counts only)
   - Per-contrast detail slides (images + top-N tables)
   - Conclusion bullet additions (stats summary)
4. **main()** — auto-discover contrast subdirs under `{analysis_dir}/{analysis_name}/`, load summaries, conditionally build slides based on file existence.
5. **.smk inputs** — add all new output files as named inputs in `expand()` so Snakemake tracks dependencies.
6. **collect_conclusion_bullets** — extend signature to accept the new summaries list and append stats bullets.

### Function module output file inventory

Per-contrast directory `{analysis_dir}/function/{contrast}/`:
- `go_back_to_back.png`, `kegg_back_to_back.png` — back-to-back bar plots
- `go_up.csv`, `go_down.csv`, `kegg_up.csv`, `kegg_down.csv` — enrichment result tables (columns: Description, Count, pvalue, p.adjust, geneID, ...)
- `up_genes.txt`, `down_genes.txt` — one gene symbol per line
- `GSEA/TEcount_Gene_GSEA.jpeg` — waterfall NES plot
- `GSEA/TEcount_Gene_GSEA.csv` — fgsea result (columns: pathway, pval, padj, NES, ES, size, leadingEdge)
- `GSEA/enrichment_plots/*.jpeg` — per-pathway gseapy-style plots (optional, not in report)

### load_function_summary() pattern

Returns a dict with paths + loaded DataFrames + pre-computed counts:
```python
result = {
    "contrast": name,
    "go_plot": ..., "kegg_plot": ..., "gsea_plot": ...,
    "go_up_df": df, "go_up_n": len(df),
    "up_count": _count_lines(up_genes_path),
    "down_count": _count_lines(down_genes_path),
    "gsea_df": df, "gsea_n": len(df),
}
```

### Table overflow when adding picture+table slides

When a slide has pictures at top and tables at bottom, the initial layout often overflows the 5.625" slide height. Pattern to avoid:
- Pictures: max height 2.5" (not 3.0") when tables follow below
- Tables: start at y=3.55" (not 4.05"), use row height 0.22" per row (not 0.30")
- Limit table rows: top_n=2 for up + separator row + top_n=2 for down = 5 rows max per table
- Always verify with programmatic overflow check (shape bottom > slide_h)

### GSEA table: top positive + top negative pathways

The GSEA detail slide shows top pathways by NES (both positive and negative):
```python
sig = gsea_df.dropna(subset=["NES"]).sort_values("NES", ascending=False)
top_positive = sig.head(4)
top_negative = sig.sort_values("NES", ascending=True).head(4)
combined = pd.concat([top_positive, top_negative]).drop_duplicates(subset=["pathway"])
```

### .smk input additions for function

```python
func_go_plot = expand(outdir + "/function/{contrast}/go_back_to_back.png", contrast=contrasts),
func_kegg_plot = expand(outdir + "/function/{contrast}/kegg_back_to_back.png", contrast=contrasts),
func_go_up = expand(outdir + "/function/{contrast}/go_up.csv", contrast=contrasts),
func_go_down = expand(outdir + "/function/{contrast}/go_down.csv", contrast=contrasts),
func_kegg_up = expand(outdir + "/function/{contrast}/kegg_up.csv", contrast=contrasts),
func_kegg_down = expand(outdir + "/function/{contrast}/kegg_down.csv", contrast=contrasts),
func_up_genes = expand(outdir + "/function/{contrast}/up_genes.txt", contrast=contrasts),
func_down_genes = expand(outdir + "/function/{contrast}/down_genes.txt", contrast=contrasts),
func_gsea_plot = expand(outdir + "/function/{contrast}/GSEA/TEcount_Gene_GSEA.jpeg", contrast=contrasts),
func_gsea_csv = expand(outdir + "/function/{contrast}/GSEA/TEcount_Gene_GSEA.csv", contrast=contrasts),
```

## Ad-hoc verification recipe

1. `python -m py_compile modules/RNAseq_report/bin/generate_report.py`
2. Run the script against existing `output/RNAseq`
3. Confirm `Presentation(...).slides` count is expected
4. Programmatic overflow check: iterate all shapes on all slides, verify `shape.left + width <= slide_w` and `shape.top + height <= slide_h` (with ~0.01" tolerance)
5. Extract table cell text to verify data correctness (counts, pathway names, p-values)
6. Test both zh and en languages
7. For visual QA, convert PPTX -> PDF via `libreoffice --headless --convert-to pdf`, then rasterize with `pdftoppm -png -r 150` and inspect

## Layout lessons

- slide 5/table areas can become cramped when many sample labels and numeric columns share a narrow table
- slide 8 note text should not sit under or beside the table body; remove or move it if overlap appears
- when adding new sections, always run the overflow check — the 5.625" height is tight for picture+table slides
