---
name: snakemake-module-config
description: Understand and modify Snakemake module configuration in this bioinformatics pipeline project
tags: [snakemake, pipeline, config, bioinformatics]
---

# Snakemake Module Config Architecture

## Purpose
Understand how configuration flows through this Snakemake-based bioinformatics pipeline, from user-facing JSON templates to module execution.

## Architecture Overview

```
User CLI args (run.py)
    ↓
Module JSON template (e.g., mimseq.json)
    ↓
run.py::run<Workflow>() function - populates datajson with runtime values
    ↓
raw.json - written to output dir, passed to Snakemake as --configfile
    ↓
Subworkflow .smk (e.g., tRNAseq.smk) - reads config, constructs module-specific config dict
    ↓
module .smk (e.g., mimseq.smk) - receives config dict via `module X: config: ...`
    ↓
Sub-module .smk (e.g., tRNAtools.smk) - reads from config.get()
    ↓
Python scripts - invoked via shell with CLI args from params
```

## Key Files Per Module

Each module has:
1. `<module>.json` - Default config template (in `workflow/Omics/modules/<module>/`)
2. `<module>.smk` - Main module Snakefile
3. `bin/<submodule>/run.py` - Python wrapper scripts
4. Sub-module `.smk` files in subdirectories

## Config Flow Details

### 1. JSON Templates Are Just Defaults
The module's `.json` file provides default values. It is NOT the actual config used at runtime.

### 2. run.py Is The Source Of Truth
`workflow/Omics/run.py` contains `run<Workflow>()` functions (e.g., `runtRNAseq`, `runMutation`) that:
- Load the JSON template via `_load_model_json()`
- Set `datajson["ROOT_DIR"] = os.path.dirname(__file__)` (resolves to `workflow/Omics/`)
- Set other runtime values (indir, outdir, logdir, samples, etc.)
- Write the populated dict to `<outdir>/raw.json`

### 3. Subworkflows Construct Module Configs
Subworkflow `.smk` files (in `subworkflow/`) create module-specific config dicts:
```python
mimseq_config = {
    "indir": ...,
    "outdir": ...,
    "ROOT_DIR": ROOT_DIR,
    "data_dir": config.get("data_dir", ""),
    "Params": {"mimseq": config.get("Params", {}).get("mimseq", {})},
    ...
}
module mimseq:
    snakefile: "../modules/mimseq/mimseq.smk"
    config: mimseq_config
```

### 4. Modules Read Via config.get()
Module `.smk` files read values using `config.get()` with defaults:
```python
ROOT_DIR = config.get("ROOT_DIR", ".")
species = config.get("Params", {}).get("mimseq", {}).get("species", "")
```

## Pitfalls

### ❌ Wrong: Modifying Only The Module's JSON Template
The JSON template is just defaults. Changing it alone does nothing at runtime.

### ❌ Wrong: Modifying Only The Python Script
Adding a CLI arg to `bin/*/run.py` without passing it from the smk accomplishes nothing.

### ❌ Wrong: Modifying Only The Sub-Module .smk
Adding a config read in `tRNAtools.smk` without the subworkflow passing it through won't work.

### ✅ Correct: Full Stack Modification
To add a new config parameter:
1. Add default to `modules/<module>/<module>.json`
2. Add to `run<Workflow>()` in `run.py` (sets actual value)
3. Add to module config dict in `subworkflow/<workflow>.smk`
4. Read in module/sub-module `.smk` via `config.get()`
5. Pass as param to Python script in the rule

## Finding Config References

To find all files that need modification for a config change:
```bash
# Find which subworkflow imports the module
grep -r "module <name>:" workflow/Omics/subworkflow/*.smk

# Find config dict construction
grep -r "<module>_config" workflow/Omics/subworkflow/*.smk

# Find run<Workflow> function
grep -r "def run<Workflow>" workflow/Omics/run.py
```

## Adding New Config Parameters

Pattern for adding a configurable path (e.g., data_dir):

1. **JSON template**: Add `"data_dir": ""`
2. **run.py**: `datajson["data_dir"] = os.path.join(os.path.dirname(__file__), "modules", "<module>", "<module>", "data")`
3. **Subworkflow**: Add `"data_dir": config.get("data_dir", ""),` to module config dict
4. **Module smk**: `data_dir = config.get("data_dir", "") or os.path.join(ROOT_DIR, ...)`
5. **Python script**: Add `--data-dir` argument, use with fallback

## Reference Files

- `workflow/Omics/run.py` - Main entry point, all `run<Workflow>()` functions
- `workflow/Omics/subworkflow/*.smk` - Subworkflow definitions
- `workflow/Omics/modules/*/` - Module implementations
