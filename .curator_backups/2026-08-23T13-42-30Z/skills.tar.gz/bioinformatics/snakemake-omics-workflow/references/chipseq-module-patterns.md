# ChIP-seq Module Patterns

Config keys specific to ChIP-seq workflows:

```python
indir = config.get("indir", "input")           # BAM directory (from bowtie2)
peaks_indir = config.get("peaks_indir", "peaks")  # Peaks directory (from macs3)
samples = config.get("samples", [])
ip_samples = config.get("ip_samples", [])
input_samples = config.get("input_samples", [])
sample_ip_input_map = config.get("sample_ip_input_map", {})  # IP -> input control mapping
```

## Nested Procedure config for sub-tools

When a tool is a sub-command of a package (bedtools has intersect, bamtobed, etc.),
use the parent tool name in Procedure and pass the sub-command in the shell script:

```python
params:
    bedtools = config.get("Procedure", {}).get("bedtools") or "bedtools",
    samtools = config.get("Procedure", {}).get("samtools") or "samtools"
# In script: $BEDTOOLS intersect -a BAM -b PEAK -u
```

Config JSON:
```json
{
    "Procedure": {
        "bedtools": "bedtools",
        "samtools": "samtools"
    }
}
```

Note: Prefer `bedtools intersect` over legacy `intersectBed` — same functionality, better maintained.

## Markdup vs Dedup — critical distinction for ChIP-seq

**markdup** (GATK4 via `gatk_prepare.smk`): adds read groups + flags PCR duplicates in BAM. Downstream tools like MACS3 handle filtering via `--keep-dup auto`. Output: `.sorted_markdup.bam`. Uses existing `modules/gatk/gatk_prepare.smk` — do NOT create a new markdup module.

**dedup** (samtools markdup -r via `igv.smk`): removes duplicate reads entirely. Suitable for visualization tracks (BigWig) but NOT for peak calling — loses information MACS3 needs. Output: `.dedup.bam`.

**ChIP-seq DAG (aligned with nf-core/chipseq):**
```
Align (bowtie2/bwa) → raw bam
    ├── gatk_prepare: AddOrReplaceReadGroups + MarkDuplicates → .sorted_markdup.bam
    │       ├── MACS3 peak calling (--keep-dup auto handles flagged dups)
    │       ├── FRiP score (uses .sorted_markdup.bam)
    │       └── HOMER annotation (on MACS3 peaks)
    └── igv dedup (samtools markdup -r) → .dedup.bam → BigWig (bamCoverage)
```

**Key rule:** MACS3 peak calling MUST receive markdup (flagged) BAM, NOT raw and NOT dedup-removed. The `--keep-dup auto` default correctly filters marked duplicates during peak calling.

**Subworkflow config pattern:**
```python
gatk_prepare_config = {
    "indir": bowtie2_config["outdir"],
    "outdir": f"{outdir}/common/4_markdup_bam",
    "logdir": logdir,
    "input_bam_substring": "",
    "Procedure": {
        "gatk": config.get("Procedure", {}).get("gatk") or "gatk",
        "samtools": config.get("Procedure", {}).get("samtools") or "samtools"
    },
    "Params": {"gatk": config.get("Params", {}).get("gatk", {})},
    "addReadsGroup": config.get("addReadsGroup", {}),
    "genome": {"fasta": config.get("genome", {}).get("fasta")}
}
```

**Output naming:** `.sorted_markdup.bam` + `.sorted_markdup.bai` + `.Markdup-metrics.txt`

**samtools markdup pipeline (igv.smk, with -r, for tracks only):**
```bash
samtools sort -n -@ ${threads} input.bam |
  samtools fixmate -m - - |
  samtools sort -@ ${threads} - |
  samtools markdup -r -@ ${threads} - output.dedup.bam &&
  samtools index -@ ${threads} output.dedup.bam
```

## FRiP score module pattern

FRiP = reads_in_peaks / total_mapped_reads

Command sequence:
1. `bedtools intersect -a BAM -b PEAK -u | samtools view -c -` — count reads in peaks
2. `samtools flagstat BAM | grep 'mapped (' | grep -v "primary" | head -1 | awk '{print $1}'` — total mapped reads
3. `awk "BEGIN {printf \"%.6f\", reads_in_peaks / total_mapped}"` — calculate ratio

Output: `{sample_id}.FRiP.txt` with tab-separated `sample_id\tfrip_score`

Conda deps: `bedtools>=2.30.0`, `samtools>=1.15.1`

Thresholds: >= 0.3 for TFs (narrow), >= 0.2 for histone marks (broad).

**Pitfall — f-string escaping in FRiP script:** The FRiP shell script uses `script_content = f"""..."""`. Bash variables with braces like `${SAMPLE_ID}` and `${FRIP}` MUST be escaped as `${{SAMPLE_ID}}` and `${{FRIP}}` to avoid Python f-string evaluation. See SKILL.md pitfall #18.

## HOMER annotatePeaks module pattern

Command: `annotatePeaks.pl <peak> <genome_fasta> -gtf <gtf> > output.txt`

Config keys:
- `Procedure.annotatePeaks` (default: `annotatePeaks.pl`)
- `genome.fasta`, `genome.gtf`

Output: `{sample_id}/{sample_id}_peaks.annotatePeaks.txt`

Conda deps: `homer>=4.11`

Config JSON:
```json
{
    "Procedure": { "annotatePeaks": "annotatePeaks.pl" },
    "genome": { "fasta": null, "gtf": null }
}
```

## Full PeakCalling config JSON

The `config/PeakCalling.json` must include all Procedure/Params keys for every module in the DAG:

```json
{
    "Procedure": {
        "trim_galore": null, "bowtie2-build": null, "bowtie2": null,
        "samtools": null, "gatk": null, "bamCoverage": null,
        "macs3": null, "bedtools": null, "annotatePeaks": null
    },
    "Params": {
        "trim_galore": {"quality": 25},
        "gatk": {"javaOptions": "-Xmx30g", "tmp-dir": null},
        "bamCoverage": {"binSize": 50, "normalizeUsing": "CPM", "offset": null, "extendReads": false},
        "macs3": {"bw": 200, "pvalue": "1e-5", "genome_size": "mm", "cutoff_analysis": false}
    },
    "addReadsGroup": {"RGLB": "lib1", "RGPL": "ILLUMINA", "RGPU": "unit1"},
    "genome": {"fasta": null, "gtf": null, "bowtie2_index_prefix": null}
}
```

**MACS3 Params:**
- `bw`: bandwidth for model building (default 200)
- `pvalue`: p-value cutoff for peak calling (default "1e-5")
- `genome_size`: genome size shorthand — "hs" (human), "mm" (mouse), etc.
- `cutoff_analysis`: when `true`, MACS3 runs `--cutoff-analysis` to find optimal p-value threshold. **Warning:** takes ~30x longer. Default `false`.

## run.py endpoint function

`runPeakCalling()` outfiles must match the FINAL outputs (markdup, peaks, FRiP, HOMER), NOT intermediate files (trimmed fastq, raw bam). Intermediate files are tracked by Snakemake DAG automatically:

```python
# Final endpoints only
outfiles.append(f"{outdir}/common/4_markdup_bam/{sid}/{sid}.sorted_markdup.bam")
outfiles.append(f"{outdir}/tracks/{sid}.bigwig")
outfiles.append(f"{outdir}/peaks/{sid}/{sid}_peaks.narrowPeak")
outfiles.append(f"{outdir}/QC/3_frip_score/{sid}/{sid}.FRiP.txt")
outfiles.append(f"{outdir}/annotation/{sid}/{sid}_peaks.annotatePeaks.txt")
```
